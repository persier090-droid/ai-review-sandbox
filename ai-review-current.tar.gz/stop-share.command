#!/bin/zsh
set -eu
cd "${0:A:h}"
/usr/local/bin/node scripts/start-share.mjs --stop
