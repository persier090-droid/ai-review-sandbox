# Troubleshooting

Symptom → root cause → fix. One liner per entry.

| Symptom | Root cause | Fix |
|---|---|---|
| Mobile swipe gets stuck mid-slide | Scroll-based navigation (iOS Safari cancels smooth-scroll on touch; mobile URL-bar toggle changes viewport units mid-animation) | Invariant #2 — use transform-track, never native scroll. Copy the main component verbatim. |
| Two slides visible at once / adjacent slide bleeds in | Slide root uses `h-dvh`/`h-svh`/`h-screen` instead of `h-full` — self-sizing to viewport drifts against the track slot | Invariant #3 — slides must be `w-full h-full shrink-0` |
| Page scrolls instead of paginating | Container missing `fixed inset-0 overflow-hidden overscroll-none touch-none`, OR a parent imposes native scroll | Invariant #2 — lock the viewport |
| One wheel tick = multiple page jumps | Debounce `let` variable resets every render (effect deps include `nextSlide`/`prevSlide`) | Invariant #4 — `useRef` + empty effect deps + ref-captured callbacks |
| Pagination dots miscount / a slide is skipped | Hand-rolled `<section>` without `data-slide`, or duplicate `data-slide` attributes | Invariant #1 |
| Nav bar overlaps content at bottom | Symmetric `p-[...]` — no safe-area | Invariant #5 (use `--ppt-pad-*` vars) |
| Content truncated on short viewports (small laptops, zoomed browsers, split-screen) | Typography uses `clamp(min, Xvw, max)` — ignores height | Invariant #6 + padding vars shrink at `max-height:800px/600px` |
| Long table/code paginates instead of scrolling | Global wheel/touch handler preventDefaults everything | Opt in with `data-slide-scrollable` + `overflow-y-auto` + bounded height + `overscroll-contain`. See `implementation-guide.md` → "Scrollable Content Within a Slide" |
| Swipe inside a scrollable region doesn't paginate on mobile | By design — touch gestures inside `data-slide-scrollable` are handed to the inner region | User taps nav dots/arrows, or lifts and swipes outside the scrollable region |
| Chapter number / kicker / accent inconsistent across slides (e.g. only slide 1 shows "01") | Each slide generated independently without a shared header spec | Invariant #7 — lock the header spec once, apply to every content slide |
| Transition animation stutters on older mobile | Missing `will-change-transform` or `translate3d` (no GPU compositing) | Keep `will-change-transform` on the track + use `translate3d` (not `translateY`) |
| Styles not applying | `data-ppt-theme` not on root, or `theme.css` not imported | Check both |
| Framer Motion silent | `whileInView` viewport settings wrong, or `motion` import missing | Check import + viewport opts |
