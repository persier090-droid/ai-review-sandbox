import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
import {ReviewStore} from '../review-store.mjs';
import {runReview} from '../review-runtime.mjs';
import {ROLE_PERSONAS} from '../role-personas.mjs';

const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-resilience-'));
const store=new ReviewStore(directory);
let app,socket,browser;
try {
  const result=await runReview({request:{scene:'KTV点歌机｜软硬件融合业务',requirement:'点歌后展示舞蹈，消费者可以关闭',roles:ROLE_PERSONAS,reference_only:true},store,emit:()=>{},call:async()=>assert.fail('must not call a model')});
  const record=store.get(result.review_id);record.discussion_complete=false;record.state='ROUND_SPEAK';record.failure=null;
  record.workflow.chat='running';record.workflow.prd='locked';store.save(record);
  const reserve=http.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));
  const port=reserve.address().port;await new Promise(r=>reserve.close(r));
  const origin=`http://127.0.0.1:${port}`;
  app=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('../',import.meta.url)),env:{...process.env,PORT:String(port),REVIEW_DATA_DIR:directory,OPENROUTER_API_KEY:'',AI_PROVIDER:'openrouter'},stdio:['ignore','pipe','pipe']});
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('startup timeout')),5000);app.stdout.on('data',data=>{if(String(data).includes('AI review server')){clearTimeout(timer);resolve();}});app.once('exit',code=>{clearTimeout(timer);reject(Error('startup exit '+code));});});
  socket=new WebSocket(origin.replace('http','ws')+'/ws');
  await new Promise((resolve,reject)=>{socket.onopen=resolve;socket.onerror=reject;});
  async function exchange(payload) {
    return new Promise((resolve,reject)=>{
      const timer=setTimeout(()=>reject(Error('message timeout')),3000);
      socket.onmessage=event=>{clearTimeout(timer);resolve(JSON.parse(event.data));};
      socket.onclose=()=>{clearTimeout(timer);reject(Error('invalid input closed the service connection'));};
      socket.send(payload);
    });
  }
  for(const payload of ['null','[]','"text"','{broken'])assert.equal((await exchange(payload)).type,'error');
  assert.equal((await exchange('{"type":"ping"}')).type,'pong');
  assert.equal((await fetch(origin+'/api/health')).status,200);
  const recovered=await(await fetch(origin+'/api/reviews/'+record.id)).json();
  assert.equal(recovered.active,false);assert.equal(recovered.artifacts.score.decision_status,'awaiting_discussion');
  assert.equal(recovered.failure.code,'SERVICE_RESTARTED');assert.deepEqual(recovered.messages,record.messages);
  const text='消费者关闭舞蹈后可继续点歌',body=Buffer.from(JSON.stringify({kind:'观点',text,evidence:'联调模拟输入，不是现场验证证据'}));
  const split=body.indexOf(Buffer.from('消'))+1;
  const updated=await new Promise((resolve,reject)=>{
    const req=http.request(origin+'/api/reviews/'+record.id+'/learning',{method:'POST',headers:{'content-type':'application/json','content-length':body.length}},res=>{
      const chunks=[];res.on('data',chunk=>chunks.push(chunk));res.on('end',()=>{try{assert.equal(res.statusCode,200);resolve(JSON.parse(Buffer.concat(chunks)));}catch(error){reject(error);}});
    });
    req.on('error',reject);req.setNoDelay(true);req.write(body.subarray(0,split));setTimeout(()=>req.end(body.subarray(split)),30);
  });
  assert.equal(updated.learning.at(-1).text,text,'split UTF-8 bytes must survive HTTP feedback');
  const require=createRequire(import.meta.url);
  let playwright;
  try{playwright=require('playwright');}catch{playwright=require(process.env.PLAYWRIGHT_MODULE || '/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}
  browser=await playwright.chromium.launch({headless:true,...(process.platform==='darwin'?{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}:{})});
  const page=await browser.newPage();
  await page.addInitScript(id=>sessionStorage.setItem('ktv-review-id',id),record.id);
  await page.goto(origin+'/?mode=ai');
  await page.locator('#statusTag').filter({hasText:'初评完成 · 正式放行待复核'}).waitFor({timeout:30000});
  assert.equal(await page.getByRole('button',{name:'重试讨论',exact:true}).isEnabled(),true);
  assert.equal(await page.locator('#bizScene option:checked').innerText(),'KTV点歌机｜软件业务服务');
  assert.equal(updated.scene,'KTV点歌机｜软硬件融合业务','historical scene wording stays unchanged');
  console.log('本地恢复校验通过：非法消息不终止服务、重启后原文保留且可重试、中文分包回填无乱码；真实模型请求0。');
}finally {
  if(browser)await browser.close();
  if(socket){socket.onclose=null;socket.close();}
  if(app&&app.exitCode===null){app.kill();await new Promise(r=>app.once('exit',r));}
  fs.rmSync(directory,{recursive:true,force:true});
}
