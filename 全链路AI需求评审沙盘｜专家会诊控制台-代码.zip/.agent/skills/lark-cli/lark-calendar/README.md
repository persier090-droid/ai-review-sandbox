# calendar (v4)

## 身份

日程查询针对当前登录用户的日历（默认 `--as user`）。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| `+agenda` | 查看日程安排（默认今天） |
| [`+meeting`](references/lark-calendar-meeting.md) | 通过日程事件 ID 获取关联的视频会议信息（meeting_id、meeting_note），日程开过视频会议才会有meeting_id |
| `+freebusy` | 查询用户主日历的忙闲信息和 RSVP 状态（纯查询场景；找可用时段走 `+suggestion`） |
| [`+room-find`](references/lark-calendar-room-find.md) | 针对一个或多个**明确的**时间块查找可用会议室（无明确时间时禁止直接调用，需先走 +suggestion） |
| [`+suggestion`](references/lark-calendar-suggestion.md) | 根据非明确时间或一段时间范围，推荐多个可用时间块方案 |

### `+get` — 单日程详情

通过 `calendar_id` + `event_id` 获取**单个日程**详情。

```bash
# calendar_id不传，默认primary
lark-cli calendar +get --calendar-id <calendar_id> --event-id <event_id>
```

### `+search-event` — 按关键词、时间范围和参会人搜索日程

仅返回基础字段（`event_id`/`summary`/`start`/`end` 等），需要详情请走 `+get`。

```bash
# query 按关键词 可选
# start/end 按时间范围（ISO 8601 或 YYYY-MM-DD）可选
# attendee-ids 按参会人（自动识别 ou_ 用户 / oc_ 群聊 / omm_ 会议室前缀）可选
# page-token 分页游标，用于继续翻页 可选
# page-size 每页数量，默认 30 可选
lark-cli calendar +search-event --query "周会" --start 2026-04-20 --end 2026-04-27 --attendee-ids "ou_user1,oc_chat1,omm_room1" --page-token <page_token> --page-size 30
```

### `+agenda` — 查看近期日程安排

默认查询当天。结果应整理为按日期分组、按开始时间升序的易读时间线。

```bash
# start/end 时间范围（ISO 8601 / YYYY-MM-DD / Unix 秒），均可选；默认当天
# calendar-id 日历 ID（默认primary）可选
lark-cli calendar +agenda --start 2026-03-10 --end 2026-03-17 --calendar-id <calendar_id>
```

注意：
- 已取消的日程自动过滤；无日程时直接告知"日程清空"。
- 时间范围超过 40 天会自动拆分查询并合并结果。

### `+freebusy` — 查询主日历忙闲时段和 RSVP 状态

仅返回忙碌时段起止时间，不含日程标题等隐私信息；其他订阅日历不在范围内。

```bash
# start/end 时间范围（ISO 8601 / YYYY-MM-DD / Unix 秒），均可选；默认当天
# user-id 目标用户 open_id（ou_ 前缀）可选；默认当前登录用户
lark-cli calendar +freebusy --start 2026-03-11 --end 2026-03-12 --user-id ou_xxx
```

用法提示：
- **仅判断是否有空** → `+freebusy`；**需要日程详情** → `+agenda`。
- 检查多人可用性：分别调用并对比，找共同空闲。

## 核心概念

- **日程实例（Instance）**：重复性日程展开后的具体时间实例。「仅此次」操作时使用具体实例的 `event_id`；「全部」或「此次及后续」操作时需对原重复性日程操作（使用原日程 `event_id`），并按需处理例外。
- **重复性日程例外（Exception）**：对重复性日程某次实例做过「仅此次」编辑后产生的独立日程（拥有独立 `event_id`）。删除/更新「全部」时必须同时处理例外，否则例外会残留。
- **全天日程（All-day Event）**：只按日期占用、没有具体起止时刻的日程，结束日期是包含在日程时间内的。
- **时间块 vs 时间范围**：时间块是具体确定的连续时间段（如 `14:00~15:00`），时间范围是泛指（如"今天下午"）。`+room-find` 必须基于确定时间块，不能基于模糊范围。
- **会议室（Room）**："room"不是"房间"，是"会议室"。会议室是日程的一种参与人（resource attendee），不能脱离日程单独预定。
- **日程会议 ID（Meeting ID）**：日程的历史视频会议 ID，在日程上开过视频会议才会有。

## 术语映射

用户日常说的"帮我约个日历""查一下今天的日历"，实际意图是针对**日程（Event）**的创建或查询，而非操作日历（Calendar）容器本身。自动将口语化的"日历"意图映射为"日程"操作。

## 意图路由

| 用户意图 | 路由到 |
|----------|--------|
| 查询日历/日程或未来时间的会议 | 本 skill |
| 按关键词搜索日程 | 本 skill（`+search-event`） |
| 从日程获取关联的视频会议 ID 或用户绑定的会议纪要文档 | 本 skill（`+meeting`） |
| 查询可用时段 / 查找可用会议室 | 本 skill（无明确时间先用 `+suggestion` 出候选时间块，再用 `+room-find` 查会议室） |

## 时间推断规范

- **星期的定义**：周一是一周的第一天，周日是最后一天。计算"下周一"等相对日期时，基于当前真实日期推算。
- **一天的范围**：用户提到"明天""今天"等泛指某天时，时间范围应覆盖整天，不要自行缩减。

## 会议室规则

- 查询/搜索可用会议室必须基于确定的时间块，参数规范详见 [+room-find](references/lark-calendar-room-find.md)。
- `+room-find` 的时间输入必须是确定时间块，不能是时间区间搜索。
- 用户仅要求"查会议室"但未提供明确时间时，必须先调用 `+suggestion` 获取可用时间块，再将时间块交给 `+room-find`。严禁猜测时间盲目调用。

## API Resources

除上述快捷命令外，本域在沙箱内**仅**以下只读原生 API 命令可用（通用格式 `lark-cli calendar <resource> <method> [flags]`）：

### calendars

- `get` — 获取单个日历信息
- `list` — 列出日历
- `primary` — 查询用户主日历
- `search` — 搜索日历

### events

- `get` — 获取单个日程详情
- `instance_view` — 展开重复性日程的实例视图
- `search_event` — 按条件搜索日程
- `share_info` — 获取日程分享信息

### freebusys

- `list` — 查询忙闲

示例：

```bash
# 查询用户主日历
lark-cli calendar calendars primary

# 获取日程分享链接
lark-cli calendar events share_info --calendar-id <calendar_id> --event-id <event_id>
```

> `calendar_id` 可以直接传 `primary`，代表当前调用身份的主日历 ID。

### 查询方法的使用方式

- 查看方法的 cli flag：`lark-cli calendar <resource> <method> -h`
- 查看方法 API 参数：`lark-cli schema calendar.<resource>.<method>`（例：`lark-cli schema calendar.events.get`）

沙箱内仅上述 API 命令可用，不要尝试其它 `service`/`api` 组合或写操作方法。

## 常用其他域命令

```bash
# 搜索用户，更多参数详见 lark-contact
lark-cli contact +search-user --query <query> --as user

# 搜索群聊，更多参数详见 lark-im
lark-cli im +chat-search --query <query> --as user
```

> 搜到的 `ou_` open_id（用户）/ `oc_` chat_id（群聊）用于 `--attendee-ids` 这类参会人参数。**解析不到，或参会人类型不明确时，向用户澄清该参会人是用户还是群聊，不要靠名字形态硬猜类型**——猜错会把日程查询/推荐建立在错误的实体上。

## 强制性规则

- 涉及日期（时间）字符串与时间戳的相互转换时，务必调用系统命令或脚本代码等外部工具进行处理，以确保转换的绝对准确。违者将导致严重的逻辑错误！
- **换算禁止依赖容器默认时区。** 沙箱容器默认时区是 UTC，直接用 `date`、`new Date()` 之类不带时区的换算会产生 8 小时偏移，把「下午 3 点的会」算成「晚上 11 点」。所有换算必须显式指定目标时区（如 `TZ=Asia/Shanghai date -d ...`），并在传 `--start-time` / `--end-time` 等参数时优先用带偏移的 ISO 8601（`2026-03-19T15:00:00+08:00`）而非裸时间串。
- 接受 `--timezone` 的命令（`+room-find` / `+suggestion`）**不要依赖它的默认值**：沙箱里没有"用户设备时区"，默认会落到容器时区。用户提到时区就显式传，没提就按其日程/公司主时区显式传。
- 会议室**物理设施**管理（设备、容量等）不由 CLI 提供，走管理员后台。
