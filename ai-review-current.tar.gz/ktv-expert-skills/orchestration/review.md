> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 评审模式 review v2.0

## 适用场景
针对一个具体方案或需求做可行性评审。

## v2.0 核心变化
- 五类评审分别定义（需求/方案/交付/质量/复盘）
- 增加前置检查（材料、角色、议程）
- 增加质询-回应循环
- 增加分歧升级机制
- 增加结论结构化和执行跟踪
- 增加评审失败处理

## 评审前
1. 议题准入（intake.md）
2. 材料准备（materials.md）
3. 角色选择（roles.md）
4. 议程设定（agenda.md）
5. 前置检查（precheck.md）

## 评审中
1. 主答发言（按 dependency.md 顺序）
2. 质询（按 challenge-protocol.md）
3. 分歧处理（按 disagreement.md）
4. 决策（按 decision-rules.md）
5. 时间控制（按 time-box.md）
6. 状态管理（按 state-machine.md）

## 评审后
1. 结论结构化（conclusion.md）
2. 执行跟踪（execution-tracking.md）
3. 条件验证（condition-verification.md）
4. 复盘（retrospective.md）
5. 自评（self-assessment.md）
6. 记录（record.md）

## 五类评审
- 需求评审（type-requirement.md）
- 方案评审（type-solution.md）
- 交付评审（type-delivery.md）
- 质量评审（type-quality.md）
- 复盘评审（type-retrospective.md）

## 最终输出
【方案名称】……
【评审结论】通过 / 有条件通过 / 不通过 / 延期
【通过条件】……
【最大风险】……
【执行项】谁、何时、做什么
【复盘节点】时间与指标
【保留意见】……


## 禁止行为
- 禁止无结论
- 禁止条件模糊
- 禁止跳过测试与项目经理环节
- 禁止不记录保留意见
