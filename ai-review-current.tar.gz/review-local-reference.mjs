import fs from 'node:fs';
import {sceneKey} from './review-context.mjs';
import {localScope} from './review-local-scope.mjs';
import {createCaseSearch} from './review-local-search.mjs';
const bank=JSON.parse(fs.readFileSync(new URL('./evaluation/review-cases-1000.json',import.meta.url),'utf8')).cases;
const search=createCaseSearch(bank);
export function localCrossChecks(review) {
  const scope=localScope(review);if(scope.status==='clarify')return [];
  const selected=new Set((review.roles || []).map(r=>r.key));
  return search(sceneKey(review.scene),scope).map(({item,overlap,match})=>({
    case_id:item.id,scene:item.scene,category:item.category,actor:item.actor,title:item.title,question:item.question,matched_terms:overlap,source:'本地1000条场景交叉验证参考，非本轮模型回复',
    cost_items:item.cost_items,role_views:item.role_views,sources:item.sources || [],match,
    roles:item.roles.filter(role=>selected.has(role)),scenario:item.scenario,premise:item.premise,reply:item.reply,reasoning:item.reasoning,
    challenge:item.challenge,response:item.response,evidence:item.evidence,verify:item.verify,accept:item.accept,overturn:item.overturn,boundary:item.boundary,
    applicability:'关键词、同义表达和本地文本向量匹配的候选案例；适用前提需核对，不计入真实专业覆盖或上线证据'
  }));
}

export function localDiscussion(ref,selectedRoles,review) {
  const base=referenceConversation(ref,selectedRoles),byKey=new Map(selectedRoles.map(r=>[r.key,r]));
  const proposer=byKey.has('pd')?'pd':ref.roles[0] || selectedRoles[0]?.key || 'facilitator';
  const responder=ref.roles.find(r=>r!==proposer&&r!=='test') || proposer;
  const challenger=byKey.has('test')?'test':selectedRoles.find(r=>r.key!==responder)?.key || 'facilitator';
  const reference={case_id:ref.case_id,title:ref.title,premise:ref.premise,boundary:ref.boundary,evidence:ref.evidence,match:ref.match,source:'本地参考，非模型实时生成'};
  const turns=[],push=(role,text,phase)=>turns.push({role,text,phase,reference});
  const context=ref.scenario.context,assets=context.assets.join('、');
  const opening=ref.role_views?.[proposer] || (proposer==='pd'?base[0].text:`我从${byKey.get(proposer)?.professional_view || '本岗位职责'}核对“${ref.title}”。${ref.reply}相关能力还要按${context.baseline}做对照，不能只凭方案文字认定可用。`);
  push(proposer,`${review.inputs?.length>1?`你补充的“${review.inputs.at(-1)}”先作为本轮讨论条件。\n`:''}${opening}`,'角色立场');
  const legacy={
    pd:ref.reply,sales:`站在${ref.actor}的采购与使用意愿上，我还要确认现状发生频率，以及不做的影响。${ref.reasoning}未验证的收益不写成交付承诺。`,
    op:`执行时需要明确谁配置、谁暂停。围绕“${ref.title}”，先记录启用与退出的实际情况；${context.trigger}时不能靠员工猜结果。试验范围和素材版本变更都要留记录。`,
    project:`交付前先核对${assets}。${ref.boundary}依赖没确认就报固定工期不合理，先与研发拆工作量，再安排这次验证。`,
    client:`终端侧先拆清启用、执行、退出三个状态，逐项对照${context.baseline}。重点看“${ref.scenario.validation.exception}”；先用边界设备测出来，再确定适配范围，不把单台演示当作全部可用。`,server:`实现“${ref.title}”时，我会先核对请求所属对象、版本和处理结果，区分失败与重复操作。涉及调用、存储或传输的持续费用要单列，不能只估开发工期；没有服务端改动的部分不额外扩建设计。`,
    h5:`站在${ref.actor}的操作路径看，“${ref.title}”不能只有开启入口。处理状态、失败原因与退出都要可见；${ref.accept}这些要落到操作验收，不能只看页面效果。`,
    service:`针对“${ref.scenario.validation.exception}”，需要留${assets}和失败时间，售后才能定位。${ref.overturn}恢复之后还要复测原流程，不能只确认新功能能打开。`
  };
  for(const role of selectedRoles) {
    if(role.key===proposer||role.key===challenger)continue;
    const text=ref.role_views?.[role.key] || legacy[role.key] || `我按${role.name}的职责核对这次“${ref.title}”。${role.professional_view}中哪些部分直接受本次改动影响，需要先确认；我不代其他岗位承诺效果，先核对${ref.evidence}`;
    push(role.key,text,'角色立场');
  }
  push(challenger,ref.role_views?.test || base[1].text,'关键质询');
  push(responder,ref.role_views?ref.response:base[2].text,'依据回应');
  push(challenger,ref.role_views?`我们用这个反例检查方案：${ref.verify}\n${ref.overturn}`:base[3].text,'反驳校验');
  push(proposer,`先确认两件事：${context.open_questions?.[0] || '目前的做法和问题频率是什么？'}${context.open_questions?.[1]?`\n${context.open_questions[1]}`:''}\n拿到记录后按“${ref.accept}”核对；未满足前仅安排验证，不扩大承诺。`,'收口决策');
  return turns;
}

const conversationalCases={
  'KTV-001':[
    '我建议先让包厢里的点歌消费者自己开启伴舞，也能随时关掉。现在还没验证大家是否喜欢、设备是否带得动，不急着每首歌自动开启。先用已授权的素材，歌词要看得清，切歌也不能受影响。',
    '如果低配机一边播MV、一边放伴舞就卡了，动画还要保留吗？',
    '这种情况先关伴舞，保证歌曲正常播放。轻量素材也可以考虑，但得先验证，不能拿高配机上的演示效果承诺所有门店都能用。',
    '我建议拿同一台设备、同一首歌做有无伴舞的对比，把切歌、暂停、连续播放和资源不足都测到。机型、开关记录和播放数据要留下；如果出现持续断音或歌词看不清，这版就先别放行。性能预算也要提前约好。'
  ],
  'KTV-037':[
    '先别承诺所有老机型都能升级。对想保留旧设备的门店经营者来说，能不能稳定用、升级要花多少，比演示效果更重要。我们还缺完整的机型清单，应该先分清哪些能完整运行、哪些需要降级、哪些暂不支持。',
    '但有些门店不愿意换硬件。如果把渲染放到云端，能不能让这些老设备也用起来？',
    '云渲染可以作为候选方案，但还不能直接答应门店。网络、时延、同时使用的规模和费用都得另外验证，不能把云端当成没有成本的兜底。',
    '我建议按硬件和系统版本挑边界设备来测，保留连续播放、资源占用以及升级回滚的记录，销售再核对能承诺哪些机型。如果最低配置一直影响点歌，就先移出支持范围；不支持的设备要说清楚，同时保住原有功能。'
  ],
  'KTV-002':[
    '我建议先挑一批歌曲验证，通过后再开放。对包厢里看舞蹈的人来说，算法能算出节拍，不代表看起来就合拍。变速、停顿和拖动进度都可能打乱同步；不稳定的歌曲先回退普通氛围动作，暂时别宣传全曲库精准踩点。',
    '匀速的部分没问题，还不够。歌曲突然变速，或者点歌的人拖了一下进度，舞蹈还能跟上吗？',
    '这些片段要单独标出来，测试能不能重新同步。我们只对验证通过的歌曲版本承诺能力，不能把一个版本的结果套到所有曲目。',
    '我建议把慢歌、强节奏、变速和留白分别测一遍，再看拖动、暂停恢复后的表现。曲目版本、人工标注、同步偏差和观看者盲评都要留记录。先约好同步和体验门槛；如果平均成绩不错，但变速歌曲还是一直错拍，就缩小开放范围。识别失败时也要能正确回退。'
  ]
};

export function referenceConversation(ref, selectedRoles) {
  const selected=new Set(selectedRoles.map(r=>r.key));
  const speaker=ref.roles.find(role=>selected.has(role)) || 'facilitator';
  const challenger=ref.roles.find(role=>selected.has(role)&&role!==speaker) || (selected.has('test')&&speaker!=='test'?'test':'facilitator');
  const verifier=selected.has('test')?'test':speaker;
  const lines=conversationalCases[ref.case_id] || [
    `${ref.reply.replace(/^先/,'我建议先')}\n\n${ref.reasoning}`,
    ref.challenge,
    ref.response,
    `验证这件事，我建议这样做：${ref.verify}\n\n${ref.accept}\n${ref.overturn}`
  ];
  return [speaker,challenger,speaker,verifier].map((role,i)=>({role,text:lines[i],reference:{case_id:ref.case_id,title:ref.title,premise:ref.premise,boundary:ref.boundary,evidence:ref.evidence,source:'本地参考，非模型实时生成'}}));
}
