import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {buildDeepSeekRequest,createDeepSeekBudget,DEEPSEEK_MODEL,DEEPSEEK_URL} from '../deepseek-provider.mjs';
import {readModelStream} from '../server.mjs';
import {runAutomaticReview} from '../review-automatic.mjs';
import {ReviewStore} from '../review-store.mjs';
import {ROLE_PERSONAS} from '../role-personas.mjs';
import {sourceFingerprint} from './source-fingerprint.mjs';
import {liveReviewChecks} from '../review-readiness.mjs';

const apiKey=process.env.DEEPSEEK_API_KEY;
if(!apiKey){console.error('未配置DEEPSEEK_API_KEY；没有发起网络请求。');process.exit(1);}
const root=fileURLToPath(new URL('../',import.meta.url));
try {
  const metadata={};
  for(const endpoint of ['models','user/balance']) {
    const response=await fetch(`${DEEPSEEK_URL}/${endpoint}`,{headers:{authorization:`Bearer ${apiKey}`},signal:AbortSignal.timeout(15000)});
    if(!response.ok)throw new Error(`DeepSeek ${endpoint} HTTP ${response.status}`);
    const data=await response.json();
    metadata[endpoint]=endpoint==='models'?data.data?.map(m=>m.id):{is_available:data.is_available,balance_infos:data.balance_infos};
  }
  console.log(JSON.stringify({read_only:true,provider:'deepseek',...metadata}));
  if(process.argv.includes('--review')) {
    const budget=createDeepSeekBudget({apiKey,allowPaid:process.env.DEEPSEEK_ALLOW_PAID==='true',limitCny:Number(process.env.DEEPSEEK_SPEND_LIMIT_CNY || 0),filename:path.join(process.env.REVIEW_DATA_DIR || path.join(root,'.review-data'),'deepseek-budget.json')});
    if(!budget.inspect().inference_enabled)throw new Error(budget.inspect().message);
    const previous=process.argv.includes('--resume')?JSON.parse(fs.readFileSync(path.join(root,'test-results/deepseek-live-report.json'),'utf8')):null;
    if(previous&&previous.source!==sourceFingerprint())throw new Error('代码已变更，不能直接复用旧联调阶段，请重新开始验证');
    const dir=previous?.record_directory || fs.mkdtempSync(path.join(os.tmpdir(),'deepseek-review-')),store=new ReviewStore(dir);
    const resumeId=previous?JSON.parse(fs.readFileSync(path.join(dir,'events.jsonl'),'utf8').trim().split('\n').at(-1)).review.id:undefined;
    let calls=0;const usage=[];const started=Date.now();
    const call=async(prompt,signal)=>{
      const wire=buildDeepSeekRequest({apiKey,messages:[{role:'system',content:'按当前评审阶段返回紧凑JSON。不得编造现场记录或预写未来结论。'},{role:'user',content:prompt}]});
      const receipt=budget.reserve(JSON.parse(wire.body));calls++;
      const response=await fetch(wire.url,{method:'POST',headers:wire.headers,body:wire.body,signal:AbortSignal.any([signal,AbortSignal.timeout(75000)])});
      if(!response.ok||!response.body)throw new Error(`DeepSeek chat HTTP ${response.status}`);
      let requestUsage;
      const output=await readModelStream(response.body,true,event=>{if(event.usage){requestUsage=event.usage;usage.push(event.usage);}});
      budget.settle(receipt,requestUsage);return output;
    };
    call.stats=()=>({active_provider:'deepseek',...budget.inspect()});
    const result=await runAutomaticReview({request:{review_id:resumeId,resume_discussion:Boolean(resumeId),scene:'ktv',model:DEEPSEEK_MODEL,roles:ROLE_PERSONAS,exploratory:true,requirement:'联调模拟需求，不代表已完成实测：包厢消费者可以主动邀请同场消费者合唱，被邀请者可拒绝或退出。只做本场邀请，不新增收费，不跨包厢。现状和收益需要门店核实；先评估是否进入小范围验证，未经同意不能开麦。成本和预算明细尚待技术及运营核对。'},store,call,emit:event=>{if(event.type==='status')console.log(JSON.stringify({phase:event.status}));},modelSource:{kind:'automatic_paid',label:'DeepSeek实时生成 · 付费API联调'}});
    const allUsage=[...(previous?.usage || []),...usage];
    const checks=liveReviewChecks(result,allUsage,ROLE_PERSONAS.map(r=>r.key));
    const report={at:new Date().toISOString(),source:sourceFingerprint(),provider:'deepseek',model:DEEPSEEK_MODEL,calls:calls+(previous?.calls || 0),latest_calls:calls,elapsed_ms:Date.now()-started+(previous?.elapsed_ms || 0),passed:checks.api_transport==='passed'&&checks.model_contract==='passed',checks,workflow:result.workflow,failure:result.failure,coverage:result.artifacts.score.coverage,verdict:result.artifacts.score.verdict,usage:allUsage,budget:budget.inspect(),record_directory:dir};
    fs.mkdirSync(path.join(root,'test-results'),{recursive:true});fs.writeFileSync(path.join(root,'test-results/deepseek-live-report.json'),JSON.stringify(report,null,2));
    console.log(JSON.stringify(report));if(!report.passed)process.exitCode=1;
  }
}catch(error){console.error(error.message);process.exitCode=1;}
