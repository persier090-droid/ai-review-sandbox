# Lark Sheet Pivot Table

## 使用场景

查看飞书表格中已有数据透视表对象的配置。本 reference 覆盖 1 个只读 shortcut：

| 操作需求 | 使用工具 | 说明 |
|---------|---------|------|
| 查看已有透视表 | `+pivot-list` | 获取透视表的结构、数据源、配置与展开后的占用区域 |

## Shortcuts

| Shortcut | Risk | 分组 |
| --- | --- | --- |
| `+pivot-list` | read | 对象 |

## Flags

### `+pivot-list`

_公共四件套 · 系统：`--dry-run`_

| Flag | Type | 必填 | 说明 |
| --- | --- | --- | --- |
| `--pivot-table-id` | string | optional | 按 id 过滤 |

## Examples

公共四件套：所有 shortcut 顶部排列 `--url` / `--spreadsheet-token` / `--sheet-id` / `--sheet-name`（XOR）。

### `+pivot-list`

```bash
lark-cli sheets +pivot-list --url "..." --sheet-id "$SID"
```

> **返回值含 `info`（展开后的占用区域与状态）**：每个透视表对象除 `position` / `snapshot` 外，还返回 `info`，标明它在 sheet 上的平铺区域与状态——`info.page_range`（筛选/分页区 A1）、`info.content_range`（主体数据区 A1）、`info.span_range`（空表合并区 A1）、`info.error_state`（错误状态，如 `None`/`Cover`/`Shrink`/`Loading`）、`info.is_empty` / `info.is_hidden`、`info.row`/`info.col`（锚点）等。
> **用途（判断某单元格是否属于透视表）**：读到某单元格要判断它是普通单元格还是透视产物时，先 `+pivot-list` 拿 `info`，看该单元格是否落在 `page_range` / `content_range` 内——落在区域内即属于某个透视表（透视表单元格不能当普通单元格解读），落在区域外则是普通单元格。

### Validate / DryRun / Execute 约束

- `Validate`：`--url` / `--spreadsheet-token` XOR 必填；`--sheet-id` / `--sheet-name` XOR 必填一个。
- `DryRun`：输出请求模板，零网络副作用。
- `Execute`：发起透视表列表查询。
