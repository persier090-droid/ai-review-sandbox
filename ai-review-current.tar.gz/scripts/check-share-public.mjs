import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createRequire} from 'node:module';
const root=fileURLToPath(new URL('../',import.meta.url));
const config=JSON.parse(fs.readFileSync(path.join(root,'.share/access.json'),'utf8'));
const password=fs.readFileSync(path.join(root,'.share/access-password.txt'),'utf8').trim();
const require=createRequire(import.meta.url);
const {chromium}=require('/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const browser=await chromium.launch({headless:true,executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
try {
  const context=await browser.newContext({baseURL:config.origin,viewport:{width:1440,height:1000}});
  const page=await context.newPage(),errors=[];
  page.on('pageerror',e=>errors.push(e.message));
  page.on('request',request=>{if(request.method()==='POST'&&new URL(request.url()).pathname==='/login')console.log(JSON.stringify({loginOrigin:request.headers().origin ?? null}));});
  await page.goto(config.origin,{timeout:45000});
  await page.getByLabel('访问口令').fill(password);
  await page.getByRole('button',{name:'进入评审',exact:true}).click();
  try{await page.locator('#reqInput').waitFor({timeout:30000});}catch(error){
    console.log(JSON.stringify({url:page.url(),body:(await page.locator('body').innerText()).slice(0,1200),cookies:(await context.cookies()).map(c=>({name:c.name,domain:c.domain,secure:c.secure}))}));
    await page.screenshot({path:path.join(root,'.share/login-debug.png'),fullPage:true});throw error;
  }
  assert.equal(await page.locator('#reqInput').inputValue(),'');
  assert.deepEqual(await page.locator('#runMode option').allTextContents(),['本地交叉验证']);
  const ws=await page.evaluate(()=>new Promise((resolve,reject)=>{
    const socket=new WebSocket(`wss://${location.host}/ws`),timer=setTimeout(()=>{socket.close();reject(Error('WSS timeout'));},15000);
    socket.onopen=()=>socket.send(JSON.stringify({type:'ping'}));
    socket.onmessage=e=>{clearTimeout(timer);resolve(JSON.parse(e.data).type);socket.close();};socket.onerror=()=>reject(Error('WSS failed'));
  }));assert.equal(ws,'pong');
  await page.locator('#reqInput').fill('分享验收样例：KTV包厢消费者主动打开数字人伴舞，可随时关闭，不遮挡歌词，不改变原点歌队列、不新增收费。');
  await page.locator('#interveneBtn').click();
  await page.waitForFunction(()=>document.querySelector('#statusTag').textContent.includes('初评完成')&&!document.querySelector('#endBtn').disabled,null,{timeout:60000});
  for(const tab of ['score','risk','todo','prd']){assert.equal(await page.locator(`[data-tab="${tab}"]`).isDisabled(),false);await page.locator(`[data-tab="${tab}"]`).click();assert.ok((await page.locator(`#panel-${tab}`).innerText()).length>60);}
  const id=await page.evaluate(()=>sessionStorage.getItem('ktv-review-id'));
  const review=await(await context.request.get('/api/reviews/'+id)).json();assert.equal(review.usage.calls,0);
  await page.locator('[data-tab="chat"]').click();
  await page.locator('#reqInput').fill('补充：只做本包厢当前歌曲的伴舞，关闭后立即恢复原画面。');await page.locator('#interveneBtn').click();
  await page.waitForFunction(()=>document.querySelector('#statusTag').textContent.includes('初评完成')&&!document.querySelector('#endBtn').disabled,null,{timeout:60000});
  await page.locator('#endBtn').click();
  const fresh=await browser.newContext({baseURL:config.origin});
  assert.equal((await fresh.request.get('/api/reviews/'+id)).status(),401);
  const login=await fresh.request.post('/login',{form:{password},headers:{origin:config.origin},maxRedirects:0});assert.equal(login.status(),303);
  assert.equal((await fresh.request.get('/api/reviews/'+id)).status(),404);
  await page.screenshot({path:path.join(root,'.share/public-desktop.png'),fullPage:true});
  await page.setViewportSize({width:390,height:844});assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.screenshot({path:path.join(root,'.share/public-mobile.png'),fullPage:true});
  assert.deepEqual(errors,[]);
  const report={origin:config.origin,at:new Date().toISOString(),passed:true,https:true,login:true,wss:true,blank_input:true,four_artifacts:true,followup:true,session_isolation:true,api_calls:0,mobile_overflow:false};
  fs.writeFileSync(path.join(root,'.share/public-verification.json'),JSON.stringify(report,null,2),{mode:0o600});console.log(JSON.stringify(report));
}finally{await browser.close();}
