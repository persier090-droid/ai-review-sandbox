import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import {passwordRecord} from '../share-access.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),directory=path.join(root,'.share');
const hostname='ai-review-sun-20260922.frp.ktvsky.com';
fs.mkdirSync(directory,{recursive:true,mode:0o700});
const configPath=path.join(directory,'access.json');
if(!fs.existsSync(configPath)){
  const password=crypto.randomBytes(18).toString('base64url');
  fs.writeFileSync(configPath,JSON.stringify({origin:`https://${hostname}`,directory:path.join(directory,'data'),...passwordRecord(password)},null,2),{mode:0o600,flag:'wx'});
  fs.writeFileSync(path.join(directory,'access-password.txt'),password+'\n',{mode:0o600,flag:'wx'});
}
// Parse the service's TOML using the standard parser, never print its token.
const template=JSON.parse(execFileSync('python3',['-c','import tomllib,json,sys; print(json.dumps(tomllib.load(open(sys.argv[1],"rb"))))',path.join(directory,'frpc-template.toml')],{encoding:'utf8'}));
if(template.serverAddr!=='server.frp.ktvsky.com'||template.serverPort!==8080||typeof template.auth?.token!=='string')throw new Error('Unexpected FRP service configuration');
if(!template.auth.token||/^\*+$/.test(template.auth.token))throw new Error('FRP template contains a placeholder token; obtain a valid company configuration before publishing');
const toml=`serverAddr = ${JSON.stringify(template.serverAddr)}\nserverPort = ${template.serverPort}\nauth.token = ${JSON.stringify(template.auth.token)}\ntransport.tls.enable = true\n\n[[proxies]]\nname = "ai-review-sun-20260922"\ntype = "http"\nlocalIP = "127.0.0.1"\nlocalPort = 8001\ncustomDomains = ["${hostname}"]\n`;
fs.writeFileSync(path.join(directory,'frpc.toml'),toml,{mode:0o600});
console.log(JSON.stringify({origin:`https://${hostname}`,port:8001,config:configPath,local_only:true,credentials_in_output:false}));
