import fs from 'node:fs';
import path from 'node:path';

export function createSkillLibrary(root,manifest) {
  const base=fs.realpathSync(root),cache=new Map();
  const document=name=>{
    if(typeof name!=='string'||!/^[_a-zA-Z0-9/-]+\.md$/.test(name)||name.startsWith('/')||name.split('/').includes('..'))throw new Error('技能路径无效');
    const file=path.join(base,name);
    if(!Object.hasOwn(manifest.documents,name)||!fs.existsSync(file))throw new Error(`技能文档不存在：${name}`);
    if(!fs.realpathSync(file).startsWith(base+path.sep))throw new Error('技能路径越界');
    if(!cache.has(name))cache.set(name,fs.readFileSync(file,'utf8'));
    return cache.get(name);
  };
  return {read(role,{seen=new Set()}={}){
    const start=manifest.roles[role];if(!start)return [];
    const result=[],visiting=new Set();
    const visit=name=>{
      if(visiting.has(name))throw new Error(`技能继承循环：${name}`);
      const text=document(name);if(seen.has(name))return;
      visiting.add(name);
      const parents=manifest.documents[name].inherits || [];
      if(!Array.isArray(parents))throw new Error(`技能继承格式错误：${name}`);
      for(const parent of parents)visit(parent);
      visiting.delete(name);seen.add(name);result.push({path:name,text});
    };
    visit(start);return result;
  }};
}
