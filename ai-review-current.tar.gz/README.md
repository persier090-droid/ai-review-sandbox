# AI Review Sandbox

全链路 AI 需求评审沙盘：支持 KTV、车载音响与 KTV、SaaS、App、Web 等场景的岗位讨论、质询、评分、风险、待办和交付文档生成。

## 本地启动

需要 Node.js 20 或更高版本：

```bash
cp .env.example .env
node --env-file=.env server.mjs
```

打开 <http://127.0.0.1:8000/>。

本机也可以双击 `start-local.command`：已有服务时直接打开页面，否则使用本地 `.env` 启动服务，日志写入 `.review-data/local-server.log`。首次打开、重置和切换场景后需求输入为空，需要手动输入。

运行模式：

- `?mode=local`：本地交叉验证，不调用模型、不需要 API Key。
- `?mode=ai`：通过本地 WebSocket 服务调用配置的模型 API。
- `?mode=manual`：网页模型协作，导入并校验模型返回的 JSON。

默认场景为 `KTV点歌机｜软件业务服务`。本地交叉验证使用关键词、同义词和 TF-IDF 稀疏向量检索，不把案例当作现场事实或正式放行依据。

## 模型配置

项目默认使用 OpenRouter 免费路由。需要时可在本地 `.env` 配置 DeepSeek 付费接续，并设置累计预算上限：

```env
AI_PROVIDER=openrouter
OPENROUTER_API_KEY=your_key
OPENROUTER_MODEL=openrouter/free
DEEPSEEK_API_KEY=your_key
DEEPSEEK_ALLOW_PAID=true
DEEPSEEK_AUTO_FALLBACK=true
DEEPSEEK_SPEND_LIMIT_CNY=3
```

`.env`、本地评审记录、预算账本和测试报告不会提交到仓库。部署环境应通过平台密钥管理注入 API Key，不要把密钥写入 Git。

## 验证

运行完整本地验收流水线：

```bash
node scripts/verify-release.mjs
```

该流水线覆盖本地恢复、60 条 KTV 案例、1000 条多场景资料、岗位技能、六阶段讨论、四项顺序交付、WebSocket 恢复和网页模型协作校验。真实模型质量和第三方服务长期可用性仍需单独验证。

## 部署提示

这是一个 Node.js 静态页面加本地 API/WebSocket 服务。部署平台需要：

1. 使用 Node.js 20+。
2. 执行 `node --env-file=.env server.mjs`。
3. 将 HTTP 和 WebSocket 转发到同一个端口，默认端口为 `8000`。
4. 为 `.env` 和 `.review-data` 配置私有持久化存储；生产环境不要提交本地数据。

更完整的使用说明见 [`本地使用说明.md`](./本地使用说明.md)。
