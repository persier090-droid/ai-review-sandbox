import test from 'node:test';
import assert from 'node:assert/strict';
import {liveReviewChecks,releaseChecks} from './review-readiness.mjs';

const roles=['pd','sales','op','project','client','server','h5','test','service'];
function complete() {
  return {failure:null,phase_progress:Array.from({length:6},()=>({status:'complete'})),conclusion:{decision:'延期'},role_status:Object.fromEntries(roles.map(role=>[role,{included:true}])),workflow:Object.fromEntries(['chat','score','risk','todo','prd'].map(key=>[key,'complete'])),artifacts:Object.fromEntries(['score','risk','todo','prd'].map(key=>[key,{verdict:'不通过',items:[],markdown:'有依据的准备与交付记录',...(key==='score'?{decision_status:'reviewed',score:75}:{})}]))};
}
test('transport success does not count as a valid model review',()=>{
  const result=complete();result.failure={message:'正文缺少对象视角'};result.conclusion=null;
  const checks=liveReviewChecks(result,[{cost:0}],roles);
  assert.equal(checks.api_transport,'passed');assert.equal(checks.model_contract,'failed');
  assert.equal(checks.free_cost,'passed');
});
test('a reasoned business rejection can complete the process; blank artifacts and partial roles cannot',()=>{
  assert.equal(liveReviewChecks(complete(),[{cost:0}],roles).model_contract,'passed');
  for(const change of [r=>r.artifacts.prd=null,r=>r.role_status.test.included=false,r=>r.artifacts.score.decision_status='awaiting_discussion',r=>r.workflow.todo='running']) {
    const r=complete();change(r);assert.equal(liveReviewChecks(r,[{cost:0}],roles).model_contract,'failed');
  }
  assert.equal(liveReviewChecks(complete(),[{}],roles).free_cost,'unverified');
  assert.equal(liveReviewChecks(complete(),[{cost:0.1}],roles).free_cost,'failed');
});
test('release separates local acceptance, fresh API evidence, output gates and free billing',()=>{
  const source='current',now=Date.now(),live={source,at:new Date(now).toISOString(),full:true,transport:'batched',checks:liveReviewChecks(complete(),[{cost:0}],roles)};
  assert.equal(releaseChecks({localPassed:true,live,source,now}).local_flow,'passed');
  assert.equal(releaseChecks({localPassed:true,live,source,now}).local_pilot,'passed');
  for(const override of [{source:'old'},{at:'2000-01-01'},{transport:'staged'},{full:false},{checks:undefined}])assert.equal(releaseChecks({localPassed:true,live:{...live,...override},source,now}).local_pilot,'blocked');
  assert.equal(releaseChecks({localPassed:false,live,source,now}).local_pilot,'blocked');
});
