# Lark Sheet Sheet Structure

## 使用场景

查看飞书表格子表的结构与布局。本 reference 覆盖 1 个只读 shortcut：

| 操作需求 | 使用工具 | 说明 |
|---------|---------|------|
| 查看子表布局 | `+sheet-info` | 获取行高、列宽、隐藏行列、行列分组、合并单元格、冻结等布局信息 |

注意：

- 当表格存在合并单元格时，应结合返回的 `merged_cells` 判断表头、分组标题和区域语义
- 不要把合并区域中非左上角的空白单元格理解为"无内容"；通常应将左上角单元格的内容视为整个合并区域的语义内容
- 要识别隐藏行列（以决定是否过滤、或如何解读混入的隐藏数据），用 `+sheet-info --include hidden_rows,hidden_cols` 取隐藏行列集合，再结合 `+csv-get` / `+cells-get`（见 `lark-sheets-read-data`）返回的 `row_indices` / `col_indices` 判断每行 / 每列是否隐藏

## Shortcuts

| Shortcut | Risk | 分组 |
| --- | --- | --- |
| `+sheet-info` | read | 工作表 |

## Flags

### `+sheet-info`

_公共四件套 · 系统：`--dry-run`_

| Flag | Type | 必填 | 说明 |
| --- | --- | --- | --- |
| `--include` | string_slice | optional | 要返回的结构信息类别，逗号分隔多个（可选值：`merges` / `row_heights` / `col_widths` / `hidden_rows` / `hidden_cols` / `groups` / `frozen`） |
| `--range` | string | optional | 限定只返回该 A1 范围的结构信息；省略时返回整表 |

## Examples

公共四件套：所有 shortcut 顶部排列 `--url` / `--spreadsheet-token` / `--sheet-id` / `--sheet-name`（XOR）。

### `+sheet-info`

```bash
# 读子表的合并区 + 行高 + 冻结信息
lark-cli sheets +sheet-info --url "https://example.feishu.cn/sheets/shtXXX" \
  --sheet-id "$SID" --include merges,row_heights,frozen
```

输出契约：返回子表的行高 / 列宽 / 隐藏 / 合并 / 分组 / 冻结等布局元信息。

### Validate / DryRun / Execute 约束

- `Validate`：XOR 公共四件套；`--range` 必须是合法 A1 范围。
- `DryRun`：输出请求模板，零网络副作用。
- `Execute`：发起子表结构查询。
