# Theme: Terminal Green

**Vibe:** Developer-focused, hacker aesthetic, authentic

**Best For:** Dev tools, APIs, CLI products

**Typography:**
- All: `JetBrains Mono` (400/700) — monospace only

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=JetBrains+Mono:wght@400;700&display=swap');

:root {
  --font-display: 'JetBrains Mono', monospace;
  --font-sans: 'JetBrains Mono', monospace;
  --font-mono: 'JetBrains Mono', monospace;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
  --font-mono: var(--font-mono);
}
```
_全主题一个字体，`font-mono` / `font-display` / 默认都渲染 JetBrains Mono。_

**Theme CSS:**
```css
[data-ppt-theme="terminal-green"] {
  --ppt-bg: #0d1117;
  --ppt-bg-secondary: #161b22;
  --ppt-text: #00ff00;
  --ppt-text-secondary: #7ee787;
  --ppt-text-dim: #238636;
  --ppt-border: #30363d;
}
```

**Key Tailwind Classes:**
```tsx
// Terminal look
className="bg-[var(--ppt-bg)] font-mono text-[var(--ppt-text)]"

// Code block style
className="bg-[var(--ppt-bg-secondary)] border border-[var(--ppt-border)] rounded-lg p-4"

// Blinking cursor effect (use Framer Motion)
className="inline-block w-3 h-6 bg-[var(--ppt-text)] animate-pulse"
```

**Signature Elements:**
- Monospace everything
- Green-on-black terminal aesthetic
- Code block styling throughout
- Command prompt decorations ($ or >)
