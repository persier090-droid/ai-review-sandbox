import {moneyText} from './review-feasibility.mjs';

const round=value=>Math.round(value*10)/10;
const grades=['存在阻塞','重大条件待解决','有条件可验证','提交方案较明确','独立实证支持'];
const criterion={
  value:'仅有案例收益假设为1档；提交现状或目标为2档；同时说明对象、现状与目标为3档。收益仍须实测。',
  experience:'可追踪的操作与退出候选方案为2档；提交对象、成功和停止条件为3档。不能把入口可用当成任务完成。',
  technical:'案例有实现路径与依赖为2档；提交工作量及验证方法为3档。现场兼容与性能尚待验证。',
  investment:'费用或预算缺失为待评；明确超预算为0档；费用区间可能超预算为1档；已列费用在预算内为3档。小计不代表完整报价。',
  risk:'已知危险或费用口径冲突为0档；高风险候选为1档；有反例与处置建议为2档；提交停止条件及范围约束为3档。',
  validation:'案例有对照与反证方法为2档；提交方法、成功和停止条件为3档。计划和实际结果分别记录。'
};

// These are explicit ordinal product rules, not a learned prediction of business value.
// Unknown dimensions are excluded from the mean and remain visible in its coverage.
export function assessComprehensive(review,{reference:ref,feasibility:f,pending=false}) {
  const factors=f.factors,dimensions=[];
  const inputSource=text=>text?{kind:'input',label:'本轮提交，未独立核验',quote:text}:null;
  const caseSource=text=>ref&&text?{kind:'case',label:`${ref.case_id} 案例建议，待确认适用`,quote:text}:null;
  const owners=keys=>keys.map(key=>review.roles?.find(r=>r.key===key)?.name || ({pd:'产品经理',sales:'销售/售前',h5:'H5/前端开发',client:'客户端研发',server:'服务端研发',project:'项目实施',op:'运营',test:'测试工程师',service:'售后运维'}[key]+'（待确认责任人）'));
  const add=(key,name,weight,rating,judgment,constraint,next_action,roles,sources)=>{
    const activeRating=pending?null:rating;
    dimensions.push({key,name,weight,rating:activeRating,status:activeRating===null?'待评':grades[activeRating],
      points:activeRating===null?null:weight*activeRating/4,judgment,constraint,next_action,
      owners:owners(roles),sources:sources.filter(Boolean),criterion:criterion[key]});
  };
  const flow=ref?.scenario?.business_flow?.[0];
  const actor=factors.audience || ref?.actor;
  const valueReady=factors.audience&&factors.problem&&factors.goal;
  add('value','需求价值',25,valueReady?3:factors.problem||factors.goal?2:ref?1:null,
    valueReady?`本次要解决“${factors.problem}”，目标是“${factors.goal}”。有明确验证对象，可与不改动的方案比较。`:ref?ref.reasoning:'尚无法判断这项改动解决谁的什么问题，先确定现有做法及不做的影响。',
    factors.problem?'提交的现状还需核对来源、发生频率及代表性；目标不等于已实现收益。':'案例只能说明可能的价值，不能证明本项目有足够需求或值得投入。',
    `由${ref?.actor || '需求提出者'}提供当前做法和一次具体问题记录，比较保持现状与候选方案的收益及代价。`,['pd','sales'],[inputSource(factors.problem),inputSource(factors.goal),caseSource(ref?.reasoning)]);
  add('experience','使用体验',15,actor&&factors.success&&factors.stop?3:flow?2:null,
    flow?`${flow.actor}要完成“${flow.action}”；体验重点是“${flow.expected}”，同时保留退出和原流程恢复。`:factors.success?`按“${factors.success}”检查任务结果，同时核对中断、退出和重新进入。`:'需要明确操作发起人、完成结果，以及取消或失败后回到哪里。',
    ref?.challenge || '正常路径成功不能替代拒绝、误操作、中断及恢复检查。',
    '按实际操作者走一遍正常、取消、超时和重进路径，记录是否需要员工介入以及原任务是否受影响。',['h5','test'],[caseSource(flow?.action),inputSource(factors.success),inputSource(factors.stop)]);
  const dependencies=ref?.scenario?.context?.assets || [];
  add('technical','技术可行性',20,f.cost.workload.length&&factors.method?3:ref?.reply&&dependencies.length?2:null,
    ref?`候选路径：${ref.reply}`:f.cost.workload.length?`已拆解${f.cost.workload.map(w=>w.quote).join('、')}；需要用提交的验证方法检查技术依赖。`:'尚未定位实现链路，不能直接承诺工期或兼容范围。',
    dependencies.length?`先核对${dependencies.join('、')}。案例中可行的路径不代表当前版本已经支持。`:'需列系统接口、数据状态、环境限制及失败恢复，不以人日估算证明技术可行。',
    ref?.verify || factors.method || '技术岗位列最小改动、依赖和回退方案，先验证最可能失败的一条链路。',ref?.roles?.filter(k=>['client','server','h5'].includes(k)).length?ref.roles.filter(k=>['client','server','h5'].includes(k)):['project','test'],
    [caseSource(ref?.reply),caseSource(dependencies.join('、')),inputSource(f.cost.workload.map(w=>w.quote).join('；')),inputSource(factors.method)]);
  const over=f.cost.budget_status==='超出已列预算',uncertain=f.cost.budget_status==='估算区间可能超预算';
  const costConflict=f.blockers.some(b=>b.key==='cost_conflict');
  const costReady=f.cost.estimate&&f.cost.budget;
  add('investment','投入合理性',15,costConflict||over?0:costReady?uncertain?1:3:null,
    costReady?`已列一次性费用${moneyText(f.cost.estimate)}，预算${moneyText(f.cost.budget)}：${f.cost.budget_status}。`:`一次性费用${moneyText(f.cost.estimate)}，${f.cost.budget?'预算'+moneyText(f.cost.budget):'预算待确认'}；暂不能判断投入是否合算。`,
    `月度持续费用${moneyText(f.cost.recurring_monthly)}；未列费用不视为零，预算不替代报价，也不能直接推算回本周期。`,
    over||uncertain?'按必要功能缩小试验范围，重新估算并由提出者确认预算。':'补齐岗位人日、单价、外部费用、持续维护和预算承担方，再比较最小方案与不做方案。',['project','op'],
    [...f.cost.basis.map(b=>inputSource(b.quote)),inputSource(f.cost.budget?.quote)]);
  const hard=f.blockers.length>0;
  add('risk','风险可控性',15,hard?0:factors.stop&&factors.boundary?3:ref?.scenario?.artifacts?.risk?.level==='高'?1:ref?.overturn?2:null,
    hard?f.blockers.map(b=>b.reason).join('；'):ref?.scenario?.artifacts?.risk?.text || factors.stop || '尚未明确最坏结果及可接受边界，不能按“没有报错”认定低风险。',
    hard?'先消除明确阻塞，其他维度高分不能抵消。':ref?.overturn || '风险未发生与未测试不同；停止条件需要对应实际业务影响。',
    hard?f.blockers.map(b=>b.action).join('；'):ref?.overturn || factors.stop || '按影响范围、恢复能力和暴露条件排序，先验证不可逆或会影响原流程的风险。',['test','service'],
    [caseSource(ref?.overturn),inputSource(factors.stop),inputSource(factors.boundary),...f.blockers.map(b=>inputSource(b.quote))]);
  const validationReady=factors.method&&factors.success&&factors.stop;
  add('validation','验证设计',10,validationReady?3:ref?.verify&&ref?.accept&&ref?.overturn?2:null,
    factors.method || ref?.verify || '目前没有能区分有效和无效的试验方案，需要先确定对照与观察对象。',
    `${f.evidence.status}。样本量、阈值和周期需要试验前确定，不能看完结果再调整。`,
    `成功：${factors.success || ref?.accept || '待定义'}；停止：${factors.stop || ref?.overturn || '待定义'}`,['test','pd'],
    [inputSource(factors.method),inputSource(factors.success),inputSource(factors.stop),caseSource(ref?.verify)]);
  const assessed=dimensions.filter(d=>d.rating!==null);
  const coverage=assessed.reduce((n,d)=>n+d.weight,0),points=assessed.reduce((n,d)=>n+d.points,0);
  const score=coverage?round(points/coverage*100):null;
  const blockers=[...f.blockers.map(b=>b.reason),...(over?['已列费用超出验证预算']:[])];
  const recommendation=pending?'先确认变更范围':hard?'暂停当前方案，先消除阻塞':over?'缩小验证范围或重新确认预算':uncertain?'先核实成本区间，再决定试验投入':!coverage?'先澄清需求':!valueReady?'先验证需求价值，再确定试验投入':!costReady?'方案可进入验证准备，先确认成本与预算':!validationReady?'补齐成功与停止条件后再开展试验':'建议开展受控小范围验证，暂不扩大投入';
  return {version:'comprehensive-v1',label:'综合研判',score,coverage,interval:{min:round(points),max:round(points+100-coverage)},dimensions,blockers,recommendation,
    focus:dimensions.filter(d=>d.rating===null||d.rating<2).sort((a,b)=>(a.rating??-1)-(b.rating??-1)||b.weight-a.weight).slice(0,3).map(d=>({key:d.key,name:d.name,action:d.next_action,owners:d.owners})),
    confidence:f.evidence.observed_count?'有回填记录，真实性与适用性待复核':'低：尚无本轮实证',
    formula:'已评项综合分 = Σ(权重 × 档位 / 4) ÷ 已评权重 × 100；未知项不进入均值，全量区间按未知项0至满分展开，并非统计置信区间。',
    scope:'候选方案的规则研判，非实时模型判断、成功概率或上线分；案例只支持条件性分析。权重尚未做现场统计校准，4档需独立实证，当前不自动授予。',release_authorized:false};
}
