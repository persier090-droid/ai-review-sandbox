import fs from 'node:fs';
import test from 'node:test';
import assert from 'node:assert/strict';
import {localCrossChecks,referenceConversation} from './review-local-reference.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import * as preliminary from './review-preliminary.mjs';

const bank=JSON.parse(fs.readFileSync(new URL('./evaluation/ktv-innovation-60.json',import.meta.url),'utf8')).cases;

test('all 60 cases support scored preliminary decisions without manufacturing real evidence',()=>{
  assert.equal(typeof preliminary.assessPreliminary,'function');
  for(const item of bank) {
    const review={scene:'ktv',requirement:item.title+' '+item.question,roles:ROLE_PERSONAS};
    const result=preliminary.assessPreliminary(review);
    assert.equal(result.case_id,item.id);
    assert.ok(Number.isFinite(result.score)&&result.score>=0&&result.score<=100);
    assert.equal(result.score,result.dimensions.reduce((n,d)=>n+d.earned,0));
    assert.ok(result.necessity&&result.cost.items.length&&result.validation.method&&result.validation.stop_when);
    assert.equal(result.cost.estimate,null);
    assert.equal(result.release_authorized,false);
    assert.ok(result.dimensions.flatMap(d=>d.checks).every(c=>c.points>=0&&c.points<=c.weight&&c.source));
  }
});

test('unmatched and superseded inputs are not scored from unrelated or stale cases',()=>{
  assert.equal(typeof preliminary.assessPreliminary,'function');
  const base={scene:'ktv',requirement:bank[0].question,roles:ROLE_PERSONAS};
  const unknown=preliminary.assessPreliminary({...base,requirement:'火星探矿',local_references:localCrossChecks(base)});
  assert.equal(unknown.case_id,null);
  assert.ok(unknown.score<60);
  assert.equal(unknown.recommendation,'先澄清需求');
  const other=preliminary.assessPreliminary({...base,scene:'saas'});
  assert.equal(other.case_id,null);
  const changed=preliminary.assessPreliminary({...base,inputs:[base.requirement,'不做数字人，改成火星探矿'],effective_scope:{status:'resolved'},effective_requirement:'火星探矿'});
  assert.equal(changed.case_id,null);
  const pending=preliminary.assessPreliminary({...base,inputs:[base.requirement,'取消数字人，改做其他功能'],effective_scope:{status:'pending'}});
  assert.equal(pending.recommendation,'先确认变更范围');
  assert.equal(pending.case_id,null);
  assert.ok(pending.score<60);
});

test('preliminary points respond to explicit constraints without upgrading them to verified facts',()=>{
  const base={scene:'ktv',requirement:bank[0].question,roles:ROLE_PERSONAS};
  const before=preliminary.assessPreliminary(base);
  const after=preliminary.assessPreliminary({...base,requirement:base.requirement+'；现状：消费者投诉舞台氛围单调；预算500元，工期2人日；首期只做可关闭的伴舞'});
  assert.ok(after.score>before.score);
  assert.ok(after.score<=100);
  assert.equal(after.cost.estimate,null);
  assert.equal(after.release_authorized,false);
  assert.match(after.cost.constraint,/预算500元/);
  assert.ok(after.dimensions[0].checks.some(c=>c.source==='提交内容（未独立核验）'));
});

test('all 60 local cases retain their sources and produce separate attributed discussion turns',()=>{
  for(const item of bank) {
    const ref={...item,case_id:item.id};
    const original=JSON.stringify(ref);
    const turns=referenceConversation(ref,ROLE_PERSONAS);
    assert.equal(turns.length,4,item.id);
    assert.ok(turns.every(t=>t.text.trim()&&ROLE_PERSONAS.some(r=>r.key===t.role)));
    assert.ok(turns.every(t=>!/(反驳点|参考回应|验证办法|通过条件|推翻条件|适用前提)：/.test(t.text)));
    assert.ok(turns.every(t=>t.reference.case_id===item.id&&t.reference.evidence===item.evidence));
    assert.ok(turns.every(t=>t.reference.source==='本地参考，非模型实时生成'));
    assert.equal(JSON.stringify(ref),original);
    const restricted=referenceConversation(ref,[{key:'custom_accessibility'}]);
    assert.ok(restricted.every(t=>t.role==='facilitator'),'unselected experts must not be impersonated');
  }
});

test('matching attaches the correct scenario foundation without treating it as established fact',()=>{
  for(const item of bank) {
    const refs=localCrossChecks({scene:'ktv',requirement:item.title+' '+item.question,roles:ROLE_PERSONAS});
    const ref=refs.find(r=>r.case_id===item.id);
    assert.ok(ref,`${item.id} must be retrievable by its own question`);
    assert.equal(ref.scenario.case_id,item.id);
    assert.equal(ref.scenario.validation.execution.status,'未执行');
    assert.deepEqual(ref.scenario.context.known_facts,[]);
  }
  assert.deepEqual(localCrossChecks({scene:'saas',requirement:bank[0].question,roles:ROLE_PERSONAS}),[]);
});
