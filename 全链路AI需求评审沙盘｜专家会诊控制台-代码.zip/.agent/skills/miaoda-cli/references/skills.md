---
name: miaoda-skills
description: 当需要把本地 .agent/steering/<stack>/ 同步到最新（或指定版本）的 coding-steering，或者想查看当前装了哪些 skill 时使用。`miaoda app init` 会一次性装上，此命令用于后续单独刷新。
---

# miaoda skills

本地 agent skills（含 steering）维护：

- `skills sync [version]`：把 coding-steering 同步到 `.agent/steering/<stack>/`
- `skills status`：查看当前装了哪些 skill / `tech.md` 是否在

> 完整 flag 见 `miaoda skills <command> --help`。

## 何时使用

✅ 用户说"刷新 / 更新 steering"、"装最新的 skills"
✅ 升级到某个 coding-steering 版本（事故止血或回滚）
✅ 看一眼当前 `.agent/steering/` 里有什么

❌ 改业务代码 / 改 template → 用对应工具
❌ 想要不一样的 stack 的 skills → 先改 `.spark/meta.json.stack`（通常意味着重新 init）

## 前置要求

- 当前目录（或 `--dir`）已走过 `miaoda app init`，`.spark/meta.json` 含 `stack` 字段（sync 会从这里读）
- `status` 不需要 meta，纯本地扫描

## sync

```bash
miaoda skills sync              # 拉 latest
miaoda skills sync 0.2.0        # pin 到指定版本或 dist-tag
miaoda skills sync --dir ./app  # 项目不在当前目录
```

**行为**：根据 meta.stack 决定要拉哪一组 skills，全部落到 `.agent/steering/<stack>/`。`_common/skills/` 先拷到 `<stack>/skills/`，再用 stack 自己的 `<stack>/skills/` 覆盖同名条目。`tech.md` 存在则同步到 `.agent/steering/<stack>/tech.md`。

**JSON 输出**：

```json
{
  "data": {
    "stack": "vite-react",
    "version": "0.2.0",
    "syncedSkills": ["_common/skills/...", "vite-react/skills/..."],
    "techSynced": true
  }
}
```

## status

```bash
miaoda skills status
```

**JSON 输出**：

```json
{
  "data": {
    "stack": "vite-react",
    "present": true,
    "skills": ["coding-guide", "react-hook-best-practices"],
    "techSynced": true
  }
}
```

`stack` 直接读自 `.spark/meta.json`；meta 缺 stack 时 `stack=null` 且 `present=false`，提示用户先 `miaoda app init`。`present=false` 而 stack 存在则意味着没装过，提示 `miaoda skills sync`。
