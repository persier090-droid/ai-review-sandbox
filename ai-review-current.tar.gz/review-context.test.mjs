import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {selectAssertions, loadRoleSkill} from './expert-skills.mjs';
import {buildContext, sceneKey} from './review-context.mjs';
import {resolveScope} from './review-scope.mjs';

test('scene-specific knowledge does not leak from KTV to SaaS', () => {
  assert.equal(sceneKey('企业SaaS后台｜云端业务'),'saas');
  assert.ok(selectAssertions([{key:'test'}],'高峰并发','KTV点歌机').length);
  assert.deepEqual(selectAssertions([{key:'test'}],'高峰并发','企业SaaS后台'),[]);
  assert.doesNotMatch(loadRoleSkill('test','企业SaaS后台'),/KTV|包厢/);
});

test('supervised experience persists, can be withdrawn and is retrieved only for a relevant scene and topic', t => {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'review-memory-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const store=new ReviewStore(dir);
  store.save({id:'one',scene:'KTV点歌机',requirement:'数字人舞蹈低端设备',revision:1,predictions:[]});
  const saved=store.learn('one',{text:'低端设备应先实测舞蹈渲染',evidence:'人工确认：门店测试记录',kind:'经验'});
  const fresh=new ReviewStore(dir);
  assert.equal(fresh.learning('KTV点歌机','数字人舞蹈').length,1);
  assert.equal(fresh.learning('车载智能终端','数字人舞蹈').length,0);
  assert.equal(fresh.learning('KTV点歌机','合同签约').length,0);
  assert.equal(saved.learning[0].status,'confirmed');
  fresh.learn('one',{item_id:saved.learning[0].id,action:'withdraw'});
  assert.equal(fresh.learning('KTV点歌机','数字人舞蹈').length,0);
  assert.equal(fresh.get('one').learning[0].text,'低端设备应先实测舞蹈渲染');
});

test('bounded context retains original scope, latest update, closure and evidence without rewriting the transcript', () => {
  const review={requirement:'仅做数字人舞蹈',inputs:['仅做数字人舞蹈','纠正：不增加付费'],messages:Array.from({length:80},(_,i)=>({text:'内容'+i})),scene:'KTV',challenges:[],responses:[],conflicts:[]};
  const before=structuredClone(review);
  const context=buildContext(review,{closure:{summary:'本轮暂缓'}},[{text:'已确认经验'}]);
  assert.equal(context.scope.original,'仅做数字人舞蹈');
  assert.equal(context.latest_input,'纠正：不增加付费');
  assert.ok(context.messages.length<=24);
  assert.equal(context.previous_closure.summary,'本轮暂缓');
  assert.equal(context.supervised_memory[0].text,'已确认经验');
  assert.deepEqual(review,before);
});
test('scope mapping rejects revived cancellations and silently discarded constraints',()=>{
  const original='使用摄像头生成舞蹈，视频不得上传云端。',change='取消使用摄像头生成舞蹈，只播放现有授权角色。';
  const previous={requirement:original,inputs:[original],effective_scope:{status:'resolved',active:[{quote:original}],retired:[]}};
  const current={requirement:original,inputs:[original,change],revision:2};
  assert.throws(()=>resolveScope(current,{active_quotes:['使用摄像头生成舞蹈','只播放现有授权角色'],retired_quotes:[],change_quote:change},previous),/取消|撤销/);
  assert.throws(()=>resolveScope(current,{active_quotes:['只播放现有授权角色'],retired_quotes:['使用摄像头生成舞蹈'],change_quote:change},previous),/遗漏/);
  resolveScope(current,{active_quotes:['只播放现有授权角色','视频不得上传云端'],retired_quotes:['使用摄像头生成舞蹈'],change_quote:change},previous);
  assert.match(current.effective_requirement,/不得上传云端/);
  const extra='增加关闭按钮。';
  const third={requirement:original,inputs:[original,change,extra],revision:3};
  assert.throws(()=>resolveScope(third,{active_quotes:['使用摄像头生成舞蹈','只播放现有授权角色','视频不得上传云端','增加关闭按钮'],retired_quotes:[],change_quote:extra},current),/撤销/);
  resolveScope(third,{active_quotes:['只播放现有授权角色','视频不得上传云端','增加关闭按钮'],retired_quotes:[],change_quote:extra},current);
  assert.ok(third.effective_scope.retired.some(r=>r.quote==='使用摄像头生成舞蹈'));
});
