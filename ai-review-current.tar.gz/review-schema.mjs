const object=properties=>({type:'object',properties,required:Object.keys(properties),additionalProperties:false});
const examples={
  references:{id:'',quote:'',source:'',usage:'',scenario:''},
  predictions:{metric:'',value:0,unit:'',operator:'',tolerance:0,owner:'',verify_by:'',method:'',assumption:'',assertion_ids:[]},
  conflicts:{id:'',type:'',parties:[],topic:'',a_position:'',b_position:'',evidence:'',escalation_level:1,resolution:'',decider:'',minority_opinion:'',review_trigger:''},
  risks:{text:'',level:'',category:'',owner:''}
};

function schema(value,path='') {
  const name=path.split('.').at(-1);
  if(Array.isArray(value)) {
    const example=path.includes('.deliverables.')?{text:'',scope_quote:''}:value[0] ?? examples[name] ?? '';
    return {type:'array',items:schema(example,path+'.item'),maxItems:['questions','responses','acknowledgements'].includes(name)?2:name==='risks'?3:20};
  }
  if(value&&typeof value==='object') {
    const properties=Object.fromEntries(Object.entries(value).map(([k,v])=>[k,schema(v,path+'.'+k)]));
    if(path.endsWith('.basis.item'))properties.source_id={type:'string',maxLength:120};
    return object(properties);
  }
  if(typeof value==='boolean')return {type:'boolean'};
  if(typeof value==='number')return {type:name==='escalation_level'?'integer':'number'};
  const enums={stance:['支持','有条件','反对'],decision:['通过','有条件通过','不通过','延期'],level:['high','mid','low'],impact_tag:['阻塞','待澄清','建议'],review_type:['requirement','solution','delivery','quality','retrospective'],kind:['input','verified_assertion','observation']};
  if(enums[name])return {type:'string',enum:enums[name]};
  if(path.endsWith('.stance_conditions.item'))return {type:'string',minLength:6,maxLength:2000};
  return {type:'string',maxLength:/quote/.test(name)?5000:['id','question_id','source_id','role','responder','asker','target'].includes(name)?120:2000};
}

// Constrained output bounds syntax and batch size; evidence and decision checks
// remain in the runtime, since a JSON schema cannot certify an opinion.
export function batchResponseFormat(template,{quotes=[],premises=[],opinions=[],requireQuestion=false}={}) {
  const variants=template.stages.map(stage=>{
    const item=schema(stage);
    item.properties.phase={type:'string',const:stage.phase};
    if(stage.role) {
      item.properties.role={type:'string',const:stage.role};
      item.properties.output.properties.role={type:'string',const:stage.role};
    }
    const bind=(node,path='')=>{
      const field=path.split('.').at(-1);
      const allowed=field==='scope_quote'?quotes:field==='evidence_quote'||path.endsWith('.basis.item.quote')?[...quotes,...premises]:[];
      if(allowed.length) {node.enum=[...new Set(allowed)];delete node.maxLength;}
      if(field==='no_questions_reason')node.minLength=6;
      for(const [name,child] of Object.entries(node.properties || {}))bind(child,path+'.'+name);
      if(node.items)bind(node.items,path+'.item');
    };
    bind(item);
    if(stage.phase==='ROUND_ASK'&&requireQuestion)item.properties.output.properties.questions.minItems=1;
    if(stage.phase==='CONVERGE'&&opinions.length) {
      const audits=item.properties.output.properties.opinion_checks;
      const prototype=audits.items;
      audits.minItems=audits.maxItems=opinions.length;
      audits.items={anyOf:opinions.map(opinion=>{
        const variant=structuredClone(prototype);
        variant.properties.role={type:'string',const:opinion.role};
        variant.properties.claim_quote={type:'string',enum:[opinion.text]};
        variant.properties.basis_quote={type:'string',enum:[...new Set(opinion.analysis.basis.map(b=>b.quote))]};
        return variant;
      })};
    }
    return item;
  });
  return {type:'json_schema',json_schema:{name:'review_batch',strict:true,schema:object({
    package_id:{type:'string',const:template.package_id},
    version:{type:'integer',const:1},
    stages:{type:'array',items:variants.length===1?variants[0]:{anyOf:variants},minItems:variants.length,maxItems:variants.length}
  })}};
}
