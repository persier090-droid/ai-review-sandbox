import fs from 'node:fs';
import path from 'node:path';

export const DEEPSEEK_MODEL='deepseek-flash';
export const DEEPSEEK_URL='https://api.deepseek.com';

export function createHybridCaller({free,paid,enabled=false,notify=()=>{}}) {
  let switched=false,paidCalls=0;
  const call=async(prompt,signal,options)=>{
    signal?.throwIfAborted();
    if(!switched)try{return await free(prompt,signal,options);}catch(error){
      signal?.throwIfAborted();
      const unavailable=[401,403,404,408,429,500,502,503,504].includes(error.status)||['FREE_CIRCUIT_OPEN','FREE_QUOTA_INSUFFICIENT','REVIEW_BUDGET','OPENROUTER_AUTH'].includes(error.code)||['TimeoutError','TypeError'].includes(error.name);
      if(!enabled||!unavailable)throw error;
      switched=true;notify({type:'recovery',status:'paid_fallback',model:DEEPSEEK_MODEL,message:'免费模型暂不可用，切换DeepSeek计费API；保留当前阶段与原始意见，受本机累计预算限制'});
    }
    paidCalls++;return paid(prompt,signal,options);
  };
  call.stats=()=>({active_provider:switched?'deepseek':'openrouter',paid_calls:paidCalls,free:free.stats?.()});
  return call;
}

export function buildDeepSeekRequest({apiKey,model=DEEPSEEK_MODEL,messages,maxTokens=8192}) {
  if(model!==DEEPSEEK_MODEL)throw new Error('DeepSeek当前仅适配deepseek-flash，其他模型需重新核对价格与协议');
  return {url:`${DEEPSEEK_URL}/chat/completions`,headers:{'content-type':'application/json',authorization:`Bearer ${apiKey}`},
    body:JSON.stringify({model,messages,stream:true,stream_options:{include_usage:true},max_tokens:Math.max(1,Math.min(8192,Number(maxTokens)||8192)),thinking:{type:'disabled'},temperature:0.2,response_format:{type:'json_object'}})};
}

// Reserve a conservative peak-rate estimate before sending. Reservations are not
// refunds or bills: failed/uncertain requests remain reserved across restarts.
export function createDeepSeekBudget({apiKey,allowPaid=false,limitCny=0,filename,now=Date.now}) {
  const limit=Number.isFinite(Number(limitCny))&&Number(limitCny)>0?Math.floor(Number(limitCny)*1e6):0;
  let reserved=0,damaged=false;
  const receipts=new WeakSet();
  const reload=()=>{
    if(!filename)return;
    if(!fs.existsSync(filename)){if(reserved>0)damaged=true;return;}
    try {const value=JSON.parse(fs.readFileSync(filename,'utf8'));if(value.version!==1||value.currency!=='CNY'||!Number.isSafeInteger(value.reserved_micros)||value.reserved_micros<0)throw Error();reserved=value.reserved_micros;}catch{damaged=true;}
  };
  const inspect=()=>{
    reload();
    const stale=now()>Date.parse('2026-10-21T00:00:00Z');
    const state=!apiKey?'auth_error':!allowPaid?'payment_disabled':damaged?'ledger_error':!limit?'budget_missing':stale?'pricing_expired':reserved>=limit?'budget_exhausted':'paid_ready';
    const messages={auth_error:'未配置DEEPSEEK_API_KEY；密钥仅能从创建时保存的原文取得',payment_disabled:'DeepSeek是计费API，当前仅免费策略禁止调用；尚未授权使用充值余额',ledger_error:'DeepSeek预算账本异常，请核对原始记录，不能自动清零',budget_missing:'尚未配置有效的DeepSeek累计预算上限',pricing_expired:'DeepSeek价格快照已过期，核对官方价格后才能继续',budget_exhausted:'DeepSeek累计预算已用完，已停止请求',paid_ready:`DeepSeek计费API · 本机累计预留${(reserved/1e6).toFixed(4)}元 / 上限${(limit/1e6).toFixed(2)}元；预留不是实际账单`};
    return {provider:'deepseek',model:DEEPSEEK_MODEL,configured:Boolean(apiKey),state,message:messages[state],free_only:false,inference_enabled:state==='paid_ready',limit_cny:limit/1e6,reserved_cny:reserved/1e6,remaining_cny:Math.max(0,limit-reserved)/1e6,billing:'paid',pricing_checked_at:'2026-09-21'};
  };
  const write=next=>{
    if(filename){const temp=filename+'.tmp';fs.writeFileSync(temp,JSON.stringify({version:1,currency:'CNY',reserved_micros:next,updated_at:new Date(now()).toISOString()}),{mode:0o600});fs.renameSync(temp,filename);}
    reserved=next;
  };
  const locked=work=>{
    let lock;
    if(filename){
      fs.mkdirSync(path.dirname(filename),{recursive:true});
      try {lock=fs.openSync(filename+'.lock','wx',0o600);}catch{throw Object.assign(new Error('DeepSeek预算账本正在使用或无法锁定；保留进度，请稍后重试'),{code:'DEEPSEEK_LEDGER_BUSY',status:403});}
    }
    try {return work();}finally{if(lock!==undefined){fs.closeSync(lock);fs.unlinkSync(filename+'.lock');}}
  };
  return {inspect,reserve(body){return locked(()=>{
    const status=inspect();
    if(status.state!=='paid_ready')throw Object.assign(new Error(status.message),{code:'DEEPSEEK_'+status.state.toUpperCase(),status:403});
    // Peak Flash price: input 2 CNY/M, output 8 CNY/M; ignore cache discounts.
    const inputBound=Buffer.byteLength(JSON.stringify(body.messages || []),'utf8')+4096;
    const outputBound=Math.min(8192,Number(body.max_tokens)||8192);
    const amount=Math.ceil(inputBound*2+outputBound*8);
    if(reserved+amount>limit)throw Object.assign(new Error('DeepSeek剩余预算不足以覆盖本次请求的保守预留；保留当前评审进度'),{code:'DEEPSEEK_BUDGET_EXHAUSTED',status:403});
    write(reserved+amount);
    const receipt=Object.freeze({micros:amount});receipts.add(receipt);return receipt;
  });},settle(receipt,usage){
    if(!receipts.has(receipt)||![usage?.prompt_tokens,usage?.completion_tokens].every(v=>Number.isSafeInteger(v)&&v>=0)||usage.prompt_tokens+usage.completion_tokens===0)return false;
    const peak=usage.prompt_tokens*2+usage.completion_tokens*8;
    if(peak>receipt.micros)return false;
    return locked(()=>{
      reload();if(damaged||reserved<receipt.micros)return false;
      write(reserved-receipt.micros+peak);receipts.delete(receipt);return true;
    });
  }};
}
