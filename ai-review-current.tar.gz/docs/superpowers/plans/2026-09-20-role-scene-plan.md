# Role and Scene Implementation Plan

Goal: Ship the approved role routing, actual skill injection and scene-specific gates through the existing review workflow.

Architecture: Pure modules build routing and acceptance policies. Existing runtime passes them to model stages; scoring and delivery share one evaluator. Human tracking records verification against a hash of scope and acceptance contract.

Tech Stack: Node ES modules, static HTML, node:test, existing Playwright scripts.

- [x] Add routing tests for KTV weak-network, SaaS isolation, unknown topics, absent roles and custom roles; implement `review-routing.mjs` without remote calls.
- [x] Add five-scene acceptance policy, evidence and stale-contract tests in `review-scene.test.mjs`; implement `review-scene.mjs` and structured DECISION fields.
- [x] Add batched prompt assertions; connect role skills, scene policies and routing in automatic, staged and manual paths. Add operations/service role files.
- [x] Integrate shared scene evaluation into score hard gates, risk gaps, tasks, PRD and evidence tracking. Preserve original source and existing role authority.
- [x] Add compact evidence details to existing assessment/tracking views, no additional conversation entry point.
- [x] Update isolated fixtures with explicit synthetic scene plans, add browser assertions for routing/scene details and run `node scripts/verify-release.mjs`.
- [x] Document policy limitations, verify source fingerprint, restart the local service after confirming idle. Do not use the real model quota.

Each implementation step starts with a failing test, then the smallest change and focused verification. No Git repository is available, so files remain reviewable in the workspace without commits. Existing user approval covers these scoped changes; no extra approval checkpoint is needed.

Verification: 105 tests passed; all eight pipeline stages passed, including desktop/mobile browser coverage and scene evidence submission. Real provider calls: zero. Runtime restarted on port 8000 after confirming all six saved reviews idle. Historical artifacts receive the current scene policy without rewriting original messages. Production model availability and semantic quality remain independently unverified.
