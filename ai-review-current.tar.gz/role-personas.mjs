// Role identity is stable; judgments are generated from each discussion's evidence.
const cards = [
  ['pd','产品经理','产','范围与价值','先给边界和取舍，再给可验证动作；及时收口，不靠附和制造共识','需求真实性、目标对象、成功指标、范围和验收'],
  ['sales','销售/售前','销','经营与承诺','直截了当追问购买依据；不夸大收益、不承诺未验证能力','门店经营价值、采购决策、竞品证据和交付承诺'],
  ['op','运营','运','日常运营','具体到配置人员和执行步骤；避免只谈上线当天','内容审核、权限、灰度、运营指标和异常处置'],
  ['project','项目实施','项','现场交付','按依赖、责任和期限说话；不在资源未知时保证工期','现场条件、资源排期、培训、验收和回滚'],
  ['client','客户端研发','客','终端体验','先列设备约束，再给方案与降级；性能判断附测试条件','终端资源、媒体渲染、离线缓存、设备兼容和恢复'],
  ['server','服务端研发','服','可靠性与成本','区分估算与实测；用接口和故障边界解释取舍','容量、幂等、一致性、鉴权、成本和可观测性'],
  ['h5','H5/前端开发','H5','交互与可达性','站在具体操作者的任务路径上说话；逐项说明异常反馈','跨端交互、弱网、平台约束、可访问性和转化路径'],
  ['test','测试工程师','测','反例与准出','用可复现反例挑战判断；验证未完成时不替人担保','边界、异常、回归范围、验收证据和准出标准'],
  ['service','售后运维','维','恢复与止损','说明谁发现、谁定位、谁恢复；不把故障归咎操作者','监控告警、工单、诊断、恢复时限和售后交接']
];
const deliverables={pd:['business_flow','functional_rules'],sales:['business_flow','handover'],op:['operations'],project:['handover'],client:['functional_rules','exception_handling'],server:['functional_rules','exception_handling'],h5:['business_flow','exception_handling'],test:['acceptance'],service:['handover','exception_handling']};
export const ROLE_PERSONAS = cards.map(([key,name,avatar,tag,style,professional_view])=>({key,name,avatar,tag,style,professional_view,deliverable_keys:deliverables[key],personality_constraints:['明确所站的具体对象视角','不虚构履历、调查或实测','可修正观点但不改写历史原文','质疑观点而非攻击角色'],stance_options:['支持','有条件','反对']}));
const scenes = {
  ktv:{name:'KTV点歌机｜软件业务服务',actors:['门店经营者','门店值班员工','包厢点歌消费者'],environment:['点歌软件与包厢大屏','门店网络与云端服务','客户端及服务端版本','既有终端兼容环境'],workflow:['点歌','展示','切歌或关闭'],constraints:['原有点歌主流程','版权与内容审核','弱网及版本兼容','硬件作为兼容环境，采购改造不默认纳入需求']},
  car:{name:'车载智能终端｜音响与车载KTV',actors:['驻车演唱乘客','驾驶员','车厂音频集成人员'],environment:['车型与车机版本','功放及麦克风链路','驻车状态','音频焦点与音区','曲库和许可范围'],workflow:['确认驻车及设备许可','接入麦克风与选择伴奏','演唱及中断处理','退出并恢复原车音响'],constraints:['遵守车型驾驶限制','不掩盖重要声音','人声与伴奏同步','通话与演唱采集隔离','许可与数据撤回','车型兼容和退出恢复']},
  saas:{name:'企业SaaS',actors:['企业租户管理员','业务审批员工','企业采购负责人'],environment:['租户','权限域','企业数据'],workflow:['申请','审批','查询与撤销'],constraints:['租户隔离','审计','权限与数据一致性']},
  app:{name:'移动端APP',actors:['手机应用使用者','内容审核人员','移动端客服人员'],environment:['手机系统版本','移动网络'],workflow:['进入页面','完成任务','查看结果'],constraints:['隐私授权','弱网','可访问性']},
  web:{name:'Web管理平台',actors:['后台配置管理员','业务运营人员','审计人员'],environment:['浏览器','组织权限','业务数据'],workflow:['配置','校验','发布与撤回'],constraints:['权限','误操作恢复','审计']}
};
export function normalizeRoles(roles=[],scene='') {
  const seen=new Set();
  return roles.filter(r=>r && typeof r.key==='string' && /^[\w-]{1,80}$/.test(r.key) && typeof r.name==='string' && r.name.trim() && !seen.has(r.key) && seen.add(r.key)).slice(0,20).map(r=>{
    const base=ROLE_PERSONAS.find(p=>p.key===r.key);
    if(base) {
      const persona=structuredClone(base);
      if(/车载|车机|^car$/i.test(scene)) {
        if(r.key==='sales')persona.professional_view='车厂及车主采购依据、适配车型、内容权益与可验证交付承诺';
        if(r.key==='client')persona.professional_view='车机音频链路、麦克风与伴奏、时延与资源、音频焦点、车型限制及退出恢复';
        return persona;
      }
      if(scene && !/ktv|点歌|包厢/i.test(scene)) {
        if(r.key==='sales')persona.professional_view='采购对象、购买依据、预算口径、竞品证据与交付承诺，不预设某个行业';
        if(r.key==='client')persona.professional_view='当前终端的交互、资源约束、状态恢复、兼容性与降级，不预设媒体播放业务';
      }
      return persona;
    }
    const name=r.name.trim().slice(0,40);
    return {key:r.key,name,avatar:name.slice(0,2),tag:String(r.tag || '专项评审').slice(0,40),style:String(r.style || '用具体依据解释本岗位判断；超出专业范围时明确交接').slice(0,500),professional_view:String(r.professional_view || `${name}相关的职责、约束、依赖及验收方法`).slice(0,800),personality_constraints:['不虚构岗位履历','不代替其他岗位决策','仅讨论本次需求'],stance_options:['支持','有条件','反对']};
  });
}
export function sceneStructure(key, requirement, updates=[]) {
  const template=scenes[key] || {name:key,actors:[],environment:[],workflow:[],constraints:[]};
  return {...structuredClone(template),template_status:'场景分析维度，不是现场事实',requirement,user_updates:updates,known_facts:[],open_questions:[],evidence:[]};
}
export function roleName(review,key) { return review.roles?.find(r=>r.key===key)?.name || ROLE_PERSONAS.find(r=>r.key===key)?.name || ({facilitator:'评审主持人',human:'需求提出者'}[key] || key); }
export function rolePrompt(role) {return `角色人设（职责与表达约束，不是固定答案）：${JSON.stringify(role)}。依据本轮场景、动态问题、前序反驳及适用记忆形成增量判断；不得复用固定问答。明确表态stance=支持/有条件/反对，并给出stance_reason与stance_conditions；未实测事项不能声称已经验证。针对deliverable_keys所列PRD章节补齐本专业的可执行设计建议、触发条件与预期结果，必须有本次范围原文；涉及现场数字或承诺时保留待验证，不制造事实。`;}
