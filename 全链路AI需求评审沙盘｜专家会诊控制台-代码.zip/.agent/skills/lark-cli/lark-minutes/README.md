# minutes (v1)

## 身份

所有 minutes 命令默认使用 `--as user`。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| [`+download`](references/lark-minutes-download.md) | 下载妙记音视频媒体文件 |

- 使用 Shortcut 前，必须先读其对应 reference 文档。

## 意图路由

| 用户意图 | 命令 |
|---------|------|
| 下载妙记音视频文件、获取媒体下载链接 | `+download` |
| 妙记基础信息：标题 / 时长 / 封面 / 链接 / 所有者 | `minutes minutes get` |

## 核心概念

- **妙记（Minutes）**：来源于飞书视频会议的录制产物或用户上传的音视频文件，通过 `minute_token` 标识。
- **妙记 Token（minute_token）**：妙记的唯一标识符，可从妙记 URL 末尾提取（如 `https://*.feishu.cn/minutes/obcnxxx` 中的 `obcnxxx`）。如果 URL 中包含额外参数（如 `?xxx`），截取路径最后一段。

## 核心场景

### 查看妙记基础信息

1. 当用户只需要确认某条妙记的标题、封面、时长、所有者、URL 等基础信息时，使用 `minutes minutes get`。
2. 从妙记 URL 末尾提取 `minute_token`，再调用 `minutes minutes get`。
3. 用户意图不明确时，默认先给基础元信息，帮助确认是否命中目标妙记。

### 下载妙记音视频文件

下载妙记的录音 / 录像媒体文件，或获取有效期 1 天的下载链接（只读操作）。使用前必须先阅读 [references/lark-minutes-download.md](references/lark-minutes-download.md)。

## API Resources

沙箱内本域仅以下原生 API 可用：

```bash
lark-cli minutes <resource> <method> [flags]
```

### minutes

- `get` — 获取妙记信息

> **权限错误**：如果返回 `[2091005] permission deny`，表示用户没有对应妙记文件的阅读权限，需提示用户联系妙记 owner 申请权限。
