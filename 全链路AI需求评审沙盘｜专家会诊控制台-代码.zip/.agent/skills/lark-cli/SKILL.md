---
name: lark-cli
description: "在妙搭沙箱里用 lark-cli 对飞书/Lark 非 apps 域做白名单内只读或受限操作：日历日程/忙闲/会议室推荐(calendar)、通讯录按姓名邮箱搜人(contact)、云文档读取与按关键词搜文档与历史版本(docs)、云盘文件列表与按关键词搜云空间文件/评论/访问记录(drive)、IM 群聊列表/成员/搜索(im)、妙记音视频下载(minutes)、电子表格读取(sheets)、幻灯片读取与历史(slides)、任务与清单查询(task)、画板导出(whiteboard)、知识库空间与节点(wiki)、多维表格读取——数据表/字段/视图配置/记录与按关键词搜记录(base)、会议录制信息——回看链接/时长/关联妙记(vc)。当用户要查看/读取/搜索/下载/导出这些飞书资源的内容时使用；命令通道一律是 lark-cli 的非 apps 域。用户消息里出现飞书资源链接就属于本 skill 的场景——链接域名同时存在 feishu.cn / feishu-boe.cn / larkoffice.com / doubao.com 多种环境，路由只看路径与 token 形态、不看域名；这类链接无法用 web_fetch 或浏览器读取，必须走本 skill。触发词：飞书文档, 云文档, 飞书链接, 文档链接, 电子表格, 表格链接, 多维表格, Base, bitable, 维表, 知识库, wiki 空间, 节点, 妙记, 会议纪要, 逐字稿, 日程, 忙闲, 排期, 通讯录, 找人, 群聊, 群消息, 置顶消息, 表情回复, 任务清单, 待办, 画板, 白板, 幻灯片, 云空间, 我的云盘, 文件夹, 会议录制, /docx/, /sheets/, /base/, /wiki/, /slides/, /minutes/, /drive/folder/, feishu.cn, feishu-boe.cn, larkoffice.com。NOT for 妙搭应用操作（走 lark-apps 系列 skill）、未列出的域、以及各域未开放的写/管理命令（本沙箱屏蔽的能力不要拼）；也 NOT for 用插件（plugin / capabilityClient / CapabilityService）读取飞书资源——插件只用于生成出来的应用在运行时访问飞书，Agent 在生成期读取内容一律用 bash 调 lark-cli。"
metadata:
  requires:
    bins: ["lark-cli"]
  cliHelp: "lark-cli --help; lark-cli <domain> --help"
require-knowledge-sources:
  - lark_cli
control-by-feature-ab: true
---

# lark-cli（非 apps 域）· 沙箱版

在妙搭沙箱里通过 `lark-cli` 对飞书/Lark 资源做**白名单内只读或受限操作**的入口 skill，按域拆分为 13 个子文档，本文件只做沙箱约定与意图路由。

## 沙箱约定（先读）

> 本约定块只出现在本根 SKILL.md 一份，13 个域共用；
> 子域 `lark-<域>/README.md` 不重复本块。

- **命令名**：一律 `lark-cli <域> +<cmd>`（快捷命令）或 `lark-cli <域> <resource> <method>`（各域白名单内的原生 API）；命令 / flag 细节以 `--help` 为准。
- **不要鉴权自举**：沙箱运行环境负责准备并随请求带上这次会话所需的鉴权材料（token 经
  `x-aily-token` 注入）；**不要**自行执行登录或初始化配置命令，遇到身份或权限不足的报错
  也不需要自行引导补登录或补配置——本沙箱不涉及这些步骤。
- **失败处理**：命令失败时把 `error.hint` 转述给用户，不要原样甩 envelope JSON。
- **身份**：多数域默认以当前登录用户身份运行（`--as user`）；wiki 域默认 `auto`、需显式带 `--as user`，以各域 README 的「身份」节为准。能否读到目标资源取决于该用户的可见范围。
- **原生 API 先查 schema**：调用 `lark-cli <域> <resource> <method>` 前，先 `lark-cli schema <域>.<resource>.<method>` 确认参数结构，不要凭直觉拼 `--params`。

## 高风险写操作审批（exit-10）

`risk: high-risk-write` 的命令不带 `--yes` 会 **exit 10** 并返回 `confirmation_required`。处理：

1. 识别 exit code=10 且 `error.type=="confirmation_required"`；
2. 把 `error.risk.action` + 关键参数转述给用户，明确"高风险"，等显式同意；
3. 同意 → 原始 argv 末尾加 `--yes` 重试；拒绝 → 终止；
4. 想先看请求 → `--dry-run`（不触发门禁、不需 `--yes`）。

**绝不**看到 exit 10 就默认补 `--yes` 静默重试。

## 意图路由

**执行某域操作前 MUST 先读对应域的 README.md，再按其指引读 references/**；不要只看本文件就拼命令。

| 用户意图 | 读取 |
|---|---|
| 查日程、搜日程、看忙闲、找会议室、推荐时间块、取日程关联的会议信息 | [lark-calendar/README.md](lark-calendar/README.md) |
| 按姓名/邮箱搜人拿 open_id、查他人或自己的资料 | [lark-contact/README.md](lark-contact/README.md) |
| 读云文档内容（整篇或锚点局部）、列文档历史版本 | [lark-doc/README.md](lark-doc/README.md) |
| 列云盘文件夹子项、查文档评论列表、查文档访问记录 | [lark-drive/README.md](lark-drive/README.md) |
| 列群聊、搜群、看群成员、查置顶/表情回复等群状态 | [lark-im/README.md](lark-im/README.md) |
| 下载妙记音视频、查妙记基础信息 | [lark-minutes/README.md](lark-minutes/README.md) |
| 读电子表格数据/公式/样式/对象配置、看历史版本与变更 | [lark-sheets/README.md](lark-sheets/README.md) |
| 读演示文稿整份或单页 XML、看历史版本与回滚任务状态 | [lark-slides/README.md](lark-slides/README.md) |
| 搜索或列取任务/任务清单（分配给我、我创建、我关注等） | [lark-task/README.md](lark-task/README.md) |
| 导出画板为预览图/SVG/代码/原始节点结构 | [lark-whiteboard/README.md](lark-whiteboard/README.md) |
| 列知识库空间、列/查 wiki 节点、看空间成员 | [lark-wiki/README.md](lark-wiki/README.md) |
| 读多维表格：列表/字段/视图配置/记录、按关键词搜记录 | [lark-base/README.md](lark-base/README.md) |
| 查会议录制：回看链接、时长、关联妙记 | [lark-vc/README.md](lark-vc/README.md) |

### calendar —— 日程与会议安排

- 触发词：日程、日历、会议安排、今天/本周有什么会、忙闲、空闲时段、会议室、约个时间。
- 能力：日程查询（`+agenda` / `+get` / `+search-event`）、忙闲（`+freebusy`）、会议室查找（`+room-find`）、时间块推荐（`+suggestion`）、日程关联视频会议信息（`+meeting`）。
- 入口：[lark-calendar/README.md](lark-calendar/README.md)

```bash
lark-cli calendar +agenda --start 2026-03-10 --end 2026-03-17
lark-cli calendar +search-event --query "周会" --start 2026-04-20 --end 2026-04-27
```

### contact —— 通讯录搜人

- 触发词：找人、搜员工、某人的 open_id、查某人的部门/邮箱、我的资料。
- 能力：按姓名/邮箱搜人拿 open_id（`+search-user`）、按 open_id 取资料、查看自己（`+get-user`）。
- 拿到 open_id 后想发消息 / 新建日程的限制见下方「能力边界」的跨域协作条目。
- 入口：[lark-contact/README.md](lark-contact/README.md)

```bash
lark-cli contact +search-user --query "张三" --has-chatted
lark-cli contact +get-user
```

### doc —— 云文档读取

- 触发词：读文档、看飞书文档、docx/wiki 链接内容、文档历史版本。
- 能力：`docs +fetch`（整篇或 `#share-...` / `#block_id` 锚点局部读取）、`docs +history-list`（历史版本列表）、`docs +search`（按关键词搜云文档）。本沙箱仅这三个只读入口。
- 入口：[lark-doc/README.md](lark-doc/README.md)

```bash
lark-cli docs +fetch --doc "文档URL或token"
lark-cli docs +history-list --doc "文档URL或token" --page-size 20
lark-cli docs +search --query "<关键词>"
```

### drive —— 云盘盘点与评论/访问记录

- 触发词：云盘里有什么、列文件夹、文档评论、谁看过这个文档。
- 能力：`drive +search`（按关键词搜云空间文件，支持类型/归属/时间窗过滤）、`drive +batch-query-comments`（按 comment_id 批量取评论详情）、`drive +list-replies`（取某条评论的回复列表）、`drive files list`（列子项、可递归盘点）、`drive file.comments list`（评论分页遍历）、`drive file.view_records list`（访问记录）。3 个只读快捷命令 + 3 个只读原生 API。
- 入口：[lark-drive/README.md](lark-drive/README.md)

```bash
lark-cli schema drive.files.list   # 调用原生 API 前先看参数结构
lark-cli drive files list --params '{"folder_token":"<folder_token>","page_size":200}'
lark-cli drive +search --query "<关键词>" --doc-types file --mine
```

### im —— 群聊与成员查询

- 触发词：我有哪些群、搜群名、群里都有谁、群里的机器人、置顶消息、表情回复。
- 能力：`+chat-list` / `+chat-search` / `+chat-members-list` 三个只读快捷命令，及 pins、reactions 等白名单只读 API。
- 入口：[lark-im/README.md](lark-im/README.md)

```bash
lark-cli im +chat-list --sort active_time
lark-cli im +chat-search --query "项目群"
```

### minutes —— 妙记

- 触发词：妙记、会议录制、minutes 链接、下载音视频、妙记信息。
- 能力：`+download`（下载妙记音视频媒体）、`minutes minutes get`（标题/时长/所有者等基础信息）。
- 入口：[lark-minutes/README.md](lark-minutes/README.md)

```bash
lark-cli minutes +download --minute-tokens obcnxxxxxxxxxxxxxxxxxxxx --output ./meeting.mp4
```

### sheets —— 电子表格读取

- 触发词：读表格、看电子表格、汇总某列、公式对不对、图表/透视表配置、表格历史版本。
- 能力：读数据（`+csv-get` / `+table-get` / `+cells-get`）、结构与对象配置（工作表/图表/透视表/条件格式/筛选器/迷你图/浮动图片）、历史与变更（`+history-list` / `+changeset-get`）、公式自检（`+formula-verify`）。
- 入口：[lark-sheets/README.md](lark-sheets/README.md)

```bash
lark-cli sheets +csv-get --url "https://.../sheets/shtXXX" --sheet-name "<真实表名>" --range "A1:F30"
```

### slides —— 幻灯片读取

- 触发词：看演示文稿、读 slides、某页幻灯片内容、幻灯片历史版本。
- 能力：整份 XML（`slides xml_presentations get`）、单页 XML（可指定历史版本）、历史版本列表（`slides +history-list`）与回滚任务状态查询（`slides +history-revert-status`）。
- 入口：[lark-slides/README.md](lark-slides/README.md)

```bash
lark-cli slides +history-list --presentation "<url_or_id>" --page-size 20
lark-cli slides +history-revert-status --presentation "<url_or_id>" --task-id "<task_id>"
```

### task —— 任务与清单查询

- 触发词：我的任务、分配给我的待办、我创建/关注的任务、任务清单、截止日期。
- 能力：任务搜索（`+search`）、我的任务（`+get-my-tasks`）、与我相关（`+get-related-tasks`）、清单搜索（`+tasklist-search`）。
- 「待办」一词有归属歧义（飞书任务 vs 妙记待办），先按 lark-task README 的归属判断节确认。
- 入口：[lark-task/README.md](lark-task/README.md)

```bash
lark-cli task +get-my-tasks
lark-cli task +search --query "上线"
```

### whiteboard —— 画板导出

- 触发词：看画板、导出画板图片、画板 SVG、画板是不是代码画的、画板节点结构。
- 能力：`+export` 导出预览图 / SVG / Mermaid·PlantUML 源码 / 原始节点结构（raw）。
- 入口：[lark-whiteboard/README.md](lark-whiteboard/README.md)

```bash
lark-cli whiteboard +export --whiteboard-token "wbcnxxxxxxxx" --output-type preview --output ./preview
```

### wiki —— 知识库查询

- 触发词：知识库、wiki 空间、wiki 节点、知识库目录、空间成员。
- 能力：列空间（`+space-list`）、列节点（`+node-list`）、查节点详情/解析 wiki URL（`+node-get`）、列空间成员（`wiki members list`）。
- 入口：[lark-wiki/README.md](lark-wiki/README.md)

```bash
lark-cli wiki +space-list --as user
lark-cli wiki +node-get --node-token "<wiki URL 或 token>" --as user
```

### base —— 多维表格读取

- 触发词：多维表格、Base、bitable、表里的记录、视图筛选、字段类型。
- 能力：定位（`+url-resolve`）、元信息（`+base-get`）、结构（`+table-list` / `+field-list` / `+view-list`）、视图配置（7 个 `+view-get*`）、记录（`+record-list` / `+record-search`）。仅这 8 类只读入口。
- 入口：[lark-base/README.md](lark-base/README.md)

```bash
lark-cli base +url-resolve --url "<Base URL>"
lark-cli base +record-list --base-token <t> --table-id <tbl> --view-id "<视图名>"
```

### vc —— 会议录制

- 触发词：会议录制、回看链接、录了多久、meeting_id。
- 能力：`vc +recording`（按 `--meeting-ids` 或 `--calendar-event-ids` 查录制的 `recording_url` / `duration` / `minute_token`）。仅这一个只读入口。
- 输入：`meeting_id` 或日程实例 ID 二者之一，**必须由用户直接提供**；只拿到会议链接或会议号时向用户索取 ID。
- 入口：[lark-vc/README.md](lark-vc/README.md)

```bash
lark-cli vc +recording --meeting-ids <meeting_id>
```

### 跨域串联提示

一次请求常跨多个域，按链路顺序读各域 README：

- **找人 → 发消息/排日程**：先 contact 搜人拿 `open_id`；发消息、新建日程 / 邀请会议在当前沙箱不可用（im 域仅开放群相关的只读查询、calendar 域无写能力），拿到 open_id 后告知用户该限制，不要用其它域命令替代；查日程 / 忙闲走 calendar 只读查询。
- **找文件 → 读内容**：只知道文件名不知道 URL 时，先在 drive / wiki 定位资源拿 token，再回 doc / sheets / slides 读内容。
- **wiki 链接 → 具体文档**：`/wiki/<token>` 链接先走 wiki `+node-get` 解析出 `obj_token` 与 `obj_type`，再按类型转 doc / sheets / slides 域读取。
- **约会议**：时间不明确时先在 calendar 用 `+suggestion` 推荐时间块，确认时间块后再用 `+room-find` 找会议室；无明确时间块禁止直接调 `+room-find`。
- **「待办」归属**：上下文含妙记/会议纪要时不走 task 域，归属判断细则见 lark-task README。

## 能力边界

- **只开放各域 README 列出的白名单命令**：各域 README 未列出的命令与 flag 在本沙箱被屏蔽，不要凭上游文档或直觉拼；原生 API 仅各域 README「API Resources」白名单内的可用。
- **未列出的域不可用**：本 skill 只覆盖上述 13 个非 apps 域；未列出的域未开放，不要尝试。
- **写/管理操作默认不开放**：创建、编辑、删除、上传、权限管理等能力大多被屏蔽；个别高风险写入口命中 exit 10 门禁时，按上文「高风险写操作审批（exit-10）」协议处理，绝不静默补 `--yes`。
- **妙搭应用操作不在这里**：对当前妙搭应用的操作（部署发布、改应用名、环境变量、线上日志与监控、插件、开放 API Key、可见范围等）走 [`lark-apps-ops`](../lark-apps-ops/SKILL.md) 系列 skill。
- **不要用插件代替本 skill 读资源**：你现在要读的飞书资源，一律用 bash 跑 `lark-cli` 读。插件（plugin / `capabilityClient` / `CapabilityService`）是写进应用代码、由**生成出来的应用在运行时**调用的，不是你的读取工具；多维表格尤其容易混——用户给了 Base 链接要你先读懂再建应用，走 base 域，不要去装插件或生成插件调用代码。反过来，应用本身需要在运行时读写飞书（页面上展示多维表格数据、发飞书通知）才用插件，那部分看 `plugin-guide`。
