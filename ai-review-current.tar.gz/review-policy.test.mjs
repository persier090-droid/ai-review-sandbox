import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ROLE_PERSONAS,normalizeRoles,sceneStructure} from './role-personas.mjs';
import {scoreReview} from './review-scoring.mjs';
import {createFreeCaller,FREE_MODEL_IDS,providerFailure} from './free-recovery.mjs';
import {ReviewStore} from './review-store.mjs';
import {buildContext} from './review-context.mjs';
import {deliverReview} from './review-delivery.mjs';
import {collectReviewRisks} from './review-risks.mjs';
import {ktvScenePlans} from './tests/scene-fixture.mjs';

function reviewBase() {
  const quote='仅实现可以关闭的数字人舞蹈';
  return {revision:1,roles:[{key:'pd',name:'产品经理'}],required_roles:['pd'],inputs:[quote],precheck:{passed:true},quality:{decision_ready:true},state_history:[{state:'ROUND_ASK',revision:1}],no_questions_reason:'反例和验证方法已记录，没有新的关键质询',role_results:[{role:'pd',stance:'支持',analysis:{claim:quote,principle:'操作可逆原则',reasoning:'依据需求提供关闭入口',counterargument:'关闭入口可能遮挡歌曲控件',verification:'实测关闭后可以继续点歌',basis:[{kind:'input',quote}]},risks:[]}],conclusion:{decision:'通过',reason:'原文允许关闭，设计须保证关闭入口可达',basis_roles:['pd'],execution:[{owner:'客户端研发',deadline:'2027-01-01',deliverable:'关闭入口',scope_quote:quote}]},closure:{in_scope:[quote],parking_lot:[],undecided:[],next_action:'实现后检查关闭入口可达性',reopen_when:'出现关闭入口不可达证据'},conditions:[],challenges:[],responses:[]};
}
function review() {
  const record=reviewBase();
  record.roles.push({key:'client',name:'客户端研发'},{key:'server',name:'服务端研发'});
  record.role_results.push(...['client','server'].map(role=>({...structuredClone(record.role_results[0]),role})));
  record.conclusion.scene_checks=ktvScenePlans(record.inputs[0]);
  return record;
}
test('nine personas are complete, duplicate selection is removed, and custom roles have honest defaults',()=>{
  assert.equal(ROLE_PERSONAS.length,9);
  for(const role of ROLE_PERSONAS)for(const field of ['key','name','avatar','tag','style','professional_view'])assert.ok(role[field]);
  const roles=normalizeRoles([{key:'pd',name:'伪造身份'},{key:'pd',name:'重复'},{key:'custom_access',name:'无障碍顾问',professional_view:'视障操作者的路径',style:'先检验操作可达性'}]);
  assert.equal(roles.length,2);assert.equal(roles[0].name,'产品经理');assert.equal(roles[1].professional_view,'视障操作者的路径');
  assert.doesNotMatch(JSON.stringify(sceneStructure('car','语音导航')),/包厢|点歌/);
});
test('scoring sums to 100 and every deduction has a check and traceable reason',()=>{
  const record=review(),score=scoreReview(record);
  assert.equal(score.score,100);assert.equal(score.verdict,'通过');
  assert.equal(score.dimensions.reduce((n,d)=>n+d.weight,0),100);
  record.no_questions_reason='';record.closure.in_scope=undefined;
  const boundary=scoreReview(record);assert.equal(boundary.score,75);assert.equal(boundary.verdict,'通过');
  record.conclusion.execution[0].deadline='尚未确定';
  const below=scoreReview(record);assert.equal(below.score,65);assert.equal(below.verdict,'不通过');
  for(const d of below.dimensions.filter(d=>d.deducted))assert.ok(d.checks.some(c=>!c.passed&&c.reason));
});
test('missing model opinions stay unscored and do not report internal bookkeeping as a failing score',()=>{
  const record=review();record.role_results=[];record.failure={http_status:429};
  const score=scoreReview(record);
  assert.equal(score.score,null);
  assert.equal(score.scoring_status,'unavailable');
  assert.match(score.scoring_reason,/429/);
  assert.match(score.rules.find(r=>r.id==='R2').reason,/尚未评分/);
  assert.doesNotMatch(score.rules.find(r=>r.id==='R2').reason,/当前[\d.]+分/);
  assert.equal(score.verdict,'待讨论');
  assert.equal(score.decision_status,'awaiting_discussion');
});
test('partial opinions without a completed decision cannot become a rejection or a score',()=>{
  const record=review();record.conclusion=null;
  const scored=scoreReview(record);
  assert.equal(scored.verdict,'待讨论');assert.equal(scored.score,null);
  assert.ok(scored.rules.every(r=>r.status==='pending'));
});
test('high score cannot override blocking risk, missing professional coverage, or unverified conditions',()=>{
  for(const mutate of [r=>r.role_results[0].risks.push({level:'high',impact_tag:'阻塞'}),r=>r.required_roles.push('test'),r=>r.conditions.push({revision:1,status:'待验证'})]) {
    const record=review();mutate(record);const scored=scoreReview(record);
    assert.ok(scored.score>=75);assert.equal(scored.verdict,'不通过');assert.ok(scored.rules.some(r=>!r.passed));
  }
  const record=review();record.role_results[0].stance='反对';assert.equal(scoreReview(record).score,100,'stance is not a popularity score');
  assert.equal(scoreReview(record).verdict,'不通过','dissent cannot be silently removed from the release decision');
  record.role_results[0].stance='有条件';record.role_results[0].stance_conditions=['关闭入口验证通过后才支持'];assert.equal(scoreReview(record).verdict,'不通过');
});
test('a complete process score cannot override a known cost beyond the submitted budget',()=>{
  const record=review();
  record.inputs.push('研发8人日；人日成本1000元；验证预算3000元');
  const scored=scoreReview(record);
  assert.equal(scored.score,100);
  assert.equal(scored.verdict,'不通过');
  assert.match(scored.rules.find(r=>r.id==='R3').reason,/费用|预算/);
});
test('final decision risks reach the release gate and every downstream deliverable',async()=>{
  const record={...review(),id:'decision-risk',scene:'KTV',requirement:'仅实现可以关闭的数字人舞蹈',discussion_complete:true,execution:[]};
  record.conclusion.risks=[{text:'授权范围尚未完成核验',level:'high',owner:'运营',impact_tag:'阻塞'}];
  await deliverReview(record,{save:()=>{},emit:()=>{}});
  for(const artifact of Object.values(record.artifacts)) assert.equal(artifact.verdict,'不通过');
  assert.ok(record.artifacts.risk.items.some(r=>r.text==='授权范围尚未完成核验'));
  assert.ok(record.artifacts.todo.items.some(t=>t.item.includes('授权范围')));
  assert.match(record.artifacts.prd.markdown,/授权范围尚未完成核验/);
});
test('failed condition feedback refreshes all deliverables and keeps task evidence',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-refresh-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const store=new ReviewStore(directory);
  const record={...review(),id:'refresh',scene:'KTV',requirement:'仅实现可以关闭的数字人舞蹈',discussion_complete:true,execution:[]};
  record.conditions=[{id:'c1',revision:1,condition:'关闭入口实际可达',verifier:'测试工程师',status:'通过',evidence:'初次验证',fallback:'修复关闭入口'}];
  await deliverReview(record,{save:()=>{},emit:()=>{}});store.save(record);
  const updated=store.track(record.id,{kind:'condition',item_id:'c1',status:'不通过',evidence:'补测低配设备关闭入口不可达'});
  for(const artifact of Object.values(updated.artifacts)) assert.equal(artifact.verdict,'不通过');
  assert.match(updated.artifacts.prd.markdown,/关闭入口实际可达/);
  const task=updated.execution.find(t=>t.kind==='verification');
  const tracked=store.track(record.id,{kind:'execution',item_id:task.id,status:'已完成',evidence:'已提交补测证据'});
  assert.equal(tracked.artifacts.todo.items.find(t=>t.id===task.id)?.status,'已完成');
  assert.match(tracked.artifacts.prd.markdown,/已提交补测证据/);
  assert.ok(tracked.conditions[0].history.some(h=>h.evidence==='初次验证'));
});
test('risk verification can carry forward only within an unchanged effective scope',()=>{
  const record={...review(),id:'risk-carry',effective_scope:{key:'same'}};
  record.conclusion.risks=[{text:'授权范围未核验',level:'high',owner:'运营'}];
  const risk=collectReviewRisks(record)[0];
  record.risk_verifications=[{id:risk.id,risk_key:risk.risk_key,scope_key:'same',revision:1,status:'已解除',evidence:'核验合同范围与本次用途一致'}];
  record.revision=2;
  assert.equal(collectReviewRisks(record)[0].status,'已解除');
  record.effective_scope.key='changed';
  assert.equal(collectReviewRisks(record)[0].status,'待验证');
});
test('unresolved factual disagreement is a hard gate even with a high score',()=>{
  const record=review();record.conflicts=[{id:'c',type:'事实',topic:'授权范围存在争议',parties:['pd','op'],resolution:'',escalation_level:5}];
  const score=scoreReview(record);assert.equal(score.score,95);assert.equal(score.verdict,'不通过');
});
test('merged or strengthened risks cannot inherit an older resolution',()=>{
  const record={...review(),id:'risk-contract',effective_scope:{key:'same'}};
  record.conclusion.risks=[{text:'授权范围未核验',level:'mid',owner:'运营'}];
  const old=collectReviewRisks(record)[0];
  record.risk_verifications=[{id:old.id,risk_key:old.risk_key,scope_key:'same',revision:1,status:'已解除',evidence:'只验证旧版用途'}];
  assert.equal(collectReviewRisks(record)[0].status,'已解除');
  record.risks=[{text:'授权范围未核验',level:'high',owner:'运营',impact_tag:'阻塞'}];
  assert.equal(collectReviewRisks(record)[0].status,'待验证');
  assert.equal(scoreReview(record).verdict,'不通过');
});
test('failed verification pauses existing implementation without deleting its evidence',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-task-history-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const store=new ReviewStore(directory),record={...review(),id:'task-history',scene:'KTV',requirement:'仅实现可以关闭的数字人舞蹈',discussion_complete:true};
  record.conclusion.execution[0].item='实现可关闭舞蹈';
  record.conditions=[{id:'c',revision:1,condition:'关闭检查',status:'通过',evidence:'先前记录'}];
  await deliverReview(record,{save:()=>{},emit:()=>{}});store.save(record);
  const task=record.execution.find(t=>t.kind==='implementation');
  store.track(record.id,{kind:'execution',item_id:task.id,status:'进行中',evidence:'已提交 commit abc123'});
  const changed=store.track(record.id,{kind:'condition',item_id:'c',status:'不通过',evidence:'补测失败'});
  assert.equal(changed.execution.find(t=>t.id===task.id)?.status,'暂停');
  assert.match(changed.artifacts.prd.markdown,/commit abc123/);
});
test('temporary failure has only one zero-cost fallback and quota/auth failures are never retried',async()=>{
  const models=[],notices=[];
  const caller=createFreeCaller({model:FREE_MODEL_IDS[1],notify:e=>notices.push(e),request:async model=>{models.push(model);if(models.length===1)throw Object.assign(new Error('unavailable'),{status:503});return 'valid';}});
  assert.equal(await caller('prompt',new AbortController().signal),'valid');assert.deepEqual(models,[FREE_MODEL_IDS[1],FREE_MODEL_IDS[0]]);assert.equal(notices.length,1);
  await caller('next stage');assert.equal(models.at(-1),FREE_MODEL_IDS[0],'reuse the working free route instead of returning to the failing primary');
  for(const status of [401,402,403,429]){let attempts=0;const stopped=createFreeCaller({model:FREE_MODEL_IDS[0],request:async()=>{attempts++;throw Object.assign(new Error('blocked'),{status});}});await assert.rejects(stopped('prompt'),/blocked/);assert.equal(attempts,1);}
  assert.throws(()=>createFreeCaller({model:'openrouter/auto',request:()=>{}}),/禁止/);
});
test('only a confirmed provider-side 429 permits one free fallback; platform and unknown limits stop',async()=>{
  for(const kind of ['provider','platform','unknown']) {
    const metadata=kind==='unknown'?{}:{provider_name:'example-provider'};
    const headers=new Headers(kind==='platform'?{'x-ratelimit-limit':'20','retry-after':'60'}:{});
    const failure=providerFailure(429,headers,{error:{metadata}});
    assert.equal(failure.rate_limit_source,kind);
    const attempts=[];
    const call=createFreeCaller({model:FREE_MODEL_IDS[1],request:async model=>{attempts.push(model);if(attempts.length===1)throw failure;return 'recovered';}});
    if(kind==='provider'){assert.equal(await call('test'),'recovered');assert.deepEqual(attempts,[FREE_MODEL_IDS[1],FREE_MODEL_IDS[0]]);}
    else {await assert.rejects(call('test'));assert.equal(attempts.length,1);}
  }
  const failure=providerFailure(429,new Headers(),{error:{message:'sk-private-sentinel',metadata:{provider_code:429}}});
  assert.equal(failure.rate_limit_source,'provider');assert.doesNotMatch(failure.message,/sentinel/);
});
test('persistent upstream failures open a circuit and cancelled calls do not retry',async()=>{
  let attempts=0;const caller=createFreeCaller({model:FREE_MODEL_IDS[0],request:async()=>{attempts++;throw Object.assign(new Error('unavailable'),{status:503});}});
  await assert.rejects(caller('a'));await assert.rejects(caller('b'));await assert.rejects(caller('c'),/停止重复请求/);assert.equal(attempts,4);
  const controller=new AbortController();controller.abort();await assert.rejects(caller('x',controller.signal));assert.equal(attempts,4);
});
test('unavailable free model id gets one other free route, never a paid model',async()=>{
  const attempted=[];
  const caller=createFreeCaller({model:FREE_MODEL_IDS[1],request:async model=>{attempted.push(model);if(attempted.length===1)throw Object.assign(new Error('model unavailable'),{status:404});return 'ok';}});
  assert.equal(await caller('request'),'ok');
  assert.deepEqual(attempted,[FREE_MODEL_IDS[1],FREE_MODEL_IDS[0]]);
});
test('candidate lessons are distinct from facts, confirmable with evidence and isolated by scene',t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'persona-learning-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const store=new ReviewStore(directory);store.save({id:'a',scene:'KTV',revision:1,requirement:'数字人舞蹈',learning:[{id:'candidate',role:'test',text:'验证关闭入口',topic:'数字人舞蹈',status:'candidate',evidence:'需求原文',counterargument:'可能遮挡歌曲操作'}],predictions:[]});
  const record={scene:'KTV',requirement:'数字人舞蹈',inputs:['数字人舞蹈'],messages:[],predictions:[]};
  let memory=store.learning('KTV','数字人舞蹈');let context=buildContext(record,null,memory);
  assert.equal(context.supervised_memory.length,0);assert.equal(context.reflection_memory.length,1);
  assert.throws(()=>store.learn('a',{action:'confirm',item_id:'candidate'}),/核验依据/);
  store.learn('a',{action:'confirm',item_id:'candidate',evidence:'门店操作测试记录及适用设备条件'});
  context=buildContext(record,null,store.learning('KTV','数字人舞蹈'));assert.equal(context.supervised_memory.length,1);
  assert.equal(store.learning('车载','数字人舞蹈').length,0);
  store.learn('a',{action:'withdraw',item_id:'candidate'});assert.equal(store.learning('KTV','数字人舞蹈').length,0);
});
