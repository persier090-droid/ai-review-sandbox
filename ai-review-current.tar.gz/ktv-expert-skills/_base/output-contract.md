# 主答输出契约

text 用自然对话回应本轮具体问题，不强制标题或段落数量。判断、依据、反例和验证保留在后台 analysis 字段供审核。
结构化字段包括 role、references、evidence_gap、alternatives、predictions、handoff。
references 保留断言 id/quote/source/usage/scenario；quote 和 source 必须和本次检索结果一致。缺失证据不能伪造引用。
alternatives 仅在真实存在方案取舍时提供，各有 plan 和 cost；无必要对比时允许为空。只列有依据的风险与应对，不编造概率或数字。
