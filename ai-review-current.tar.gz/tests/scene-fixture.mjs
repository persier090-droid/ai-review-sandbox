// Synthetic design plans for exercising gates, never actual verification evidence.
export function ktvScenePlans(quote,roles=['pd','client','server']) {
  const owner=keys=>keys.find(k=>roles.includes(k));
  return [
    {id:'ktv:song-flow',owner:owner(['client','test']),scope_quote:quote,criterion:'关闭新增展示后能继续点歌、切歌且歌词不被遮挡',method:'同机同曲对照开关前后，执行点歌切歌暂停并录像',failure_condition:'入口不可达或播放中断则关闭新增展示并恢复旧流程'},
    {id:'ktv:service-recovery',owner:owner(['server','client','service']),scope_quote:quote,criterion:'断网和重连后保留已确认队列且不重复加歌',method:'记录请求编号，断开网络再恢复，核对队列与日志',failure_condition:'重复入队或丢失歌曲则暂停发布并恢复已确认队列'},
    {id:'ktv:content-config',owner:owner(['op','pd']),scope_quote:quote,criterion:'仅在授权门店启用已确认许可的素材并可撤回',method:'对照素材许可记录与门店开关，验证越权发布被拒绝',failure_condition:'来源不明或越权可发布则撤下该素材并关闭相关开关'}
  ];
}
