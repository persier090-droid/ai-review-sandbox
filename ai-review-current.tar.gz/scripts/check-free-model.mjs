import {buildProviderRequest,readModelStream} from '../server.mjs';

const request=buildProviderRequest({provider:'openrouter',baseUrl:'https://openrouter.ai/api/v1',apiKey:process.env.OPENROUTER_API_KEY,model:process.env.OPENROUTER_MODEL || 'openrouter/free',messages:[{role:'user',content:'连通性测试，仅返回JSON对象：{"ok":true}。'}]});
try {
  const response=await fetch(request.url,{method:'POST',headers:request.headers,body:request.body,signal:AbortSignal.timeout(60000)});
  if (!response.ok) {
    const body=await response.json().catch(()=>null);
    let message=String(body?.error?.message || 'No provider error message');
    if(process.env.OPENROUTER_API_KEY)message=message.split(process.env.OPENROUTER_API_KEY).join('[redacted]');
    console.log(JSON.stringify({ok:false,http_status:response.status,message:message.slice(0,1000),free_only:true}));process.exitCode=1;
  }
  else {
    const metadata={};
    const raw=await readModelStream(response.body,true,info=>{if(info.model)metadata.model=info.model;if(info.usage)metadata.usage=info.usage;});
    console.log(JSON.stringify({connected:true,reply:JSON.parse(raw),free_only:true,model:metadata.model,cost:metadata.usage?.cost ?? null}));
  }
} catch (error) {console.log(JSON.stringify({ok:false,error_type:error.name,free_only:true}));process.exitCode=1;}
