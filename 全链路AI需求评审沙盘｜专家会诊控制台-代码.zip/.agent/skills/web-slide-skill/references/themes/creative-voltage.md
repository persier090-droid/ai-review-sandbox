# Theme: Creative Voltage

**Vibe:** Bold, creative, energetic, retro-modern

**Best For:** Creative pitches, brand decks, campaign reveals

**Typography:**
- Display: `Syne` (700/800) — distinctive retro-modern display
- Mono: `Space Mono` (400/700) — accent + technical feel

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Syne:wght@700;800&family=Space+Mono:wght@400;700&display=swap');

:root {
  --font-display: 'Syne', sans-serif;
  --font-sans: 'Space Mono', ui-monospace, monospace;
  --font-mono: 'Space Mono', ui-monospace, monospace;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
  --font-mono: var(--font-mono);
}
```
_标题用 `font-display`，正文/徽章默认就是 Space Mono；所有小字天生带技术感。_

**Theme CSS:**
```css
[data-ppt-theme="creative-voltage"] {
  --ppt-bg-primary: #0066ff;    /* electric blue */
  --ppt-bg-dark: #1a1a2e;
  --ppt-accent-neon: #d4ff00;   /* neon yellow */
  --ppt-text-light: #ffffff;
  --ppt-text-dark: #0a0a0a;
}
```

**Key Tailwind Classes:**
```tsx
// Split panels (electric blue left, dark right)
className="min-h-full grid grid-cols-2"
// left: bg-[var(--ppt-bg-primary)]  right: bg-[var(--ppt-bg-dark)]

// Neon badge/callout
className="bg-[var(--ppt-accent-neon)] text-[var(--ppt-text-dark)] font-mono uppercase tracking-wider px-3 py-1 rounded-sm text-xs"

// Display headline
className="font-display text-[clamp(2rem,6vw,5rem)] font-extrabold italic leading-none text-[var(--ppt-text-light)]"

// Halftone overlay (CSS only)
className="absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,rgba(255,255,255,0.15)_1px,transparent_0)] bg-[size:4px_4px] pointer-events-none"
```

**Signature Elements:**
- Electric blue + neon yellow contrast
- Halftone texture patterns (CSS radial-gradient dots)
- Neon pill badges / callouts
- Italic display type for energy
- Split vertical panels
