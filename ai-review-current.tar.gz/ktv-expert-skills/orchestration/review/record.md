> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 评审记录规范 review-record

## 用途
定义评审全过程的结构化记录，确保可追溯、可复盘、可校准。

## 记录结构


review_record:
  review_id: 唯一编号
  timestamp: 开始时间
  end_time: 结束时间
  topic: 议题
  review_type: 类型
  participants: [参加角色]
  facilitator: 主持人
  
  intake:
    decision: 上评审
    urgency: 紧急度
    required_materials: [材料]
  
  precheck:
    passed: true/false
    missing: [缺失项]
  
  agenda: [子议题列表]
  
  rounds:
    - round: 1
      phase: SPEAK
      speaker: 角色
      content: 发言摘要
      assertions_used: [断言编号]
      prediction: prediction 字段
    - round: 2
      phase: ASK
      asker: 角色
      target: 角色
      question_type: 类型
      question: 问题
    - round: 3
      phase: RESPOND
      responder: 角色
      response: 回应摘要
      revised: true/false
  
  conflicts:
    - conflict_id: 编号
      type: 类型
      parties: [角色]
      escalation_level: 1-5
      resolution: 裁决
      minority_opinion: 保留意见
  
  conclusion: 结论结构（见 conclusion.md）
  
  tracking: [执行项列表]
  
  retrospective:
    scheduled_at: 复盘时间
    status: 待复盘/已复盘
  
  self_assessment:
    score: 分数
    level: 等级
记录的用途

追溯：谁的判断被采纳，谁被否决，为什么
复盘：预测 vs 实际，偏差归因
校准：更新断言库和校准规则
审计：合规检查
学习：案例入库
存储规则

每条评审记录独立存储
记录不可修改，只能追加
记录保留至少 3 年
敏感信息脱敏后存储
禁止行为

禁止不记录
禁止记录不完整
禁止记录后不进入 learning-protocol
