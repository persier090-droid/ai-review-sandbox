// Synthetic replies for transport and validation tests only; never production evidence.
import {ktvScenePlans} from './scene-fixture.mjs';
export function manualReply(bundle) {
  const quote=bundle.request.change || bundle.request.requirement;
  const roles=bundle.request.roles.map(r=>r.key);
  const questions=roles.length>1?[{id:'q1',asker:roles[1],target:roles[0],type:'验证',question:'包厢点歌消费者如何在舞蹈播放中继续点歌？',basis:'需求未提供播放中的操作验证记录'}]:[];
  const reply={package_id:bundle.id,version:1,stages:[
    {phase:'INTAKE',output:{review_type:'requirement',agenda:['舞蹈展示与点歌边界'],scope:{active_quotes:[...new Set([bundle.request.requirement,quote])],retired_quotes:[],change_quote:quote},materials:[{name:'需求描述',quote}]}},
    ...roles.map(role=>({phase:'ROUND_SPEAK',role,output:{role,text:'站在包厢点歌消费者的角度，我建议先验证播放舞蹈时能否继续点歌。没有现场记录，这轮不承诺已经可用。',stance:'有条件',stance_reason:'只有主任务操作经过验证后才支持交付',stance_conditions:['舞蹈播放时仍可关闭并继续点歌'],analysis:{stakeholder:'包厢点歌消费者',claim:'舞蹈展示应保留可退出的点歌路径',principle:'附加体验需要满足操作可逆原则',reasoning:'舞蹈展示增加播放状态，应先验证对点歌任务的影响',counterargument:'若关闭控件遮挡点歌操作，新增入口也无法解决问题',boundary:'仅讨论当前舞蹈展示，不扩大到其他营销功能',verification:'在包厢终端播放舞蹈并执行关闭和点歌，记录操作结果',basis:[{kind:'input',quote}]},risks:[],references:[],evidence_gap:'仅有需求原文，没有现场验证记录',predictions:[],prediction_gap:'没有设备基线，不编造性能预测',deliverables:{acceptance:[{text:'播放舞蹈后关闭并继续点歌，记录实际操作路径',scope_quote:quote}]}}})),
    {phase:'ROUND_ASK',output:{questions,no_questions_reason:questions.length?'':'仅一个参会岗位，暂不能交叉质询'}},
    {phase:'ROUND_RESPOND',output:{responses:questions.map(q=>({question_id:q.id,responder:q.target,stakeholder:'包厢点歌消费者',response:'包厢点歌消费者需要随时回到点歌操作，我同意先在终端验证关闭入口和状态恢复。',basis:[{kind:'input',quote}],revised:false}))}},
    {phase:'ROUND_CHALLENGE',output:{acknowledgements:questions.map(q=>({question_id:q.id,asker:q.asker,satisfied:true,reason:'认可验证安排，仍需现场记录，不能据此认定已通过'})),conflicts:[]}},
    {phase:'CONVERGE',output:{summary:'本轮先明确操作边界，等待现场验证，不扩大需求',in_scope:[quote],parking_lot:[],undecided:['终端实际点歌路径尚未验证'],owner:'产品经理',next_action:'测试工程师记录播放、关闭、继续点歌的操作结果',reopen_when:'提供实际终端操作验证记录',opinion_checks:roles.map(role=>({role,consistent:true,evidence_supported:true,scope_respected:true,reason:'正文仅依据需求提出待验证建议，没有声称完成实测'}))}},
    {phase:'DECISION',output:{deciders:['pd'],basis_roles:roles,decision:'延期',summary:'补齐操作验证后再评审',reason:'需求包含舞蹈展示，但尚无主任务操作验证记录',consensus:[],minority_opinions:[],conditions:[],execution:[{item:'补充终端操作验证记录',owner:'测试工程师',deadline:'2099-01-01',deliverable:'播放关闭点歌操作记录',scope_quote:quote}],questions:[],risks:[],review_at:'2099-01-02',next_action:'测试工程师提交记录后复核'}}
  ]};
  reply.stages.find(s=>s.phase==='DECISION').output.scene_checks=ktvScenePlans(quote,roles);
  for(const audit of reply.stages.find(s=>s.phase==='CONVERGE').output.opinion_checks) {
    const opinion=reply.stages.find(s=>s.phase==='ROUND_SPEAK'&&s.role===audit.role).output;
    audit.claim_quote=opinion.text;
    audit.basis_quote=opinion.analysis.basis[0].quote;
  }
  return reply;
}
