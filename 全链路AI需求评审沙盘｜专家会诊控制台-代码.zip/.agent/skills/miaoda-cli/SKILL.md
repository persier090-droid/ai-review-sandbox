---
name: miaoda-cli
description: 妙搭沙箱预装的 Code Agent 命令行工具 `miaoda`（modern 模式），**直接调用**用于应用初始化、应用元数据查看 / 修改、发布上线、刷新本地 agent skills（steering）。触发词：miaoda app / miaoda deploy / miaoda skills / 妙搭初始化 / 妙搭应用元数据 / 妙搭发布 / 妙搭上线 / 应用名修改 / 更新 steering / 更新 skills。
control-by-feature-ab: true
---

# miaoda-cli

`miaoda` 是妙搭沙箱已预装的 Code Agent 命令行工具，直接调用。每条命令对应一个平台原子操作。

modern 模式下挂载的命令域是 **app**、**deploy**、**skills** 三个；其他域（file、db、observability 等）只在 default 模式存在，本 skill 不涵盖。

## 调用范式

```bash
miaoda <domain> <action> [args] [flags]
```

- **核心操作目标用位置参数**（如 template 名），**修饰符用 flag**（如 `--skip-build`、`--name`）
- **默认 `pretty` 同时服务人类与 Agent**：只有需要严格字段契约的脚本场景才加 `--json`，可用 `--json id,name` 做字段级选择

## 全局 flag

| Flag | 说明 |
|---|---|
| `--json [fields]` | JSON 结构化输出，可选字段级选择 |
| `--output <pretty\|json>` | 输出格式，默认 `pretty` |
| `--verbose` | debug 日志到 stderr |
| `-h, --help` | 帮助 |
| `-v, --version` | 版本号（仅根命令） |

## 输出契约

- pretty（默认）：紧凑对齐，人类与 Agent 共用
- JSON 模式：业务字段在 `data` key 下（`{"data": ...}`）；不再额外包 `ok` / `request_id` 等命令级 wrapper
- 错误始终写 stderr：
  - pretty：`Error: message\n  hint: ...`
  - JSON：`{"error": {"code": "...", "message": "...", "hint": "..."}}`
- 退出码：`0` 成功；`1` 运行时错误（按 `error.code` 决策重试）；`2` 用法错误（修正参数后重试）

## 调试：`--verbose`

输出更多 debug 信息到 stderr（inner-api 的请求/响应、logid、tosutil 上传日志等），用于排查异常或贴 logid 求助平台。

## 域与子命令

| 域 | 用途 | 参考 |
|---|---|---|
| `miaoda app ...` | 应用元数据查看 / 修改、应用代码骨架初始化（`init` 仅 modern 暴露） | [references/app.md](./references/app.md) |
| `miaoda deploy ...` | 触发一次发布（本地构建 + 本地部署，同步返回访问 URL） | [references/deploy.md](./references/deploy.md) |
| `miaoda skills ...` | 更新 / 查看本地 agent skills（含 coding-steering） | [references/skills.md](./references/skills.md) |
