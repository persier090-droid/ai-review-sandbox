import {localScope} from './review-local-scope.mjs';
import {sceneKey} from './review-context.mjs';

const number='(\\d+(?:\\.\\d+)?)(?:\\s*[-~至到]\\s*(\\d+(?:\\.\\d+)?))?';
const sum=rows=>rows.length?{min:rows.reduce((n,r)=>n+r.min,0),max:rows.reduce((n,r)=>n+r.max,0)}:null;
const range=(match,multiplier=1)=>({min:Math.min(Number(match[2]),Number(match[3]??match[2]))*multiplier,max:Math.max(Number(match[2]),Number(match[3]??match[2]))*multiplier});

// Extract explicit quantities only. Calendar days, unknown currencies and budgets
// are never substituted for labor estimates or supplier quotations.
function quantities(text,labels,units,money=false) {
  const pattern=new RegExp(`(${labels})\\s*(?:[:：为]|预计|约|改为)?\\s*${number}\\s*(${units})`,'g'),items=new Map();
  for(const match of text.matchAll(pattern)) {
    if(/(?:不含|不计|取消|无需|免除)\s*$/.test(text.slice(Math.max(0,match.index-6),match.index)))continue;
    items.set(match[1],{name:match[1],quote:match[0],...range(match,money&&match[4]==='万元'?10000:1)});
  }
  return [...items.values()];
}
export function assessFeasibility(review,costItems=[]) {
  const scope=localScope(review),input=scope.input||scope.latest;
  const clauses=String(input).split(/[。；\n]/).map(s=>s.trim()).filter(Boolean);
  const submitted=clauses.filter(s=>!/假设|假定|联调样例|未提供|待补充|尚不清楚/.test(s));
  const locate=pattern=>submitted.findLast(s=>pattern.test(s)) || '';
  const factors={
    audience:locate(/包厢.*消费者|演唱者|经营者|店员|员工|门店|商户|顾客|收银|服务员|驾驶员|乘客|管理员|消费者|(?:对象|目标用户)[：:]/),
    problem:locate(/(?:现状|痛点|问题|不做的后果)[：:]|(?:目前|每[日周月天]).*(?:投诉|失败|耗时|损失|协助)/),
    goal:locate(/(?:目标|成功指标|收益目标)[：:]|为了.*(?:降低|减少|提升|避免)/),
    method:locate(/(?:验证方法|验证方案|对照方法)[：:]/),
    success:locate(/(?:成功条件|验收标准|通过条件)[：:]/),
    stop:locate(/(?:停止条件|失败判据|终止条件)[：:]/),
    boundary:locate(/只做|仅限|不扩展|不增加|不做|首期|仅驻车|仅.*时/)
  };
  const workload=quantities(input,'研发|开发|测试|实施|设计|运营|售后','人日|人天');
  const rates=quantities(input,'人日成本|人日单价|人天成本|人天单价','万元|元',true);
  const extra=quantities(input,'授权费|接入费|素材费|设备费','万元|元',true);
  const totals=quantities(input,'一次性费用|一次性成本','万元|元',true);
  const monthly=quantities(input,'月维护费|月调用费|月运维费|每月费用','万元|元',true);
  const budgets=quantities(input,'验证预算|预算上限|预算','万元|元',true);
  const budget=budgets.at(-1)||null,rate=rates.at(-1);
  const labor=rate?workload.map(w=>({...w,min:w.min*rate.min,max:w.max*rate.max,quote:`${w.quote} × ${rate.quote}`})):[];
  const subtotal=sum([...labor,...extra]);
  const estimate=totals.at(-1)||subtotal;
  const cost={items:costItems,workload,rate:rate||null,estimate,recurring_monthly:sum(monthly),budget,
    basis:[...labor,...extra,...totals,...monthly],scope:'仅对已列费用作算术小计；不是完整报价，持续费用另计',
    budget_status:!budget?'未提供带单位的预算':!estimate?'成本待估':estimate.min>budget.max?'超出已列预算':estimate.max>budget.min?'估算区间可能超预算':'已列费用未超预算'};
  const inScope=item=>(review.effective_scope?.key&&item.scope_key===review.effective_scope.key)||(Number.isInteger(review.revision)&&item.revision===review.revision);
  const observations=[...(review.predictions||[]).filter(p=>inScope(p)&&p.feedback?.evidence).map(p=>p.feedback.evidence),...(review.conditions||[]).filter(c=>inScope(c)&&c.status==='通过'&&c.evidence).map(c=>c.evidence)];
  const evidence={observed_count:new Set(observations).size,status:observations.length?'已有人工回填记录，适用性及真实性待核验':'未提交本轮可追溯的验证记录',sources:[...new Set(observations)],independently_verified:false};
  const blockers=[];
  if(totals.length&&subtotal&&estimate.max<subtotal.min)blockers.push({key:'cost_conflict',quote:totals.at(-1).quote,reason:'提交的总费用低于已列明细小计，口径冲突',action:'核对总价是否包含已列人日与外部费用，消除重复或漏项',owner:'project'});
  for(const quote of clauses) {
    if(/禁止|不得|不允许|不能让|不支持/.test(quote))continue;
    if(sceneKey(review.scene)==='car'&&/驾驶员.*(?:行驶中|开车时|驾驶时).*(?:选歌|操作屏幕|唱歌)/.test(quote))blockers.push({key:'driving',quote,reason:'驾驶过程中主动操作娱乐功能存在注意力冲突',action:'改为驻车开放，并验证车辆状态变化时的退出与音频恢复',owner:'client'});
    if(/(?:未经授权|未获授权|没有授权).*(?:使用|播放|采集|录制|发布)/.test(quote))blockers.push({key:'authorization',quote,reason:'本次使用范围没有明确的授权依据',action:'先确认素材或数据的许可范围，再决定是否开展该试验',owner:'pd'});
  }
  const actions=[];
  const names={pd:'产品经理',project:'项目实施',test:'测试工程师',op:'运营',client:'客户端研发'};
  const add=(key,owner,item,done_when,quote='')=>actions.push({key,owner:review.roles?.find(r=>r.key===owner)?.name || `需求提出者（需${names[owner]}确认）`,item,done_when,quote});
  if(!factors.audience||!factors.problem||!factors.goal)add('necessity','pd','确认受影响对象、现状问题与改善目标','提交一条可追踪的现状记录，并说明不做的影响及替代办法');
  if(!estimate||!rate||!workload.length)add('cost','project','补齐最小验证的工作量与费用估算','分岗位列人日、单价、外部费用及持续费用；缺项注明，不以预算代替成本');
  if(cost.budget_status==='超出已列预算'||cost.budget_status==='估算区间可能超预算')add('budget','pd','调整试验范围或重新确认预算','给出删减项及重新估算，由提出者确认预算后再安排',budget.quote);
  if(!budget)add('budget','pd','确认带单位的验证预算上限','明确一次性预算、持续费用上限及承担方');
  if(!factors.method||!factors.success||!factors.stop)add('validation','test','确认对照试验、成功条件与停止条件','确定对象、样本、指标阈值、观察周期和异常退出规则，再收集结果');
  if(!observations.length)add('evidence','test','记录本次试验结果与失败样本','保留版本、时间、执行步骤与原始记录；按预先条件复核');
  for(const blocker of blockers)add(blocker.key,blocker.owner,blocker.action,'提交边界修订与验证方案，未确认前暂停相关操作',blocker.quote);
  const recommendation=scope.status==='clarify'?'先确认本轮范围':blockers.length?'暂停当前高风险方案，先修订边界':cost.budget_status==='超出已列预算'?'缩小验证范围或重新确认预算':cost.budget_status==='估算区间可能超预算'?'先核实成本区间，再确定试验范围':!factors.audience&&!factors.problem&&!factors.goal?'先澄清需求':!factors.problem||!factors.goal?'先验证必要性，再确定试验投入':!estimate||!budget?'补齐成本与预算后安排最小验证':!factors.method||!factors.success||!factors.stop?'补齐成功与停止条件后开展验证':'确认剩余费用及现场条件后开展小范围验证';
  return {version:'feasibility-v1',necessity:{status:factors.problem&&factors.goal?'已有问题与目标，收益待验证':'待验证',problem:factors.problem,goal:factors.goal,audience:factors.audience},cost,evidence,factors,blockers,actions,recommendation,release_authorized:false,scope:'基于当前提交内容与人工记录的辅助判断；不代表已验证收益或批准开发上线'};
}

export const moneyText=value=>value?`${value.min===value.max?value.min:`${value.min}至${value.max}`}元`:'待估算';
export function feasibilityText(f) {
  return `推进建议：${f.recommendation}\n必要性：${f.necessity.status}\n现状：${f.necessity.problem || '待补充实际问题'}\n目标：${f.necessity.goal || '待明确改善目标'}\n已列一次性费用：${moneyText(f.cost.estimate)}；${f.cost.scope}\n月度持续费用：${moneyText(f.cost.recurring_monthly)}\n验证预算：${f.cost.budget?moneyText(f.cost.budget):'未提供'}；${f.cost.budget_status}\n证据：${f.evidence.status}\n${f.scope}`;
}
