---
name: performance-review
description: "Fullstack performance audit checklist for the Reviewer agent. Covers frontend rendering, data fetching, memory, loading, backend queries, algorithm complexity, concurrency. 触发词：性能审查, performance review, 性能问题"
hook: SessionStart
available-agents:
  - Reviewer
---

# Performance Review Checklist

## Frontend Rendering & State

**Reference stability (trace origin):**
- Dependencies of useEffect/useMemo/useCallback containing object/array refs — trace whether the ref is recreated each render
- Event listener cleanup referencing the same function instance as addEventListener

**Render path cost:**
- Inline .filter()/.map()/.sort()/new Set()/new Date() in JSX — should extract to useMemo
- Large lists (100+ items) without virtualization
- Large components (500+ lines) where local state changes cause unrelated subtree re-renders
- Derived data using useState + useEffect instead of useMemo

## Frontend Data Fetching

- List API using getAll without pagination — should use backend pagination
- Multiple independent requests using serial await — should Promise.all
- Polling (setInterval + async) without request lock — next request shouldn't fire before previous completes
- Missing request cancellation on component unmount or parameter change

## Frontend Memory

By frequency of occurrence, focus on top three:
- setTimeout/setInterval without cleanup in useEffect return
- addEventListener without matching removeEventListener
- subscribe without unsubscribe

## Frontend Loading

- Routes not using React.lazy — synchronous import of all pages impacts initial load
- Large third-party libraries (ECharts, jsPDF, etc.) not dynamically imported
- Importing from barrel files (index.ts) — import directly from source for tree-shaking
- **Google Fonts / external CDN must not appear in entry resources**:
  - Search `index.html` and CSS files (especially `tailwind-theme.css`) for: `fonts.googleapis.com`, `fonts.gstatic.com`, `cdn.jsdelivr.net`, `unpkg.com`, `cdnjs.cloudflare.com`
  - **Must fix**: delete the `@import url(...)` line in CSS and the `<link rel="preconnect">` / `<link href="...">` tags in HTML; fall back to the system font stack.

## P1 · Data Access Performance

**Core issue**: N+1 queries in loops, findAll without limit.

```typescript
// BAD: N+1 — 100 orders → 100 queries
for (const order of orders) { const user = await User.findById(order.userId); }
// GOOD: batch query + in-memory join
const users = await User.findAll({ where: { id: userIds } });
const userMap = new Map(users.map(u => [u.id, u]));
```

**Checklist**:
- N+1 queries: per-item DB calls inside loops — use batch or JOIN
- List endpoints without pagination — will break as data grows
- OFFSET pagination on large datasets — use cursor pagination (WHERE id > cursor)
- Multiple independent DB queries running serially — use Promise.all
- External API calls without timeout
- WHERE/ORDER BY columns missing indexes — **cross-check with schema definition: for every ORDER BY or WHERE column in service queries, verify a matching index exists in schema.ts**
- Aggregation done in JS instead of SQL layer — fetch all rows then compute in app is a common anti-pattern
- **Sorting fields used in list/ranking endpoints must have database indexes — read schema.ts and verify**
- **Date-range loop expansion in JS (CRITICAL)**: code shaped like `for (let d = new Date(start); d <= end; d.setDate(d.getDate()+1)) for (item of items) ...` is O(N×days). For 1000 records over 90 days = 90,000 ops per request. Must be pushed to SQL using `generate_series(start, end, '1 day') + unnest(array_field) + GROUP BY ... HAVING COUNT(*) > N` — let the database do the date×row cross product
- **Multiple endpoints sharing the same base data should be merged**: e.g. Dashboard frontend calling 4 separate stats endpoints, each internally re-querying the full teacher table to build a lookup map. Merge into a single overview endpoint that runs the 4 stats in parallel internally and shares one base-data query.
- **Stats / Dashboard endpoints must have a default time window**: any query that scans the entire fact table for aggregation (`select ... from coursePlan` with no `where`) will degrade as data grows. Add a default `where startDate >= now() - interval '90 day'` (or business-appropriate window) so it can hit `idx_*_start_date`. Without a time window, even with indexes the planner may still seq-scan. If "all history" is required, use a materialized view or pre-aggregated table refreshed on schedule, never a live full-table scan.

| Scenario | Severity |
|----------|----------|
| findAll without limit | CRITICAL |
| N+1 queries | HIGH |

## P2 · Memory Usage

**Core issue**: Large file readFileSync into memory, module-level Map growing without bound.

**Checklist**:
- Large files must use streams, not readFileSync
- Module-level collections must have size limits or LRU eviction
- Must not accumulate full datasets in memory

| Scenario | Severity |
|----------|----------|
| readFileSync on user uploads / Map without limit | HIGH |

## P3 · Algorithm Complexity

**Core issue**: Nested loop O(n²) should use Set/Map index; hot-path JSON.parse(JSON.stringify) deep clone.

```typescript
// BAD: O(n²) nested lookup
for (const order of orders) {
  const user = users.find(u => u.id === order.userId); // linear scan per order
}
// GOOD: pre-build index
const userMap = new Map(users.map(u => [u.id, u]));
for (const order of orders) {
  const user = userMap.get(order.userId); // O(1) lookup
}
```

**Checklist**:
- No nested loops with linear lookup (O(n²)) — pre-build Map/Set index
- No unnecessary sort or deep clone on hot paths
- No ReDoS-vulnerable regular expressions

| Scenario | Severity |
|----------|----------|
| O(n²) nested loops / ReDoS | HIGH |
| Hot-path deep clone | MEDIUM |

## P4 · Concurrency & Backpressure

**Core issue**: Unbounded Promise.all overwhelming downstream; Stream without backpressure handling.

**Checklist**:
- Large array Promise.all must have concurrency limit (p-limit or chunked batches)
- Stream pipelines must handle backpressure (use pipeline)
- Batch operations must be chunked

| Scenario | Severity |
|----------|----------|
| Unbounded Promise.all | HIGH |
| Stream without backpressure | MEDIUM |

## Q1 · Anti-pattern Detection

**Checklist**:
- No overly long functions (> 60 lines)
- No deep nesting (> 4 levels)
- No magic numbers
- No duplicated code blocks (3+ times)

| Scenario | Severity |
|----------|----------|
| Overly long functions / deep nesting | MEDIUM |
| Magic numbers | LOW |

## On-demand References

For business-type-specific checks (e-commerce, payment, lottery, etc.), see `references/business-analyzer.md`.
