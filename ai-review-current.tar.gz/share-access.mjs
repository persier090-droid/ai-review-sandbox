import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';

const lifetime=7*24*60*60*1000;
const digest=value=>crypto.createHash('sha256').update(value).digest('hex');
export function passwordRecord(password) {
  if(typeof password!=='string'||password.length<16)throw new Error('Share password must have at least 16 characters');
  const salt=crypto.randomBytes(16).toString('hex');
  return {salt,passwordHash:crypto.scryptSync(password,salt,32).toString('hex')};
}
const loginPage=message=>`<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>评审平台登录</title><style>body{margin:0;background:#f5f7fa;color:#1d2129;font:16px system-ui;display:grid;min-height:100vh;place-items:center}main{box-sizing:border-box;width:min(420px,calc(100% - 32px));padding:28px;border:1px solid #e5e6eb;border-radius:8px;background:white}h1{font-size:24px;margin:0 0 24px}label{display:block;margin-bottom:10px}input,button{box-sizing:border-box;width:100%;font:inherit;padding:12px;border:1px solid #c9cdd4;border-radius:6px}button{margin-top:18px;background:#165dff;color:white;border:0;cursor:pointer}p{color:#c53b32;line-height:1.5}</style><main><h1>AI 需求评审沙盘</h1><form action="/login" method="post"><label for="password">访问口令</label><input id="password" name="password" type="password" autocomplete="current-password" required maxlength="200"><button type="submit">进入评审</button>${message?`<p role="alert">${message}</p>`:''}</form></main></html>`;

export function createShareAccess({origin,directory,salt,passwordHash,now=Date.now}) {
  const url=new URL(origin);
  if(url.protocol!=='https:'||url.origin!==origin||!salt||!/^[a-f0-9]{64}$/.test(passwordHash))throw new Error('Invalid HTTPS share configuration');
  fs.mkdirSync(path.join(directory,'sessions'),{recursive:true,mode:0o700});
  const stores=new Map();let attempts=0,windowStart=now();
  const validOrigin=req=>req.headers.host===url.host&&(!req.headers.origin||req.headers.origin===origin);
  const filename=token=>path.join(directory,'sessions',digest(token)+'.json');
  function session(req) {
    if(!validOrigin(req))return null;
    const token=(req.headers.cookie || '').split(';').map(s=>s.trim()).find(s=>s.startsWith('__Host-review_share='))?.slice('__Host-review_share='.length);
    if(!/^[a-f0-9]{64}$/.test(token || ''))return null;
    let record;
    try{record=JSON.parse(fs.readFileSync(filename(token),'utf8'));}catch{return null;}
    if(!/^[a-f0-9]{48}$/.test(record.id || '')||!Number.isFinite(record.expires)||record.expires<=now())return null;
    if(!stores.has(record.id)){
      const store=new ReviewStore(path.join(directory,'reviews',record.id));
      fs.mkdirSync(store.directory,{recursive:true,mode:0o700});
      store.recoverInterrupted();store.refreshScenePolicy();
      if(stores.size>=128)stores.delete(stores.keys().next().value);
      stores.set(record.id,store);
    }
    return stores.get(record.id);
  }
  const reply=(res,status,body,extra={})=>{
    res.writeHead(status,{'content-type':'text/html; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff','referrer-policy':'same-origin','content-security-policy':"default-src 'self'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'",...extra});res.end(body);return null;
  };
  async function authorize(req,res) {
    if(!validOrigin(req))return reply(res,403,'Forbidden');
    const pathname=new URL(req.url,origin).pathname;
    if(pathname==='/login'&&req.method==='POST'){
      if(req.headers.origin!==origin)return reply(res,403,'Forbidden');
      if(now()-windowStart>=60000){attempts=0;windowStart=now();}
      if(++attempts>30)return reply(res,429,loginPage('尝试次数过多，请一分钟后再试。'),{'retry-after':'60'});
      if(!req.headers['content-type']?.startsWith('application/x-www-form-urlencoded'))return reply(res,415,'Unsupported content type');
      const chunks=[];let length=0;
      for await(const chunk of req){length+=Buffer.byteLength(chunk);if(length>4096)return reply(res,413,'Request too large');chunks.push(Buffer.from(chunk));}
      const password=new URLSearchParams(Buffer.concat(chunks).toString('utf8')).get('password') || '';
      if(password.length>200||!crypto.timingSafeEqual(crypto.scryptSync(password,salt,32),Buffer.from(passwordHash,'hex')))return reply(res,401,loginPage('访问口令不正确。'));
      const token=crypto.randomBytes(32).toString('hex'),id=crypto.randomBytes(24).toString('hex');
      fs.writeFileSync(filename(token),JSON.stringify({id,expires:now()+lifetime}),{mode:0o600,flag:'wx'});
      return reply(res,303,'',{'location':'/?mode=local','set-cookie':`__Host-review_share=${token}; Path=/; HttpOnly; Secure; SameSite=Strict; Max-Age=${lifetime/1000}`});
    }
    const store=session(req);
    if(store)return store;
    if(pathname.startsWith('/api/'))return reply(res,401,'Authentication required');
    return reply(res,200,loginPage(''));
  }
  return {origin,validOrigin,session,authorize};
}
