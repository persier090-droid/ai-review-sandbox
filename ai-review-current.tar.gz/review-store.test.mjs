import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {runReview} from './review-runtime.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import {ktvScenePlans} from './tests/scene-fixture.mjs';
import {assessScene} from './review-scene.mjs';
import {rebuildReviewArtifacts} from './review-delivery.mjs';
import {resolveScope} from './review-scope.mjs';

function setup(t) {
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-store-recovery-'));
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  return new ReviewStore(directory);
}
test('scene evidence survives restart, rejects stale criteria, and refreshes four artifacts',async t=>{
  const store=setup(t),requirement='点歌后展示舞蹈，消费者可以随时关闭';
  const result=await runReview({request:{scene:'ktv',requirement,roles:ROLE_PERSONAS,reference_only:true},store,emit:()=>{},call:async()=>assert.fail('no API')});
  const record=store.get(result.review_id);
  resolveScope(record);
  record.role_results=ROLE_PERSONAS.map(r=>({role:r.key,analysis:{basis:[]}}));
  record.conclusion={scene_checks:ktvScenePlans(requirement)};
  rebuildReviewArtifacts(record);store.save(record);
  const item=assessScene(record).checks[0],input={kind:'scene',item_id:item.id,contract_key:item.contract_key,status:'通过',evidence:'测试报告 T-101，版本1.0，同机对照未影响点歌与切歌'};
  assert.throws(()=>store.track(record.id,{...input,contract_key:'stale'}),/标准已变更/);
  const updated=store.track(record.id,input);
  assert.equal(updated.reassessment_required,true);
  assert.equal(updated.artifacts.score.scene_assessment.checks[0].verified,true);
  assert.ok(updated.artifacts.prd.markdown.includes(input.evidence));
  assert.equal(updated.artifacts.risk.gaps.some(g=>g.source===item.id),false);
  const restored=new ReviewStore(store.directory),saved=restored.get(record.id);
  assert.equal(saved.scene_verifications.length,1);
  saved.conclusion.scene_checks[0].criterion='修改后的标准需要继续核对新的条件';restored.save(saved);
  assert.throws(()=>restored.track(record.id,input),/标准已变更/);
  assert.equal(assessScene(restored.get(record.id)).checks[0].verified,false);
});
test('a torn final journal write is archived and valid records remain appendable',t=>{
  const store=setup(t);store.save({id:'one',messages:[{text:'原始中文记录'}]});
  const valid=fs.readFileSync(store.file);
  fs.appendFileSync(store.file,'{"review":{"id":"unfinished');
  const damaged=fs.readFileSync(store.file),restored=new ReviewStore(store.directory);
  assert.equal(restored.get('one').messages[0].text,'原始中文记录');
  assert.deepEqual(fs.readFileSync(restored.recovery.backup),damaged);
  assert.deepEqual(fs.readFileSync(store.file),valid);
  restored.save({id:'two',messages:[]});
  assert.ok(new ReviewStore(store.directory).get('two'));
});
test('historical artifacts are reassessed without rewriting original conversation or decision',async t=>{
  const store=setup(t),result=await runReview({request:{scene:'ktv',requirement:'点歌后展示舞蹈，消费者可以随时关闭',roles:ROLE_PERSONAS,reference_only:true},store,emit:()=>{},call:async()=>assert.fail('no API')});
  const record=store.get(result.review_id),messages=structuredClone(record.messages);
  delete record.artifacts.score.scene_assessment;store.save(record);
  assert.equal(store.refreshScenePolicy(),1);
  const refreshed=store.get(record.id);
  assert.deepEqual(refreshed.messages,messages);assert.deepEqual(refreshed.conclusion,record.conclusion);
  assert.equal(refreshed.reassessment_required,true);
  assert.ok(refreshed.artifacts.score.scene_assessment.checks.every(c=>!c.plan_valid));
  assert.equal(store.refreshScenePolicy(),0);
});
test('a complete final record without newline stays valid after the next save',t=>{
  const store=setup(t);store.save({id:'one'});
  fs.truncateSync(store.file,fs.statSync(store.file).size-1);
  const restored=new ReviewStore(store.directory);restored.save({id:'two'});
  const next=new ReviewStore(store.directory);assert.ok(next.get('one'));assert.ok(next.get('two'));
});
test('corruption in a committed journal line is reported without discarding history',t=>{
  const store=setup(t);store.save({id:'one'});fs.appendFileSync(store.file,'invalid committed record\n');
  const before=fs.readFileSync(store.file);
  assert.throws(()=>new ReviewStore(store.directory),/第2行/);
  assert.deepEqual(fs.readFileSync(store.file),before);
});
test('interrupted attempts become retryable preparation records, preserving original opinions',async t=>{
  const store=setup(t);
  const result=await runReview({request:{scene:'KTV点歌机',requirement:'点歌后展示舞蹈，消费者可以随时关闭',roles:ROLE_PERSONAS,reference_only:true},store,emit:()=>{},call:async()=>assert.fail('no model call')});
  const record=store.get(result.review_id);
  record.discussion_complete=false;record.state='ROUND_SPEAK';record.failure=null;
  record.workflow={chat:'running',score:'locked',risk:'locked',todo:'locked',prd:'locked'};
  record.checkpoints={'INTAKE:':{output:{scope:'original'}}};store.save(record);
  const restored=new ReviewStore(store.directory);assert.equal(restored.recoverInterrupted(),1);
  const recovered=restored.get(record.id);
  assert.equal(recovered.artifacts.score.decision_status,'awaiting_discussion');
  assert.equal(recovered.artifacts.score.score,null);assert.equal(recovered.failure.code,'SERVICE_RESTARTED');
  assert.deepEqual(recovered.messages,record.messages);assert.deepEqual(recovered.checkpoints,record.checkpoints);
  assert.equal(restored.recoverInterrupted(),0);
});
