import { readFile, realpath } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';

const inputUrl = new URL('../evaluation/ktv-variant-benchmark/inputs/scenarios.json', import.meta.url);

function requireCondition(condition, message) {
  if (!condition) throw new Error(message);
}

export function exactKeys(value, expected, location) {
  requireCondition(value && typeof value === 'object' && !Array.isArray(value), `${location}: expected object`);
  const actual = Object.keys(value).sort();
  requireCondition(JSON.stringify(actual) === JSON.stringify([...expected].sort()), `${location}: unexpected or missing fields`);
}

function nonempty(value, location) {
  requireCondition(typeof value === 'string' && value.trim().length > 0, `${location}: expected nonempty text`);
  requireCondition(!value.includes('\uFFFD'), `${location}: invalid replacement character`);
}

export function validateInputs(bank) {
  exactKeys(bank, ['schema_version', 'simulation', 'instruction', 'cases'], 'inputs');
  requireCondition(bank.schema_version === '1.0' && bank.simulation === true, 'inputs: simulation/version mismatch');
  nonempty(bank.instruction, 'instruction');
  requireCondition(bank.instruction.includes('模拟'), 'instruction: missing simulation label');
  requireCondition(Array.isArray(bank.cases) && bank.cases.length > 0, 'inputs: no cases');
  const ids = new Set();
  const bodies = new Set();
  for (const scenario of bank.cases) {
    exactKeys(scenario, ['case_id', 'turns'], 'case');
    requireCondition(/^q-\d{2}$/.test(scenario.case_id) && !ids.has(scenario.case_id), 'case: invalid or duplicate ID');
    ids.add(scenario.case_id);
    requireCondition(Array.isArray(scenario.turns) && scenario.turns.length > 0, `${scenario.case_id}: no turns`);
    for (const [index, turn] of scenario.turns.entries()) {
      exactKeys(turn, ['turn_id', 'content'], `${scenario.case_id}/turn`);
      requireCondition(turn.turn_id === index + 1, `${scenario.case_id}: turns must be consecutive`);
      nonempty(turn.content, `${scenario.case_id}/${turn.turn_id}`);
      requireCondition(turn.content.startsWith('模拟'), `${scenario.case_id}/${turn.turn_id}: missing simulation label`);
      const normalized = turn.content.normalize('NFKC').replace(/\s+/gu, '');
      requireCondition(!bodies.has(normalized), `${scenario.case_id}/${turn.turn_id}: duplicate turn content`);
      bodies.add(normalized);
    }
  }
  return bank;
}

export async function readInputs() {
  const expected = fileURLToPath(inputUrl);
  requireCondition(await realpath(expected) === expected, 'inputs: symlink or redirected path refused');
  return validateInputs(JSON.parse(await readFile(inputUrl, 'utf8')));
}

// This module only reads the public input file. Review criteria never enter this process.
export function selectTurn(bank, caseId, turnId) {
  validateInputs(bank);
  requireCondition(Number.isSafeInteger(turnId) && turnId > 0, 'turn: expected positive integer');
  const scenario = bank.cases.find(item => item.case_id === caseId);
  requireCondition(scenario, 'case: unknown ID');
  const turn = scenario.turns.find(item => item.turn_id === turnId);
  requireCondition(turn, 'turn: unknown number');
  return {
    messages: [
      ...(turnId === 1 ? [{ role: 'system', content: bank.instruction }] : []),
      { role: 'user', content: turn.content }
    ]
  };
}

const isMain = process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  try {
    const args = process.argv.slice(2);
    if (args.length === 1 && args[0] === '--help') {
      console.log('Usage: node scripts/benchmark-ktv-prompt.mjs --case q-17 --turn 1');
      console.log('Print one user turn only; turn 1 also includes the neutral simulation instruction. No model calls.');
    } else {
      requireCondition(args.length === 4 && args[0] === '--case' && args[2] === '--turn', 'usage: --case <id> --turn <number>');
      requireCondition(/^[1-9]\d*$/.test(args[3]), 'turn: invalid integer');
      console.log(JSON.stringify(selectTurn(await readInputs(), args[1], Number(args[3])), null, 2));
    }
  } catch (error) {
    console.error(`benchmark-prompt: ${error.message}`);
    process.exitCode = 1;
  }
}
