import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {localCrossChecks} from './review-local-reference.mjs';
import {assessPreliminary} from './review-preliminary.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import os from 'node:os';
import path from 'node:path';
import {runReview} from './review-runtime.mjs';
import {ReviewStore} from './review-store.mjs';
import {localScope} from './review-local-scope.mjs';
import {sceneKey} from './review-context.mjs';

test('1000 scene cases are unique, retrievable, scored and traceable without real-world claims',()=>{
  const url=new URL('./evaluation/review-cases-1000.json',import.meta.url);
  assert.ok(fs.existsSync(url),'multi-scene case library is missing');
  const library=JSON.parse(fs.readFileSync(url));
  assert.equal(library.cases.length,1000);
  assert.equal(new Set(library.cases.map(c=>c.id)).size,1000);
  assert.equal(new Set(library.cases.map(c=>c.question)).size,1000);
  for(const scene of ['ktv','car','saas','app','web'])assert.equal(library.cases.filter(c=>c.scene===scene).length,200);
  for(const c of library.cases) {
    const review={scene:c.scene,requirement:c.title+' '+c.question,roles:ROLE_PERSONAS};
    const ref=localCrossChecks(review).find(r=>r.case_id===c.id);
    assert.ok(ref,c.id+' not retrievable');
    for(const key of ['premise','reply','reasoning','challenge','response','evidence','verify','accept','overturn','boundary'])assert.ok(ref[key],c.id+':'+key);
    assert.equal(ref.scenario.validation.execution.status,'未执行');
    assert.deepEqual(ref.scenario.context.known_facts,[]);
    assert.ok(ref.scenario.artifacts.tasks.every(t=>t.evidence_ids.every(id=>ref.scenario.evidence_requirements.some(e=>e.id===id))));
    const score=assessPreliminary(review);assert.ok(Number.isFinite(score.score));assert.equal(score.case_id,c.id);assert.ok(score.cost.items.length);assert.equal(score.release_authorized,false);
    if(c.scene==='car')assert.doesNotMatch(c.title+c.question,/POI|目的地检索/);
  }
});

const sceneRequests={
  ktv:'KTV点歌机新增数字人跳舞功能，点歌后可触发数字人舞蹈展示',
  car:'车载音响新增驻车KTV唱歌，支持麦克风接入、伴奏播放和歌词同步；退出后恢复原车音响，不影响通话和重要提示音',
  saas:'SaaS后台新增客户自动分级体系，按消费金额划分等级，支持手动调整与降级预警',
  app:'移动端APP新增积分商城，支持积分兑换实物、库存管控、兑换记录查询',
  web:'Web管理后台新增实时数据大屏，展示业务指标、异常标红、权限分级查看'
};
test('five scenes finish local dialogue, questions, counterexamples and four ordered deliverables without an API',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'local-scenes-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const store=new ReviewStore(directory);
  for(const [scene,requirement] of Object.entries(sceneRequests)) {
    const events=[];
    const run=change=>runReview({request:{scene,roles:ROLE_PERSONAS,reference_only:true,requirement,...change},store,emit:e=>events.push(structuredClone(e)),call:()=>assert.fail('local simulation must not invoke any API')});
    const result=await run({});
    assert.equal(result.failure,null);assert.equal(result.reference_only,true);assert.equal(result.usage.calls,0);
    assert.ok(result.phase_progress.every(p=>p.status==='reference'));
    assert.deepEqual(events.filter(e=>e.type==='artifact').map(e=>e.stage),['score','risk','todo','prd']);
    const messages=result.messages.filter(m=>m.reference);
    assert.deepEqual(new Set(messages.map(m=>m.role)),new Set(ROLE_PERSONAS.map(r=>r.key)));
    assert.equal(new Set(messages.map(m=>m.text)).size,messages.length,'no repeated speech');
    assert.ok(messages.some(m=>/[？?]/.test(m.text)));
    assert.ok(messages.some(m=>/如果|若|出现|不能/.test(m.text)));
    assert.equal(result.artifacts.score.preliminary.case_id.slice(0,scene.length).toLowerCase(),scene);
    assert.ok(result.artifacts.score.preliminary.cost.items.length);
    assert.equal(result.artifacts.score.score,null);assert.equal(result.artifacts.score.preliminary.release_authorized,false);
    assert.equal(result.artifacts.score.coverage.local_speakers,9);
    assert.ok(result.artifacts.risk.gaps.length&&result.artifacts.todo.items.length);
    assert.ok(result.artifacts.prd.markdown.includes(requirement));
    for(const section of ['业务流程','功能规则','异常处理','运营配置','交付售后','验收标准'])assert.ok(result.artifacts.prd.markdown.includes(`### ${section}`));
    const continued=await run({review_id:result.review_id,change:'预算500元，工期2人日；只对当前试验范围估算'});
    assert.equal(continued.review_id,result.review_id);assert.equal(continued.revision,2);
    assert.equal(continued.failure,null);assert.equal(continued.usage.calls,0);
    assert.equal(continued.artifacts.score.preliminary.case_id,result.artifacts.score.preliminary.case_id,'budget follow-up must retain the same issue');
    assert.ok(continued.artifacts.score.preliminary.score>result.artifacts.score.preliminary.score);
    assert.deepEqual(store.get(result.review_id).inputs,[requirement,'预算500元，工期2人日；只对当前试验范围估算']);
  }
});
test('short singing follow-up is retrievable and explicit cancellation retires old scope',()=>{
  const base={scene:'ktv',requirement:sceneRequests.ktv,roles:ROLE_PERSONAS};
  const brief={...base,inputs:[base.requirement,'如果是唱歌呢']};
  assert.match(localCrossChecks(brief)[0].title,/演唱/);
  assert.ok(localScope(brief).input.includes(base.requirement));
  const replacement={...base,inputs:[base.requirement,'取消数字人，只做唱歌']};
  assert.equal(localScope(replacement).input,'唱歌');
  assert.doesNotMatch(localCrossChecks(replacement)[0].title,/数字人|伴舞/);
  assert.doesNotMatch(assessPreliminary(replacement).input,/数字人/);
  const unclear={...base,inputs:[base.requirement,'不要这个了']};
  assert.equal(localScope(unclear).status,'clarify');assert.deepEqual(localCrossChecks(unclear),[]);
  assert.ok(Number.isFinite(assessPreliminary(unclear).score));
  assert.equal(sceneKey('车载智能终端｜音响与车载KTV'),'car');
  const scoped={scene:'web',roles:ROLE_PERSONAS,inputs:['后台大屏实时看数据','预算500元，工期2人日','只做大屏，不增加导出']};
  assert.match(localScope(scoped).input,/预算500元/);
  assert.ok(localCrossChecks(scoped).every(r=>!r.title.includes('导出')),'excluded capabilities must not be retrieved as positive requirements');
});
test('limited and custom attendees speak without impersonating unselected experts',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'local-custom-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const roles=[ROLE_PERSONAS[0],{key:'custom_audio',name:'音响顾问',professional_view:'麦克风与功放的匹配、啸叫及音区验收'}];
  const result=await runReview({request:{scene:'car',requirement:sceneRequests.car,roles,reference_only:true},store:new ReviewStore(directory),emit:()=>{},call:()=>assert.fail('no API')});
  assert.ok(result.messages.some(m=>m.role==='custom_audio'));
  assert.ok(result.messages.every(m=>['pd','custom_audio','human','facilitator'].includes(m.role)));
  assert.equal(result.artifacts.score.coverage.included,0);
});

test('paraphrased questions anchor to relevant cases through hybrid local retrieval',()=>{
  const queries=[
    ['ktv','给唱歌的人加个虚拟舞伴，想关就关','KTV-001'],
    ['car','在车里唱卡拉OK，听见自己的声音慢半拍','CAR-03'],
    ['saas','A公司的客户不应该给B公司看到','SAAS-01'],
    ['web','后台看板网断了还显示旧数字','WEB-003'],
    ['app','用积分换礼物，点了两次不能扣两遍','APP-00']
  ];
  for(const [scene,input,prefix] of queries) {
    const ref=localCrossChecks({scene,requirement:input,roles:ROLE_PERSONAS})[0];
    assert.ok(ref.case_id.startsWith(prefix),input+':'+ref.title);
    assert.equal(ref.match.query,input);assert.ok(ref.match.expanded_terms.length);
    assert.ok(ref.match.cosine>0&&ref.match.cosine<=1);
    assert.match(ref.match.method,/TF-IDF/);
  }
});
test('unmatched questions still produce a scoped clarification, score and actionable documents',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'local-no-match-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const result=await runReview({request:{scene:'web',requirement:'想研究火星矿物',roles:ROLE_PERSONAS,reference_only:true},store:new ReviewStore(directory),emit:()=>{},call:()=>assert.fail('no API')});
  assert.equal(result.failure,null);assert.equal(result.artifacts.score.preliminary.case_id,null);
  assert.ok(Number.isFinite(result.artifacts.score.preliminary.score));
  assert.ok(result.messages.some(m=>m.role==='pd'&&/操作场景/.test(m.text)));
  assert.ok(result.messages.some(m=>m.role==='test'&&/失败反例/.test(m.text)));
  assert.equal(result.role_status.sales.status,'pending_context');
  assert.equal(result.workflow.prd,'complete');assert.ok(result.artifacts.todo.items.length);
});
