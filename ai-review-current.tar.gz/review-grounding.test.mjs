import test from 'node:test';
import assert from 'node:assert/strict';
import {assessPreliminary} from './review-preliminary.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {runReview} from './review-runtime.mjs';
import {realisticReviewHoldout} from './evaluation/realistic-review-holdout.mjs';
import {validateDiscussionOutput} from './expert-skills.mjs';
import {manualReply} from './tests/manual-fixture.mjs';
const evaluate=(requirement,scene='ktv',extra={})=>assessPreliminary({scene,requirement,roles:ROLE_PERSONAS,...extra});

test('local assessment separates a six-factor candidate appraisal from missing project information',()=>{
  const p=evaluate('KTV点歌机支持包厢消费者邀请合唱，允许拒绝和退出');
  const c=p.comprehensive;
  assert.ok(c,'comprehensive professional appraisal is required');
  assert.equal(c.dimensions.length,6);
  assert.equal(c.dimensions.reduce((n,d)=>n+d.weight,0),100);
  assert.equal(c.dimensions.find(d=>d.key==='investment').rating,null);
  assert.equal(c.coverage,85);
  assert.equal(c.dimensions.find(d=>d.key==='value').points,6.25);
  assert.equal(c.score,42.6,'round only after weighted aggregation');
  assert.equal(c.release_authorized,false);
  assert.ok(c.score>p.score,'candidate appraisal is distinct from document readiness');
  assert.ok(c.interval.max>c.interval.min);
  for(const d of c.dimensions){assert.ok(d.judgment&&d.constraint&&d.next_action&&d.owners.length);assert.ok(d.rating===null||d.sources.length);assert.notEqual(d.rating,4,'case references never become independent validation');}
  for(const ch of p.dimensions.flatMap(d=>d.checks))if(ch.source.includes('案例'))assert.equal(ch.points,0);
});

test('comprehensive appraisal reacts to current budget and cannot average away a hard boundary',()=>{
  for(const row of realisticReviewHoldout){
    const a=evaluate(row.request,row.scene).comprehensive;
    const b=evaluate(row.request,row.scene,{inputs:[row.request,`预算改为${row.overBudget}元`]}).comprehensive;
    assert.ok(a&&b);
    assert.ok(a.score>b.score,row.scene);
    assert.match(b.recommendation,/缩小|预算/);
    assert.ok(b.blockers.length);
    assert.equal(b.release_authorized,false);
  }
  const unsafe=evaluate('让驾驶员行驶中在中控屏选歌唱歌','car').comprehensive;
  assert.match(unsafe.recommendation,/暂停/);
  assert.equal(unsafe.dimensions.find(d=>d.key==='risk').rating,0);
});

test('unrelated input never borrows a case score or synthetic professional certainty',()=>{
  const c=evaluate('请做一个量子纠缠实验装置').comprehensive;
  assert.ok(c);
  assert.equal(c.score,null);
  assert.equal(c.coverage,0);
  assert.deepEqual(c.interval,{min:0,max:100});
  assert.match(c.recommendation,/明确|确认|澄清/);
});

test('a risk may cite a different actual premise from the same requirement, but never an invented source',()=>{
  const input='包厢消费者可以随时关闭舞蹈，关闭后还要保留点歌队列';
  const opinion=manualReply({id:'grounding',request:{requirement:input,roles:ROLE_PERSONAS}}).stages.find(s=>s.role==='pd').output;
  opinion.analysis.basis=[{kind:'input',quote:'包厢消费者可以随时关闭舞蹈'}];
  opinion.risks=[{text:'关闭舞蹈可能清空队列',level:'mid',impact:'消费者需要重新选择歌曲',mitigation:'关闭前后比较队列内容是否相同',evidence_quote:'关闭后还要保留点歌队列'}];
  assert.equal(validateDiscussionOutput(opinion,'pd',[],{},input).eligible,true);
  opinion.risks[0].evidence_quote='所有机型队列都已测试通过';
  assert.equal(validateDiscussionOutput(opinion,'pd',[],{},input).eligible,false);
});

test('a library match supplies suggestions but cannot earn points for missing project information',()=>{
  const result=evaluate('点歌后数字人自动跳舞');
  assert.ok(result.case_id);
  for(const check of result.dimensions.flatMap(d=>d.checks))if(check.source.includes('案例'))assert.equal(check.points,0,check.label);
  assert.equal(result.feasibility.necessity.status,'待验证');
  assert.equal(result.feasibility.cost.estimate,null);
  assert.equal(result.feasibility.release_authorized,false);
});

test('budget alone is not an estimate and hypothetical data never becomes observed evidence',()=>{
  const result=evaluate('为包厢消费者增加可关闭的伴舞；假设收入提升30%；预算5000元；已测试成功但没有提供记录');
  assert.equal(result.feasibility.cost.estimate,null);
  assert.equal(result.feasibility.evidence.observed_count,0);
  assert.equal(result.feasibility.cost.budget.max,5000);
  assert.match(result.feasibility.evidence.status,/待核验|未提交/);
});
test('negated expenses and hypothetical benefits cannot count as submitted costs or known goals',()=>{
  const p=evaluate('假设目标：收益提升30%；未提供目标用户：包厢消费者；研发2人日；人日成本1000元；不含授权费1000元');
  assert.equal(p.feasibility.cost.estimate.min,2000);
  assert.equal(p.dimensions.find(d=>d.key==='necessity').earned,0);
});

const detailed='包厢消费者点歌后可开启伴舞。现状：每周有20次员工协助退出背景的记录。目标：减少员工协助。只做可关闭伴舞，不增加收费。研发6人日；测试2人日；人日成本1000元；授权费0元；月维护费200元；验证预算7000元。验证方法：同机同歌比较有无伴舞，记录关闭后继续点歌。成功条件：试验中均能关闭且继续点歌。停止条件：出现断音即停止。';
test('itemized costs retain units, separate recurring expenses and stop an over-budget trial',()=>{
  const result=evaluate(detailed).feasibility;
  assert.equal(result.cost.estimate.min,8000);
  assert.equal(result.cost.estimate.max,8000);
  assert.equal(result.cost.recurring_monthly.min,200);
  assert.equal(result.cost.budget_status,'超出已列预算');
  assert.match(result.recommendation,/缩小|重新/);
  assert.ok(result.actions.some(a=>a.key==='budget'));
  assert.equal(result.evidence.observed_count,0,'claims in a request do not constitute verified field records');
});
test('a budget change revises the assessment without losing the topic or resurrecting old budget',()=>{
  const result=evaluate(detailed,'ktv',{inputs:[detailed,'预算改为12000元']}).feasibility;
  assert.equal(result.cost.budget.max,12000);
  assert.equal(result.cost.estimate.max,8000);
  assert.equal(result.cost.budget_status,'已列费用未超预算');
  assert.equal(result.release_authorized,false);
});
test('cost ranges and incomplete units must not turn into a precise quotation',()=>{
  const range=evaluate('车载驻车唱歌；研发6至8人日；人日成本1000元；验证预算7000元','car').feasibility;
  assert.equal(range.cost.estimate.min,6000);assert.equal(range.cost.estimate.max,8000);
  assert.equal(range.cost.budget_status,'估算区间可能超预算');
  const missing=evaluate('新增伴舞；研发6天；人日成本1000；预算7000').feasibility;
  assert.equal(missing.cost.estimate,null);assert.equal(missing.cost.budget,null);
});
test('an explicit cost total is not added a second time to its itemized components',()=>{
  const f=evaluate('研发2人日；人日成本1000元；授权费1000元；一次性费用3000元；预算4000元').feasibility;
  assert.equal(f.cost.estimate.max,3000);
  assert.equal(f.cost.budget_status,'已列费用未超预算');
});
test('project evidence gaps and budget decisions reach all four deliverables',async t=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'grounded-delivery-'));t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  const r=await runReview({request:{scene:'ktv',requirement:detailed,roles:ROLE_PERSONAS,reference_only:true},store:new ReviewStore(directory),emit:()=>{},call:()=>{throw Error('offline must not call a model');}});
  assert.equal(r.artifacts.score.preliminary.feasibility.cost.estimate.min,8000);
  const c=r.artifacts.score.preliminary.comprehensive;
  assert.equal(r.artifacts.risk.preliminary,c.recommendation);
  assert.equal(r.artifacts.todo.preliminary,c.recommendation);
  assert.equal(r.artifacts.prd.preliminary,c.recommendation);
  assert.match(r.closure.summary,/综合参考分/);
  assert.match(r.artifacts.prd.markdown,/## 综合研判/);
  assert.ok(r.artifacts.prd.markdown.includes(`${c.score}/100`));
  assert.ok(r.artifacts.risk.gaps.some(g=>g.source==='budget'));
  assert.ok(r.artifacts.todo.items.some(item=>item.source==='budget'));
  assert.match(r.artifacts.prd.markdown,/8000元/);
  assert.match(r.artifacts.prd.markdown,/缩小验证范围|重新确认预算/);
});
test('held-out car scenarios distinguish driver interaction, parked singing and a prohibited action',()=>{
  const unsafe=evaluate('让驾驶员行驶中在中控屏选歌唱歌','car').feasibility;
  assert.ok(unsafe.blockers.some(b=>b.key==='driving'));
  assert.match(unsafe.recommendation,/暂停/);
  for(const text of ['仅驻车时允许驾驶员在中控屏选歌唱歌','禁止驾驶员行驶中选歌，乘客只使用后排屏幕']) {
    assert.equal(evaluate(text,'car').feasibility.blockers.length,0,text);
  }
});
test('held-out five-scene proposals consistently separate need, cost, evidence and a next action',()=>{
  const cases=[['ktv','包厢内合唱时展示可关闭的分句提示'],['car','后排乘客驻车时唱歌，来电立即暂停伴奏'],['saas','企业管理员批量撤回离职员工的访问权限'],['app','消费者兑换礼品失败后恢复积分'],['web','值班员工查看延迟指标时展示数据采集时间']];
  for(const [scene,text] of cases) {
    const result=evaluate(text,scene).feasibility;
    assert.ok(result.necessity&&result.cost&&result.evidence&&result.recommendation);
    assert.ok(result.actions.length>0);assert.equal(result.cost.estimate,null);
    assert.equal(result.release_authorized,false);
  }
});
test('five held-out operational scenarios respond to tighter and corrected budgets without inventing evidence',()=>{
  for(const scenario of realisticReviewHoldout) {
    const first=evaluate(scenario.request,scenario.scene).feasibility;
    assert.equal(first.cost.estimate.min,scenario.cost,scenario.scene);
    assert.equal(first.cost.budget_status,'已列费用未超预算');
    assert.equal(first.evidence.observed_count,0);
    assert.match(first.recommendation,/小范围验证/);
    const changes=[scenario.request,`预算改为${scenario.overBudget}元`];
    const limited=evaluate(scenario.request,scenario.scene,{inputs:changes}).feasibility;
    assert.equal(limited.cost.budget_status,'超出已列预算');
    assert.match(limited.recommendation,/缩小/);
    const corrected=evaluate(scenario.request,scenario.scene,{inputs:[...changes,`预算改为${scenario.newBudget}元`]}).feasibility;
    assert.equal(corrected.cost.budget_status,'已列费用未超预算');
    assert.equal(corrected.cost.estimate.min,scenario.cost);
    assert.equal(corrected.release_authorized,false);
  }
});
