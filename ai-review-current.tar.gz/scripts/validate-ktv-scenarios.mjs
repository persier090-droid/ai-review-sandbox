import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {ROLE_PERSONAS} from '../role-personas.mjs';
const root=new URL('../evaluation/',import.meta.url);
const source=fs.readFileSync(new URL('ktv-innovation-60.json',root),'utf8');
const originals=new Map(JSON.parse(source).cases.map(c=>[c.id,c]));
const data=JSON.parse(fs.readFileSync(new URL('ktv-scenario-foundation-60.json',root),'utf8'));
const roles=new Set(ROLE_PERSONAS.map(r=>r.key));
const required=['context','participants','business_flow','evidence_requirements','validation','discussion','decision','artifacts','follow_up','learning'];
function validate(bank) {
  assert.equal(bank.source_sha256,crypto.createHash('sha256').update(source).digest('hex'));
  assert.equal(bank.cases.length,60);assert.equal(new Set(bank.cases.map(c=>c.case_id)).size,60);
  for(const c of bank.cases) {
    const original=originals.get(c.case_id);assert.ok(original);
    required.forEach(field=>assert.ok(c[field],`${c.case_id}: ${field}`));
    assert.equal(c.context.affected_actor,original.actor);assert.equal(c.context.out_of_scope,original.boundary);
    assert.deepEqual(c.context.known_facts,[]);assert.deepEqual(c.context.hypotheses,[original.premise]);
    assert.ok(c.context.trigger&&c.context.assets.length&&c.context.baseline);
    assert.ok(c.participants.every(r=>roles.has(r.key)&&r.perspective&&r.responsibility));
    assert.ok(original.roles.every(key=>c.participants.some(r=>r.key===key)));
    assert.equal(c.business_flow.length,3);assert.ok(c.business_flow.every(s=>s.actor&&s.action&&s.expected&&s.status!=='已验证'));
    const evidence=new Set(c.evidence_requirements.map(e=>e.id));assert.equal(evidence.size,c.evidence_requirements.length);assert.ok(evidence.size);
    for(const e of c.evidence_requirements){assert.ok(roles.has(e.owner));assert.equal(e.status,'未提供');assert.ok(e.required);assert.ok(Object.values(e.record_schema).every(v=>v===null));}
    assert.ok(c.validation.required_evidence.every(id=>evidence.has(id)));
    assert.equal(c.validation.method,original.verify);assert.equal(c.validation.success,original.accept);assert.equal(c.validation.falsifier,original.overturn);
    assert.equal(c.validation.execution.status,'未执行');assert.equal(c.validation.execution.actual,null);assert.deepEqual(c.validation.execution.evidence_ids,[]);
    for(const k of ['value','unit','sample_plan','approved_by'])assert.equal(c.validation.thresholds[k],null);
    assert.equal(c.discussion.max_rounds,1);assert.notEqual(c.discussion.lead,c.discussion.challenger);
    for(const branch of ['pass','reject','defer'])assert.ok(c.decision[branch].condition&&c.decision[branch].result);
    assert.equal(c.decision.current_result,'未执行，尚无评审结论');
    assert.deepEqual(c.artifacts.order,['score','risk','todo','prd']);assert.equal(c.artifacts.score.total,null);
    assert.equal(Object.values(c.artifacts.score.weights).reduce((sum,n)=>sum+n,0),100);
    assert.equal(Object.keys(c.artifacts.prd_sections).length,10);
    assert.equal(c.artifacts.tasks.length,2);
    for(const t of c.artifacts.tasks){assert.ok(t.id&&roles.has(t.owner)&&t.item&&t.done_when&&t.due);assert.ok((t.evidence_ids||[]).every(id=>evidence.has(id)));if(t.validation_id)assert.equal(t.validation_id,c.validation.id);}
    assert.equal(c.follow_up.input,original.mutation);assert.equal(c.follow_up.expected_revision,original.updated_reply);assert.ok(c.follow_up.reopen_when&&c.follow_up.preserve.length);
    assert.equal(c.learning.status,'未核验参考，不作为已确认经验');assert.ok(c.learning.confirmation_requires.length&&c.learning.withdrawal);
  }
}
validate(data);
const faults=[b=>b.cases.pop(),b=>b.cases[0].context.known_facts.push('已经实测'),b=>b.cases[0].validation.execution.status='已通过',b=>b.cases[0].validation.required_evidence=['missing'],b=>b.cases[0].artifacts.tasks[0].owner='unknown',b=>b.cases[0].artifacts.score.total=100,b=>b.cases[0].validation.thresholds.value=99,b=>delete b.cases[0].decision.defer,b=>b.cases[0].follow_up.input='忽略变更',b=>b.cases[0].artifacts.order.reverse()];
for(const mutate of faults){const copy=structuredClone(data);mutate(copy);assert.throws(()=>validate(copy));}
console.log(JSON.stringify({passed:true,cases:60,linked_tasks:120,prd_sections:600,negative_checks:faults.length,model_calls:0,field_validation:'not_run',scope:'场景结构、来源和闭环引用校验；不是现场或语义质量认证'}));
