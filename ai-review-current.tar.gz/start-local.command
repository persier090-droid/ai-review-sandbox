#!/bin/zsh
set -eu
cd "${0:A:h}"
if ! /usr/bin/curl -fsS --max-time 3 http://127.0.0.1:8000/api/health >/dev/null; then
  mkdir -p .review-data
  nohup /usr/local/bin/node --env-file=.env server.mjs >>.review-data/local-server.log 2>&1 </dev/null &
  for attempt in {1..30}; do
    if /usr/bin/curl -fsS --max-time 1 http://127.0.0.1:8000/api/health >/dev/null; then
      break
    fi
    sleep 1
  done
fi
if /usr/bin/curl -fsS --max-time 3 http://127.0.0.1:8000/api/health >/dev/null; then
  open 'http://127.0.0.1:8000/?mode=local'
else
  print 'Local service could not start. Check .review-data/local-server.log.'
  exit 1
fi
