---
name: extract-json-schema
description: "Extract concise JSON schema with semantic field descriptions from JSON data. Use when: (1) analyzing JSON structure for documentation, (2) generating schema for API/data contracts, (3) creating field-level documentation for programmatic use, (4) understanding complex nested JSON data. Keywords: JSON schema, 提取schema, 字段说明, field description, data structure, 数据结构分析"
---

# Extract JSON Schema

从 JSON 数据中提取精简的 schema 信息，包含语义化的字段解释，便于程序化处理和集成。

---

## Schema 输出规范

输出必须符合 `extracted-json-schema/v1` 格式：

```json
{
  "$schema": "extracted-json-schema/v1",
  "title": "数据集名称",
  "description": "数据集整体描述",
  "source": "数据来源（可选）",
  "extracted_at": "ISO 8601 时间",
  "root_type": "object | array",
  "fields": [
    {
      "path": "字段路径（如 order.items[].price）",
      "type": "string | number | boolean | object | array | null | mixed",
      "element_type": "数组元素类型（仅 array 需要）",
      "nullable": false,
      "description": "语义化中文描述（核心字段）",
      "example": "示例值",
      "enum": ["枚举值（如有）"],
      "format": "date | datetime | currency | percentage | url | email | uuid 等",
      "unit": "元 | % | 天 等",
      "children": ["子字段路径列表（仅 object/array）"]
    }
  ],
  "statistics": {
    "total_fields": 0, "max_depth": 0, "object_count": 0, "array_count": 0
  }
}
```

### 类型与格式速查

| JSON 值 | type | 常见 format | unit |
|---------|------|------------|------|
| `"text"` | `string` | date, datetime, period, email, url, uuid | — |
| `123` / `1.5` | `number` | currency, percentage, ratio | 元, %, 天 |
| `true` | `boolean` | — | — |
| `{}` | `object` | — | — |
| `[]` | `array` | — | — |
| `null` | `null` | — | — |
| 混合类型 | `mixed` | — | — |

---

## 语义化描述规范

描述是 schema 的核心价值。每个字段的 description 必须说明**业务含义**，而非重复字段名。

| 字段类型 | 描述模板 | 差的描述 ❌ | 好的描述 ✅ |
|----------|----------|-----------|-----------|
| 标识字段 | [实体]的[唯一标识] | "标题" | "财务报告的标题，标识报告类型和时间范围" |
| 数值字段 | [指标名称]，单位为[单位] | "数量" | "该产品线的营收金额，单位为元" |
| 百分比字段 | [指标]的百分比/增长率 | "百分比" | "该产品线营收占总营收的百分比" |
| 日期字段 | [事件]的[日期/时间] | "时间" | "订单创建的时间戳，UTC 格式" |
| 状态字段 | [实体]的[状态]，可选值包括... | "状态" | "订单状态，可选值：paid, pending, cancelled" |

描述编写原则：结合数据集上下文理解字段含义 → 参考同级字段关联性 → 使用业务语言而非技术术语。

---

## 提取流程

```
1. 确认输入 JSON（用户提供或从文件读取）
   ↓
2. 识别根类型（object/array），递归遍历所有字段
   ↓
3. 推断 type、format、unit（优先根据字段名，结合值验证）
   ↓
4. 生成语义化 description（核心步骤，参考上方规范）
   ↓
5. 构建扁平化 fields 列表 + 计算 statistics
   ↓
6. 输出 Schema JSON，保存到 tmp/output/<source>_schema.json
```

### 类型推断规则

- 数组元素类型以第一个元素为准
- 遇到 `null` 值时标记 `nullable: true`
- 同一字段存在多种类型时标记为 `mixed`
- format 不确定时不标注

---

## 示例

**输入**：
```json
{"order_id": "ORD-001", "total_amount": 598.00, "items": [{"name": "无线耳机", "price": 299.00}]}
```

**输出（关键字段）**：
```json
{
  "$schema": "extracted-json-schema/v1",
  "title": "电商订单",
  "fields": [
    {"path": "order_id", "type": "string", "nullable": false, "description": "订单的唯一标识编号", "example": "ORD-001"},
    {"path": "total_amount", "type": "number", "nullable": false, "description": "订单总金额", "example": 598.00, "format": "currency", "unit": "元"},
    {"path": "items", "type": "array", "element_type": "object", "nullable": false, "description": "订单包含的商品列表", "children": ["items[]"]},
    {"path": "items[].name", "type": "string", "nullable": false, "description": "商品名称", "example": "无线耳机"},
    {"path": "items[].price", "type": "number", "nullable": false, "description": "商品单价", "example": 299.00, "format": "currency", "unit": "元"}
  ],
  "statistics": {"total_fields": 5, "max_depth": 2, "object_count": 2, "array_count": 1}
}
```

---

## Common Mistakes

| 错误 | 正确做法 |
|------|----------|
| description 只写字段名翻译（如 "名称"） | 结合业务上下文写语义描述（如 "产品线名称"） |
| 数值字段不标注 unit | 金额标 "元"，百分比标 "%"，时长标 "天/ms" |
| 数组类型缺 element_type | array 类型必须标注元素类型 |
| object/array 缺 children | 必须列出子字段路径 |
| 忘记 statistics 段 | 每次输出必须包含 total_fields, max_depth 等统计 |
| format 乱标 | 不确定时不标注，优先根据字段名推断 |
| 输出标准 JSON Schema (draft-07) | 本 skill 输出 extracted-json-schema/v1 格式，非标准 JSON Schema |

---

## Checklist

输出前逐项确认：

- [ ] 所有字段都有 description 且语义化（非字段名翻译）
- [ ] type 与实际值匹配
- [ ] array 类型有 element_type，object/array 有 children
- [ ] 金额/百分比等数值有 format 和 unit
- [ ] statistics 与实际字段数一致
- [ ] $schema 为 "extracted-json-schema/v1"
