# Theme: Bold Signal

**Vibe:** Confident, bold, modern, high-impact

**Best For:** Pitch decks, keynotes, product launches

**Typography:**
- Display: `Archivo Black` (900) — bold, confident sans-serif
- Body: `Space Grotesk` (400/500) — modern geometric sans

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Archivo+Black&family=Space+Grotesk:wght@400;500;700&display=swap');

:root {
  --font-display: 'Archivo Black', sans-serif;
  --font-sans: 'Space Grotesk', sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="bold-signal"] {
  --ppt-bg: #1a1a1a;
  --ppt-bg-secondary: #2d2d2d;
  --ppt-text: #ffffff;
  --ppt-text-secondary: #a0a0a0;
  --ppt-accent: #FF5722;
  --ppt-accent-foreground: #1a1a1a;
  --ppt-card: #FF5722;
  --ppt-card-foreground: #1a1a1a;
}
```

**Key Tailwind Classes:**
```tsx
// Background
className="bg-[var(--ppt-bg)] bg-gradient-to-br from-[#1a1a1a] via-[#2d2d2d] to-[#1a1a1a]"

// Accent card
className="bg-[var(--ppt-accent)] text-[var(--ppt-accent-foreground)] rounded-2xl p-8"

// Hero 标题（Archivo Black 900）
className="font-display text-[clamp(2rem,6vw,5rem)] leading-[0.95] tracking-tight"

// Section numbers（大字号装饰）
className="font-display text-[clamp(4rem,10vw,8rem)] text-[var(--ppt-text)]/10"
```

**Signature Elements:**
- Bold colored card as focal point (orange, coral)
- Large section numbers (01, 02, etc.) with low opacity
- Navigation breadcrumbs
- Grid-based layout
