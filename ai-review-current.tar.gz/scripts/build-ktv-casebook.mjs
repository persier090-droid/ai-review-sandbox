import assert from 'node:assert/strict';
import { readFile, writeFile } from 'node:fs/promises';
import { ROLE_PERSONAS } from '../role-personas.mjs';

const root = new URL('../evaluation/', import.meta.url);
const bank = JSON.parse(await readFile(new URL('ktv-innovation-60.json', root), 'utf8'));
const roles = new Map(ROLE_PERSONAS.map(role => [role.key, role]));
const sources = new Map(bank.source_notes.map(source => [source.id, source]));
const fields = ['id', 'category', 'title', 'question', 'premise', 'actor', 'stance', 'reply', 'reasoning', 'challenge', 'response', 'evidence', 'verify', 'accept', 'overturn', 'mutation', 'updated_reply', 'boundary'];
assert.equal(bank.cases.length, 60, 'Must contain exactly 60 cases');
assert.equal(new Set(bank.cases.map(item => item.id)).size, 60, 'Duplicate case IDs');
assert.equal(new Set(bank.cases.map(item => item.question)).size, 60, 'Duplicate questions');
assert.equal(sources.size, bank.source_notes.length, 'Duplicate source IDs');
const categoryCounts = Object.fromEntries(Object.keys(bank.categories).map(key => [key, 0]));
const stanceCounts = { 支持: 0, 有条件: 0, 反对: 0 };
const leadCounts = Object.fromEntries(roles.keys().map(key => [key, 0]));
const challengerCounts = Object.fromEntries(roles.keys().map(key => [key, 0]));
for (const [index, item] of bank.cases.entries()) {
  assert.equal(item.id, `KTV-${String(index + 1).padStart(3, '0')}`);
  for (const field of fields) {
    assert.ok(typeof item[field] === 'string' && item[field].trim(), `${item.id}: missing ${field}`);
    assert.ok(!item[field].includes('\uFFFD'), `${item.id}: invalid text in ${field}`);
  }
  assert.ok(Object.hasOwn(categoryCounts, item.category), `${item.id}: unknown category`);
  assert.ok(Object.hasOwn(stanceCounts, item.stance), `${item.id}: invalid stance`);
  assert.equal(item.roles.length, 2, `${item.id}: requires lead and challenger`);
  assert.notEqual(item.roles[0], item.roles[1], `${item.id}: independent role required`);
  for (const key of item.roles) assert.ok(roles.has(key), `${item.id}: unknown role ${key}`);
  assert.ok(['高', '中', '低'].includes(item.risk.level), `${item.id}: invalid risk level`);
  assert.ok(['阻塞', '待澄清', '建议'].includes(item.risk.impact), `${item.id}: invalid impact`);
  assert.ok(Array.isArray(item.sources));
  for (const key of item.sources) assert.ok(sources.has(key), `${item.id}: unknown source ${key}`);
  categoryCounts[item.category]++;
  stanceCounts[item.stance]++;
  leadCounts[item.roles[0]]++;
  challengerCounts[item.roles[1]]++;
}
for (const [key, count] of Object.entries(categoryCounts)) assert.equal(count, 6, `${key}: requires 6 cases`);
for (const key of roles.keys()) assert.ok(leadCounts[key] + challengerCounts[key] > 0, `Missing role ${key}`);

const text = [`# ${bank.title}`, '',
  `版本：${bank.version}。整理日期：${bank.created_at}。`, '',
  '**用途：用新点子检验角色是否能理解场景、给出专业判断、回应质疑并提出可核验动作。全部60条是人工设计的假设案例；尚未逐条调用模型，也未进行门店实测。**', '',
  '参考回复是合格论证示例，不是唯一标准答案，不应接入生产对话作为固定消息，也不能自动写入已确认知识。具体问题改变后，应依据新前提调整判断。', '',
  '## 如何理解结果', '',
  '- “已给前提”只在该测试题中成立，不是对真实门店或整个行业的事实陈述。',
  '- “支持 / 有条件 / 反对”是对当前方案的角色立场，不等于项目最终通过或不通过。支持也要完成验证；有条件必须说清条件。',
  '- “通过条件”是建议的场景验收条件，尚未执行。技术预算、经营门槛、样本量需依据设备基线与风险在测试前确定，没有伪造统一行业数值。',
  '- “反证 / 推翻条件”要求能够改变结论；改写问题后仍重复原答案，视为上下文理解失败。',
  '- 风险等级是题设下的初始评审建议，不是实际事故概率；impact表示本轮处理方式。',
  '- 多角色、多模型彼此赞同都不算独立事实验证。有效交叉验证必须回到可追溯的合同、日志、样本、测试或真实行为。', '',
  '## 使用步骤', '',
  '1. 从无答案出题版中取题。只向被测模型提供问题、假设前提、具体对象、岗位和范围；不要提供参考回复、反驳和验收答案。题设前提应明确标成模拟条件。',
  '2. 按现有六阶段流程进行：范围解析、角色立场、关键质询、依据回应、反驳校验、收口决策。需要其他必要岗位时可补充，但不得为凑人数扩展议题。',
  '3. 保留模型原文、请求状态和材料来源。先独立评价首轮，再发送该题“条件变更”作为第二轮追问；不要把预期修正一起发送。',
  '4. 依据下表核对论证和交叉验证，允许同样有依据的不同方案。不按措辞相似度打分，不要求模型背出参考答案。',
  '5. 真实证据回填前不宣布场景已验证。模型失败单列“未形成有效意见”；系统失败与方案不成立分别报告。',
  '6. 收口后按智能评测、风险看板、待办任务、交付文档顺序生成同一修订的结果，不能开放空白结果冒充完成。', '',
  '每题按当前产品规则限制调用和讨论预算；不自动跑无限循环。使用真实API前仍遵守免费白名单及零费用策略。当前文件构建不发出模型请求。', '',
  '## 人工判读清单', '',
  '| 检查项 | 满足的表现 | 不满足的表现 |',
  '| --- | --- | --- |',
  '| 对象与范围 | 指出具体操作者、受影响者，守住本次任务 | 笼统称“用户”，自行扩功能 |',
  '| 前提与来源 | 分开题设、已核验事实、假设和缺口 | 编造报告、收益、授权或现场数字 |',
  '| 专业判断 | 立场、因果解释和可执行方案对应本岗位 | 只有赞成反对或泛泛提醒 |',
  '| 交叉质询 | 另一岗位指出具体失效情形，主责实际回应 | 双方互夸或引用对方发言证明事实 |',
  '| 独立验证 | 指定证据、责任、方法、接受与推翻条件 | 只说“进一步优化”“让模型再确认” |',
  '| 动态修正 | 新前提使受影响判断改变，保留历史 | 忽略删除条件，继续重复旧方案 |',
  '| 收口与交付 | 有结果、缺口、负责人和重启条件 | 无限讨论、空白页、把错误调用当专业结论 |', '',
  '每项记录“满足 / 不满足 / 待人工核验”和原文位置。以上用于案例语义评价，不替代现有100分过程评分，不另外宣称统计准确率。事实编造、越过免费限制、用固定消息冒充模型和忽略关键反证属于阻塞项。', '',
  '项目放行继续遵循 [评审产品规则与验收](../评审产品规则与验收.md)：R1依据与流程、R2分数至少75且无阻塞、R3条件已验证且分歧有证据闭环。三条同时满足才可在明确范围内通过；需求评审通过不等于上线通过。', '',
  '如需汇总模型评测，分别报告：有效模型结果数/计划案例数、已人工核验合格数/有效结果数、关键错误案例数、上下文修正合格数/有效追问数。必须同时展示分母和未执行数；跳过失败不得抬高总体完成率。当前这些数量均尚未测量。', '',
  '## 四项交付怎么落地', '',
  '| 产物 | 每题应写入的内容 | 缺证时的处理 |',
  '| --- | --- | --- |',
  '| 智能评测 | 当前修订的有效观点、评分明细、三条门槛与触发原因 | 标记缺证或流程未完成，不生成假分数 |',
  '| 风险看板 | 本题主责岗位、具体失效情形、风险级别与impact | 保留未关闭项；勾选跟进不代表解除 |',
  '| 待办任务 | 由验证方法明确责任，列出证据交付物、优先级和完成节点 | 不通过时先补证或改方案，不自动安排开发 |',
  '| 交付文档 | 场景、原需求、范围、立场、结论、待确认清单及PRD章节 | 未知项显式留待确认，不替门店编造事实 |', '',
  '本题库内的证据清单全部是待取得的证据要求。涉及真实日期，由本轮负责人根据评审时间和资源确认；默认在对应放行门槛前完成，不能伪造具体承诺。', '',
  '## 目录', '', '| 编号 | 类别 | 问题主题 | 主责 / 交叉岗位 |', '| --- | --- | --- | --- |'
];
for (const item of bank.cases) text.push(`| ${item.id} | ${bank.categories[item.category]} | ${item.title} | ${item.roles.map(key => roles.get(key).name).join(' / ')} |`);
for (const [category, title] of Object.entries(bank.categories)) {
  text.push('', `## ${category}. ${title}`, '');
  for (const item of bank.cases.filter(item => item.category === category)) {
    const [lead, challenger] = item.roles.map(key => roles.get(key).name);
    text.push(`### ${item.id} ${item.title}`, '',
      `**问题：** ${item.question}`, '',
      `**已给前提（模拟）：** ${item.premise}`, '',
      `**具体对象：** ${item.actor}。**主责：** ${lead}；**交叉岗位：** ${challenger}。`, '',
      `**参考回复｜${item.stance}：** ${item.reply}`, '',
      `**判断依据与解释：** ${item.reasoning}`, '',
      `**${challenger}质询：** ${item.challenge}`, '',
      `**${lead}回应：** ${item.response}`, '',
      `**待取得的独立证据：** ${item.evidence}`, '',
      `**交叉验证方法：** ${item.verify}`, '',
      `**通过条件（待执行）：** ${item.accept}`, '',
      `**反证 / 推翻条件：** ${item.overturn}`, '',
      `**第二轮条件变更：** ${item.mutation}`, '',
      `**应有的上下文修正：** ${item.updated_reply}`, '',
      `**范围边界：** ${item.boundary} **初始风险建议：** ${item.risk.level} / ${item.risk.impact}。`, '');
    if (item.sources.length) {
      text.push(`**适用边界参考：** ${item.sources.map(id => { const source = sources.get(id); return `[${source.title}](${source.url})`; }).join('；')}。来源只支持相应制度边界，不证明本题设计已经实测。`, '');
    }
  }
}
text.push('## 来源核对与知识回填', '');
for (const source of bank.source_notes) text.push(`- **${source.id} [${source.title}](${source.url})**：${source.note}`);
text.push('', '来源核对日期：2026-09-20。真实上线前按具体用途、合同和最新适用规则复核。案例中的工程与产品方案为基于题设的设计判断，不声称全部来自这些法规。', '',
  '后续每次实测保留：案例ID、修订、模型与版本、原始输入、原始输出、调用是否有效、核验人、证据位置、适用环境、判读结果、实际偏差和纠正动作。只有核验通过且标明适用范围的内容才能进入已确认知识；其余保持候选。原始发言不覆盖。', '',
  '## 文件与复核', '',
  '- `ktv-innovation-60.json`：完整案例、参考论证、反例、证据与上下文追问。',
  '- `ktv-innovation-questions.json`：无参考答案出题版；follow_up字段应在首轮完成后发送。',
  '- `ktv-casebook-validation.json`：结构检查报告，不是模型能力或门店验证报告。',
  '- 重新生成与检查：在项目根目录执行 `node scripts/build-ktv-casebook.mjs`。', '',
  '本轮只整理评测资料，不改变应用角色库、运行接口和知识确认状态，不消耗模型额度。', '');

// Keep reference answers outside the prompts sent to the system under evaluation.
const questions = {
  version: bank.version,
  status: bank.status,
  instruction: 'initial_input用于首轮；follow_up在首轮完成后单独发送。前提均为模拟，不可伪装成实测。',
  cases: bank.cases.map(item => ({
    id: item.id,
    category: bank.categories[item.category],
    initial_input: {
      question: item.question,
      hypothetical_premise: item.premise,
      affected_actor: item.actor,
      roles: item.roles.map(key => ({ key, name: roles.get(key).name })),
      scope: item.boundary
    },
    follow_up: item.mutation
  }))
};
const report = {
  status: 'structure_passed',
  case_count: bank.cases.length,
  category_counts: categoryCounts,
  stance_counts: stanceCounts,
  role_coverage: ROLE_PERSONAS.map(role => ({ key: role.key, name: role.name, lead: leadCounts[role.key], challenger: challengerCounts[role.key] })),
  checks: ['60 unique sequential IDs', '60 distinct questions', '10 categories with 6 cases each', 'required text fields present', 'all 9 roles covered', 'distinct lead and challenger per case', 'valid stance/risk/source references', 'no Unicode replacement characters'],
  model_evaluation: 'not_run',
  field_validation: 'not_run',
  benchmark_prompt_isolation: 'reference fields excluded; follow_up separated from initial_input',
  knowledge_status: 'hypothetical_unverified'
};
await writeFile(new URL('KTV新点子60条评审与交叉验证.md', root), text.join('\n'), 'utf8');
await writeFile(new URL('ktv-innovation-questions.json', root), JSON.stringify(questions, null, 2) + '\n', 'utf8');
await writeFile(new URL('ktv-casebook-validation.json', root), JSON.stringify(report, null, 2) + '\n', 'utf8');
console.log(JSON.stringify(report, null, 2));
