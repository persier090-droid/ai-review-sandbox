import fs from 'node:fs';
import path from 'node:path';
import {spawn} from 'node:child_process';

const directory=path.resolve(process.env.REVIEW_DATA_DIR || '/data');
const origin=process.env.REVIEW_PUBLIC_ORIGIN;
const salt=process.env.REVIEW_ACCESS_SALT;
const passwordHash=process.env.REVIEW_ACCESS_HASH;
if(!origin || new URL(origin).origin!==origin || !origin.startsWith('https://') || !/^[a-f0-9]{32}$/.test(salt || '') || !/^[a-f0-9]{64}$/.test(passwordHash || '')){
  throw new Error('Configure REVIEW_PUBLIC_ORIGIN, REVIEW_ACCESS_SALT and REVIEW_ACCESS_HASH before starting the protected deployment');
}
fs.mkdirSync(directory,{recursive:true,mode:0o700});
const config=path.join(directory,'access.json');
fs.writeFileSync(config,JSON.stringify({origin,salt,passwordHash,directory:path.join(directory,'sessions-data')}),{mode:0o600});
// The shared pilot has no model credentials and cannot spend API budget.
const app=spawn(process.execPath,['server.mjs'],{cwd:new URL('../',import.meta.url),stdio:'inherit',env:{
  PATH:process.env.PATH,HOST:process.env.HOST || '0.0.0.0',PORT:process.env.PORT || '8000',
  REVIEW_SHARE_CONFIG:config,REVIEW_DATA_DIR:path.join(directory,'base')
}});
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>app.kill(signal));
app.on('exit',code=>process.exit(code ?? 1));
app.on('error',error=>{console.error(error.message);process.exit(1);});
