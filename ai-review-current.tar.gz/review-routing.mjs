import {sceneKey} from './review-context.mjs';

const RULES=[
  {id:'tenant',label:'租户与权限边界',scenes:['saas','web'],terms:['租户','越权','权限隔离'],lead:'server',collaborators:['h5','pd'],challenger:'test'},
  {id:'payment',label:'交易与一致性',terms:['支付','扣款','订单','退款','幂等','回调'],lead:'server',collaborators:['sales','op','h5'],challenger:'test'},
  {id:'offline',label:'弱网与恢复',terms:['断网','弱网','离线','网络恢复','恢复网络','丢包'],leadByScene:{saas:'server',web:'h5',app:'client'},lead:'client',collaborators:['server','service','h5'],challenger:'test'},
  {id:'media',label:'播放与互动体验',scenes:['ktv','car','app'],terms:['播放','点歌','舞蹈','数字人','歌词','语音','唱歌','伴奏','音响','麦克风','人声','混响'],lead:'client',collaborators:['server','op','pd'],challenger:'test'},
  {id:'car-audio',label:'车载音频与驻车边界',scenes:['car'],terms:['音频','焦点','驻车','车载','通话','声区'],lead:'client',collaborators:['project','pd','service'],challenger:'test'},
  {id:'privacy',label:'数据授权与撤回',terms:['隐私','个人信息','授权','录音','人脸','数据删除'],leadByScene:{saas:'server',web:'server'},lead:'client',collaborators:['server','h5','pd'],challenger:'test'},
  {id:'capacity',label:'服务容量与成本',terms:['并发','容量','成本','限流','延迟','高峰'],lead:'server',collaborators:['client','service','sales'],challenger:'test'},
  {id:'interaction',label:'页面与操作路径',terms:['扫码','页面','交互','表单','按钮','浏览器'],lead:'h5',collaborators:['client','pd','op'],challenger:'test'},
  {id:'operations',label:'运营配置与效果',terms:['活动','优惠','会员','转化','灰度','运营','内容审核'],lead:'op',collaborators:['pd','sales','server'],challenger:'test'},
  {id:'deployment',label:'交付与现场实施',terms:['部署','安装','工期','交付','现场'],lead:'project',collaborators:['client','server','service'],challenger:'test'},
  {id:'incident',label:'故障定位与恢复',terms:['故障','告警','回滚','运维','报障'],lead:'service',collaborators:['server','client','project'],challenger:'test'},
  {id:'value',label:'需求价值与边界',terms:['目标','收益','新点子','范围','需求边界'],lead:'pd',collaborators:['sales','op'],challenger:'test'}
];

export function routeQuestions(scene,text,roles=[]) {
  const key=sceneKey(scene),input=String(text || ''),selected=new Set(roles.map(r=>r.key));
  const issues=RULES.filter(r=>!r.scenes||r.scenes.includes(key)).flatMap(rule=>{
    const terms=rule.terms.filter(t=>input.toLowerCase().includes(t.toLowerCase()));
    if(!terms.length)return [];
    const desired=rule.leadByScene?.[key] || rule.lead;
    const quote=input.split(/[。；\n]/).find(line=>terms.some(t=>line.includes(t))) || input;
    const collaborators=rule.collaborators.filter(r=>r!==desired&&r!==rule.challenger&&selected.has(r));
    return [{id:rule.id,label:rule.label,quote,matched_terms:terms,lead:selected.has(desired)?desired:null,collaborators,challenger:selected.has(rule.challenger)?rule.challenger:null,missing_roles:[desired,rule.challenger].filter(r=>!selected.has(r))}];
  });
  if(!issues.length) issues.push({id:'clarify',label:'先澄清问题与专业边界',quote:input,matched_terms:[],lead:selected.has('pd')?'pd':null,collaborators:[],challenger:null,missing_roles:selected.has('pd')?[]:['pd']});
  return {version:'role-routing-v1',method:'场景与关键词规则匹配，需结合上下文核对；不代表语义识别或事实核验',issues};
}
