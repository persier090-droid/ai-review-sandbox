# vc +recording

命令事实以 `lark-cli vc +recording --help` 为准。

## 命令骨架

```bash
lark-cli vc +recording --meeting-ids <meeting_id> --as user
lark-cli vc +recording --calendar-event-ids <日程实例 ID> --as user
```

- `--meeting-ids` 与 `--calendar-event-ids` 二选一，都支持逗号分隔批量。
- 没有其它定位方式：本域只有 `+recording` 一个入口，只有会议链接或会议号时无法换到
  `meeting_id`，需向用户索取。

## 输出契约

关键字段：

| 字段 | 含义 |
|---|---|
| `recording_url` | 回看入口链接 |
| `duration` | 录制时长 |
| `minute_token` | 关联妙记 token，可交给 [lark-minutes](../lark-minutes/README.md) 的 `minutes +download` 下载音视频 |

## Agent 规则

- 用户问「能不能回看」「录了多久」时，直接转述 `recording_url` 与 `duration`，不必展开整个响应体。
- 批量查多个会议时用一次调用传逗号分隔的 ID，不要循环单查。
- 命令失败时把 `error.hint` 转述给用户；录制读取依赖高级权限，权限类报错要说明是权限问题，
  不要改用其它命令重试。
