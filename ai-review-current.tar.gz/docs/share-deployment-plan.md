# Small-group share deployment

Approved scope: HTTPS FRP access to this Mac, access-code login, isolated browser sessions, local cross-validation only. Original port 8000, data and API budget stay unchanged. No public anonymous access or API credentials in the shared process.

1. Add share-access.mjs: exact origin/host checks, constant-time password verification, bounded login attempts, expiring HttpOnly cookies, persistent opaque sessions and separate ReviewStore per session.
2. Add tests before implementation: unauthenticated API/WS denial, invalid password, cross-origin denial, two-session record isolation, expiry and local-only provider gate.
3. Integrate optional share access into server.mjs HTTP and WS paths; no changes to ordinary local operation. Share page shows only local mode.
4. Create private .share configuration, official FRP client and hostname mapping on loopback port 8001. Secrets and logs excluded from Git and handoff packages.
5. Verify locally through the intended Host/Origin, then open authenticated HTTPS tunnel and verify external HTTP, WS and a complete review with four artifacts. Keep a start/stop entry point and document the computer-on requirement.

Public activation must follow authorization for the exact domain and password-protected scope. Do not declare deployment complete until the externally reachable URL is verified.
