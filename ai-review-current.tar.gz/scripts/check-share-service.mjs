import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {passwordRecord} from '../share-access.mjs';
import {ROLE_PERSONAS} from '../role-personas.mjs';
const require=createRequire(import.meta.url);
const {ws:WebSocket}=require('/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright-core/lib/utilsBundle.js');
const root=fileURLToPath(new URL('../',import.meta.url)),dir=fs.mkdtempSync(path.join(os.tmpdir(),'share-service-'));
const origin='https://review-test.frp.ktvsky.com',host=new URL(origin).host,password='fixture-password-long-enough';
const config=path.join(dir,'access.json');fs.writeFileSync(config,JSON.stringify({origin,directory:path.join(dir,'shared'),...passwordRecord(password)}));
const reserve=http.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));const port=reserve.address().port;await new Promise(r=>reserve.close(r));
const cloud=process.argv.includes('--cloud');
const record=JSON.parse(fs.readFileSync(config,'utf8'));
const app=spawn(process.execPath,[cloud?'scripts/start-cloud.mjs':'server.mjs'],{cwd:root,env:{PATH:process.env.PATH,PORT:String(port),REVIEW_SHARE_CONFIG:config,REVIEW_DATA_DIR:path.join(dir,'base'),...(cloud?{REVIEW_PUBLIC_ORIGIN:origin,REVIEW_ACCESS_SALT:record.salt,REVIEW_ACCESS_HASH:record.passwordHash}:{})},stdio:['ignore','pipe','pipe']});
const request=(url,{cookie,body,site=origin}={})=>new Promise((resolve,reject)=>{
  const req=http.request({host:'127.0.0.1',port,path:url,method:body===undefined?'GET':'POST',headers:{host,origin:site,...(cookie?{cookie}:{}),...(body!==undefined?{'content-type':'application/x-www-form-urlencoded'}:{})}},res=>{let text='';res.on('data',d=>text+=d);res.on('end',()=>resolve({status:res.statusCode,headers:res.headers,text}));});req.on('error',reject);req.end(body);
});
function wsRequest(cookie,payload){return new Promise((resolve,reject)=>{
  const ws=new WebSocket(`ws://127.0.0.1:${port}/ws`,{headers:{host,origin,...(cookie?{cookie}:{})}});
  const timer=setTimeout(()=>{ws.terminate();reject(Error('WS timeout'));},30000);
  const finish=result=>{clearTimeout(timer);ws.close();resolve(result);};
  ws.on('unexpected-response',(_,r)=>{r.resume();finish({http:r.statusCode});});ws.on('error',reject);
  ws.on('open',()=>ws.send(JSON.stringify(payload)));ws.on('message',raw=>{const packet=JSON.parse(raw);if(['error','pong','result'].includes(packet.type))finish(packet);});
});}
try {
  await new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(Error('startup timeout')),15000);app.stdout.on('data',d=>{if(String(d).includes('AI review server')){clearTimeout(t);resolve();}});app.on('exit',()=>reject(Error('server stopped')));});
  assert.equal((await request('/api/health')).status,401);assert.equal((await wsRequest(null,{type:'ping'})).http,401);
  assert.match((await request('/')).text,/访问口令/);
  const login=async()=>{const r=await request('/login',{body:new URLSearchParams({password}).toString()});assert.equal(r.status,303);return r.headers['set-cookie'][0].split(';')[0];};
  const a=await login(),b=await login();
  assert.equal((await wsRequest(a,{type:'ping'})).type,'pong');
  assert.equal(JSON.parse((await request('/api/health',{cookie:a})).text).provider,'local');
  assert.equal((await request('/',{cookie:a,site:'https://evil.example'})).status,403);
  const html=(await request('/',{cookie:a})).text;assert.doesNotMatch(html,/<option value="ai"/);assert.match(html,/<option value="local" selected>/);
  assert.equal((await wsRequest(a,{reference_only:false,requirement:'must not call models',roles:ROLE_PERSONAS})).type,'error');
  const result=await wsRequest(a,{reference_only:true,scene:'ktv',roles:ROLE_PERSONAS,requirement:'本地分享联调：KTV消费者主动开启数字人伴舞，可关闭，不遮挡歌词、不改变原有点歌队列。'});
  assert.equal(result.type,'result');assert.equal(result.result.usage.calls,0);
  for(const stage of ['chat','score','risk','todo','prd'])assert.equal(result.result.workflow[stage],'complete');
  const id=result.result.review_id;assert.equal((await request('/api/reviews/'+id,{cookie:a})).status,200);assert.equal((await request('/api/reviews/'+id,{cookie:b})).status,404);
  assert.equal((await request('/.env',{cookie:a})).status,404);assert.equal((await request('/.share/access.json',{cookie:a})).status,404);
  const manual=await request('/api/manual/export',{cookie:a,body:'invalid'});assert.equal(manual.status,415);
  console.log('PASS: share login, denied anonymous HTTP/WS, cross-origin rejection, two-session record isolation, nine-role local review with four artifacts, model-call blocking, private file denial.');
}finally{app.kill();if(app.exitCode===null)await new Promise(r=>app.once('exit',r));fs.rmSync(dir,{recursive:true,force:true});}
