import fs from 'node:fs';
import crypto from 'node:crypto';
import {topics,conditions,sceneProfiles,sourceNotes} from '../evaluation/scenario-catalog.mjs';
import {ROLE_PERSONAS} from '../role-personas.mjs';

const read=path=>JSON.parse(fs.readFileSync(new URL(path,import.meta.url),'utf8'));
const original=read('../evaluation/ktv-innovation-60.json');
const foundations=new Map(read('../evaluation/ktv-scenario-foundation-60.json').cases.map(c=>[c.case_id,c]));
const cases=original.cases.map(c=>{
  const scenario=structuredClone(foundations.get(c.id));
  for(const task of scenario.artifacts.tasks)task.evidence_ids ??= scenario.validation.required_evidence;
  return {...c,scene:'ktv',topic_id:c.id,scenario};
});
const names=Object.fromEntries(ROLE_PERSONAS.map(r=>[r.key,r.name]));

for(const [scene,rows] of Object.entries(topics))for(const [topicIndex,row] of rows.entries())for(const [conditionIndex,condition] of conditions[scene].entries()) {
  const [rawTitle,keywords,actor,operation,invariant,failure,approach]=row;
  const title=rawTitle.replaceAll('車','车').replaceAll('載','载');
  const [label,trigger,method]=condition,p=sceneProfiles[scene];
  const number=(scene==='ktv'?60:0)+topicIndex*10+conditionIndex+1;
  const id=`${scene.toUpperCase()}-${String(number).padStart(3,'0')}`;
  const roles=['pd',p.lead,'test','op','service'];
  const premise=`本条是待验证场景：${actor}需要${operation}；假设${trigger}，尚无现场测量或执行记录。`;
  const reply=`建议先${approach}。这次只验证“${operation}”，以“${invariant}”作为观察目标。`;
  const reasoning=`${actor}关心的是能否完成“${operation}”。如果${failure}，即使入口能打开，也没有完成这项任务。是否值得扩大投入，要用发生频率、任务完成情况和维护成本判断。`;
  const challenge=`先确认一个边界：${trigger}时，会不会${failure}？如果只测正常操作，凭什么认为“${invariant}”也成立？`;
  const response=`这个担心成立，正常路径通过不能覆盖该条件。${approach}只是候选处理办法；还要${method}。出现“${failure}”就停止扩大范围，不用平均结果掩盖这条反例。`;
  const verify=`先固定${p.assets.join('、')}，以${p.baseline}作基线；${method}，再复做“${operation}”，记录预期与实际差异。`;
  const accept=`试验前确认样本、指标阈值及资源上限；在“${label}”样本中逐项证明“${invariant}”，且原有主流程与退出恢复回归通过。`;
  const overturn=`若复现“${failure}”，或“${invariant}”无法证明，暂停该条件下开放，保留记录并缩小范围；不能把缺少记录当作通过。`;
  const boundary=`仅评估${title}在“${label}”下的改动；不扩展其他功能，不承诺未测设备、组织、账号或版本。`;
  const costItems=[`${title}的${p.cost[0]}`,p.cost[1],`${label}专项验证及原流程回归`,p.cost[3]];
  const evidenceItems=[`${p.assets.join('、')}及原流程基线`,`${label}下“${operation}”的步骤、实际结果和差异`,`${title}的工作量、持续费用与停止条件核对记录`];
  const evidence=evidenceItems.join('；');
  const evidenceRequirements=evidenceItems.map((required,i)=>({id:`${id}-E${i+1}`,owner:[p.lead,'test','pd'][i],required,status:'待补充',provenance:'待采集，非已存在的现场证据'}));
  const tasks=[
    {owner:'pd',item:`确认${actor}执行“${operation}”的现状、频率及试验范围`,done_when:'记录明确来源的现状、收益假设和本轮不做项',evidence_ids:[`${id}-E1`]},
    {owner:p.lead,item:`拆解“${approach}”的依赖和人日，与运营核对持续费用`,cost_estimate:true,done_when:'估算注明版本、依赖、假设和资源上限，由责任人确认',evidence_ids:[`${id}-E3`]},
    {owner:'test',item:method,done_when:accept,evidence_ids:[`${id}-E2`]},
    {owner:'service',item:`为“${failure}”准备发现、定位和恢复步骤`,done_when:'按本场景完成一次可追溯恢复演练，确认原流程可用',evidence_ids:[`${id}-E2`]}
  ].map((t,i)=>({...t,id:`${id}-T${i+1}`,priority:i===2?'高':'中',due:'进入试验前，由责任人确认日期',validation_id:`${id}-V1`}));
  const risk={text:`${trigger}时可能${failure}`,level:conditionIndex===0?'中':'高',impact:'待澄清',owner:p.lead,status:'候选风险，尚未复现',evidence_ids:[`${id}-E2`]};
  const prd={功能概述:`为${actor}提供${operation}的候选能力，${boundary}`,业务流程:`${actor}${operation}；${approach}；失败时显示真实状态并回到原有流程。`,前置条件:`确认${p.assets.join('、')}，核对许可、权限和适用范围。`,功能规则:`${invariant}；${approach}。`,异常处理:`重点覆盖${trigger}；${failure}时按记录定位并停止扩大范围。`,开发分工:`产品确认边界；${names[p.lead]}拆解实现及依赖；测试负责${label}反例；运营和售后核对恢复。`,运营配置:'参数、权限、发布范围均记录版本；试验前指定配置与撤回负责人。',交付售后:`交付${p.assets.join('、')}清单及诊断恢复步骤，未验证范围不作承诺。`,风险清单:risk.text,验收标准:`${verify}。${accept} ${overturn}`};
  const roleViews={
    pd:`站在${actor}的角度，先看“${operation}”是否解决已有问题。${approach}可以列为候选，但本轮不扩大到其他功能；请补充现在怎么做、多久发生一次，再决定投入。`,
    sales:`从采购和承诺范围看，我还不能把“${invariant}”写成已具备的能力。先确认${actor}是否愿意为这项改善试用或投入，再按验证过的版本列交付范围；没有现状对比，收益只能是假设。`,
    op:`实际执行上，要有人负责“${operation}”的配置和撤回。尤其${trigger}时，不能让操作者自己猜结果。我建议先定配置负责人、异常反馈入口和复核记录，再开放试用。`,
    project:`交付依赖要先列清：${p.assets.join('、')}。这些条件没确认，${title}就不能报固定工期；先在声明的试验范围验证“${label}”，通过后再安排扩大。`,
    client:scene==='ktv'||scene==='car'?`终端侧我关注“${operation}”对原有声音和操作的影响。${approach}；但要同时测${p.baseline}，出现“${failure}”不能靠重启掩盖，必须有可验证的退出恢复路径。`:`客户端侧先检查“${operation}”的状态归属和恢复。${trigger}时，界面不能沿用过期的成功状态；需要与服务端核对当前对象和结果，再允许继续操作。`,
    server:`服务端要区分发起、实际完成和重试，不能收到请求就记成功。围绕“${operation}”保留对象身份、版本和处理结果；${trigger}时先查真实状态，避免重复效果或越权。没有服务端改动的部分不额外扩建设计。`,
    h5:`从${actor}的操作路径看，“${operation}”至少要让人分清处理中、已完成和可取消。${trigger}时，页面要显示实际状态和下一步；退出后也不能把旧结果当成新结果。`,
    test:challenge,
    service:`售后首先需要能区分“${failure}”发生在哪个环节。请保留${p.assets.join('、')}及失败时间；恢复后复测“${operation}”和原流程。一次恢复成功不能代替${label}的回归。`
  };
  cases.push({id,scene,topic_id:`${scene}-${topicIndex+1}`,condition_index:conditionIndex,condition_label:label,title:`${title} · ${label}`,question:`${actor}希望${operation}。当${trigger}时，如何保证${invariant}？`,keywords:keywords.split(' '),actor,roles,premise,reply,reasoning,challenge,response,evidence,verify,accept,overturn,boundary,mutation:`如果出现${failure}，是否仍可推进？`,updated_reply:overturn,cost_items:costItems,sources:p.sources,role_views:roleViews,
    scenario:{case_id:id,title:`${title} · ${label}`,status:'模拟验证场景，待确认适用',context:{setting:p.name,trigger,affected_actor:actor,baseline:p.baseline,assets:p.assets,known_facts:[],hypotheses:[invariant],open_questions:[`实际是否发生“${failure}”？`,'发生频率、成本上限和样本是什么？'],out_of_scope:boundary},participants:roles.map(key=>({key,name:names[key],perspective:ROLE_PERSONAS.find(r=>r.key===key).professional_view,responsibility:roleViews[key]})),business_flow:[{actor,action:operation,expected:invariant,status:'待验证'}],evidence_requirements:evidenceRequirements,
      validation:{id:`${id}-V1`,owner:'test',baseline:p.baseline,method:verify,success:accept,falsifier:overturn,exception:failure,required_evidence:evidenceRequirements.map(e=>e.id),thresholds:{status:'待试验前确认',rule:'固定样本、指标、阈值与费用上限，不在结果出来后追改门槛'},execution:{status:'未执行',records:[]}},
      discussion:{lead:p.lead,challenger:'test',question:challenge,reference_response:response},decision:{rules:['当前事实与建议分开','初评只决定是否值得验证','正式放行须完成证据与责任确认'],pass:{condition:accept},reject:{condition:overturn},defer:{condition:'缺少现场资料',result:'先安排最小验证'},current_result:'尚无现场验证结果'},artifacts:{tasks,risk,prd_sections:prd,score:{weights:{necessity:30,cost:25,validation:30,scope:15},total:null,meaning:'待结合本轮输入计算验证准备度，不是上线分'},order:['智能评测','风险看板','待办任务','交付文档']},follow_up:{input:`${trigger}，怎么处理？`,expected_revision:'保留当前范围，重新核对受影响条件',reopen_when:'新增输入或可定位的验证证据',invalidates:['旧假设覆盖范围','受影响验收记录']},learning:{status:'待人工确认',confirmation_requires:['来源与版本可追溯','适用范围已核对','反例与验证记录完整'],withdrawal:'出现反例或版本变化后撤回已确认经验'}}});
}
const payload={version:'multiscene-1000-v1',count:cases.length,composition:'保留60条KTV案例；94个专业主题分别覆盖10种运行条件，共新增940个模拟验证场景。不是1000次实测，也不是模型实时生成。',sources:sourceNotes,source_hash:crypto.createHash('sha256').update(fs.readFileSync(new URL('../evaluation/scenario-catalog.mjs',import.meta.url))).digest('hex'),cases};
if(cases.length!==1000)throw new Error(`Expected 1000, got ${cases.length}`);
const output=new URL('../evaluation/review-cases-1000.json',import.meta.url),content=JSON.stringify(payload,null,2)+'\n';
if(process.argv.includes('--check')) {
  if(!fs.existsSync(output)||fs.readFileSync(output,'utf8')!==content)throw new Error('Case library is stale; regenerate it');
  console.log('1000 case library matches its authored sources');
} else {fs.writeFileSync(output,content);console.log(`Generated ${cases.length} cases`);}
