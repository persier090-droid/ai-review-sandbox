# apps cache

调试妙搭应用的运行时缓存：查看某个缓存 key 的内容用 `+cache-get`，删除单个 key 用 `+cache-delete`，清空某个环境的全部缓存用 `+cache-clear`。缓存是应用为了加速而临时存放的数据，删除或清空后，应用下次用到时会自动重新取最新数据。

环境 flag 使用 `--environment`；所有命令都需 `--app-id "$app_id"`。

## 命令一览

| 命令 | 做什么 | risk | 关键参数 |
|---|---|---|---|
| `+cache-get` | 查一个缓存 key 的内容与信息 | read | `--key`、`--environment`、`--format` |
| `+cache-delete` | 删一个缓存 key（不需 `--yes`） | write | `--key`、`--environment` |
| `+cache-clear` | 清空指定环境下的全部缓存 | high-risk-write | `--environment`、`--yes` |

## 环境的默认落点（写操作前必读）

缓存按运行环境隔离。不传 `--environment` 时按应用当前的环境配置自动选择：有多环境的应用落到 `dev`，**没有多环境的应用直接落到 `online`（生产）**。返回结果里的 `environment` 会告诉你这次实际操作了哪个环境。

因此：`+cache-clear` / `+cache-delete` 这类写操作，不确定应用有没有多环境时**显式传 `--environment`**；纯查看的 `+cache-get` 影响小，可以省略。

## 查看

`+cache-get` 按 `--key` 查单个缓存。命中时返回是否存在、剩余有效期（TTL）、内容及其大小；未命中或已过期时只返回 `exists=false`、不带内容。

没有「只看信息、不取内容」的模式——每次查询都会连内容一起返回，内容可能较大。只是想确认「在不在 / 还有多久过期」时，留意别占用太多上下文。

`--format json`（默认）原样返回缓存内容，适合精确比对；`--format pretty` 会把内容格式化展开，更便于阅读。

```bash
lark-cli apps +cache-get --app-id "$app_id" --key <key>
lark-cli apps +cache-get --app-id "$app_id" --environment online --key <key> --format pretty
```

## 删除单个 key

重复删、或删一个本就不存在的 key，**都算成功**（返回删除数量 0），不会报错；删中则返回删除数量 1。删掉后应用下次会自动重新取最新数据，影响小，故不需 `--yes`。

用户只描述了业务含义、没给准确 key 时，先对齐 key 再删。

```bash
lark-cli apps +cache-delete --app-id "$app_id" --environment dev --key <key>
```

## 清空环境缓存（高风险）

`+cache-clear` 清空当前应用在**指定环境**下的全部缓存，用于定位不到具体 key 时的快速恢复。影响面是整个环境，是 `high-risk-write`：遵循 SKILL.md 的 exit-10 审批协议——先让用户确认环境无误、说明会清掉该环境全部缓存，再传 `--yes`。不要自动补 `--yes`。返回本次清除的 key 数量。

```bash
lark-cli apps +cache-clear --app-id "$app_id" --environment dev --dry-run
lark-cli apps +cache-clear --app-id "$app_id" --environment dev --yes
```

## 错误与边界

- key 是否合法（非空、长度等）由服务端校验，不合法会返回带说明的错误。
- 缓存服务暂时不可用时按 `error.hint` 转述给用户，这类可稍后重试。

## 反模式

- 不要在不确定应用是否多环境时省略写操作的 `--environment`——可能直接清掉线上缓存。
- 不要为了「只看 TTL」而反复调用 `+cache-get`：它总会带回内容，多次调用会白占上下文。
- 不要把 `+cache-clear` 当常规排查手段；先用 `+cache-get` 定位具体 key，定位不到才考虑清空。
