import fs from 'node:fs';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
let lucide;
try {lucide=require('lucide');} catch {lucide=require('/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/lucide');}
const icons={human:['UserRound','#2563eb','#eff6ff'],facilitator:['MessagesSquare','#475569','#f1f5f9'],pd:['ClipboardList','#2563eb','#eff6ff'],sales:['Handshake','#b45309','#fffbeb'],op:['SlidersHorizontal','#0f766e','#f0fdfa'],project:['HardHat','#b45309','#fffbeb'],client:['Monitor','#0369a1','#f0f9ff'],server:['Server','#475569','#f1f5f9'],h5:['PanelsTopLeft','#7e22ce','#faf5ff'],test:['ShieldCheck','#15803d','#f0fdf4'],service:['Headset','#be123c','#fff1f2'],custom:['UserRoundCog','#52525b','#f4f4f5']};
const directory=new URL('../assets/avatars/',import.meta.url);fs.mkdirSync(directory,{recursive:true});
for(const [role,[name,color,background]] of Object.entries(icons)) {
  const paths=lucide[name].map(([tag,attributes])=>`<${tag} ${Object.entries(attributes).map(([key,value])=>`${key}="${value}"`).join(' ')}/>`).join('');
  fs.writeFileSync(new URL(`${role}.svg`,directory),`<!-- Lucide icons, ISC license; see LICENSE.txt. -->\n<svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 48 48"><rect width="48" height="48" rx="24" fill="${background}"/><g transform="translate(12 12)" fill="none" stroke="${color}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${paths}</g></svg>\n`);
}
const packagePath=require.resolve('lucide/package.json',{paths:['/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules']});
fs.copyFileSync(new URL('./LICENSE',`file://${packagePath}`),new URL('LICENSE.txt',directory));
console.log('Generated 12 local role avatars.');
