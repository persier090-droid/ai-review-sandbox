export const FREE_MODEL_IDS=['openrouter/free','google/gemma-4-31b-it:free','nex-agi/nex-n2.5-pro:free','nex-agi/nex-n2.5-mini:free'];
export const freeAttemptBudget=(roles,batched=true)=>batched?Math.ceil(roles/3)*2+(roles>1?7:4):18;
export function providerFailure(status,headers,body,provider='OpenRouter') {
  const metadata=body?.error?.metadata;
  const platformLimit=['x-ratelimit-limit','x-ratelimit-remaining','x-ratelimit-reset'].some(name=>headers.has(name));
  const source=status!==429?null:platformLimit?'platform':metadata?.provider_name||metadata?.provider_code?'provider':'unknown';
  const hint=headers.get('retry-after');
  const retryAfter=hint===null?null:/^\d+$/.test(hint)?Number(hint):Math.max(0,Math.ceil((Date.parse(hint)-Date.now())/1000));
  const explanation=source==='provider'?'模型上游限流，可尝试一次其他免费路由':source==='platform'?'平台请求限额受限，暂停重试，等待额度恢复':source==='unknown'?'请求受限，暂无法区分平台或模型上游限制，暂停重试':'';
  return Object.assign(new Error(`${provider} 请求未完成 (${status})${explanation?'：'+explanation+'；不回退付费模型':''}`),{status,rate_limit_source:source,retry_after_seconds:Number.isFinite(retryAfter)?retryAfter:null});
}
export function createFreeCaller({model,request,notify=()=>{},maxAttempts=18}) {
  if(!FREE_MODEL_IDS.includes(model)) throw new Error('禁止调用非白名单免费模型');
  let attempts=0, consecutiveFailures=0,preferred=model;
  const call=async(prompt,signal,options)=>{
    if(consecutiveFailures>=2) throw Object.assign(new Error('免费服务暂不可用，已停止重复请求；保留本轮记录'),{code:'FREE_CIRCUIT_OPEN'});
    const candidates=[preferred,...FREE_MODEL_IDS.filter(m=>m!==preferred)].slice(0,2);
    let lastError;
    for(let i=0;i<candidates.length;i++) {
      signal?.throwIfAborted();
      if(attempts>=maxAttempts) throw Object.assign(new Error('已达到本轮免费请求上限'),{code:'REVIEW_BUDGET'});
      attempts++;
      try {
        const result=await request(candidates[i],prompt,signal,options);
        preferred=candidates[i];consecutiveFailures=0;return result;
      } catch(error) {
        lastError=error;
        if(signal?.aborted) throw error;
        const transient=[404,408,500,502,503,504].includes(error.status)||(error.status===429&&error.rate_limit_source==='provider')||['TimeoutError','TypeError'].includes(error.name);
        if(!transient) throw error;
        if(i===0) notify({type:'recovery',status:'free_fallback',model:candidates[1],attempts,message:'当前免费模型暂不可用，正在切换一次免费路由；价格上限仍为0'});
      }
    }
    consecutiveFailures++;
    throw lastError;
  };
  call.stats=()=>({attempts,max_attempts:maxAttempts,consecutive_failures:consecutiveFailures});
  return call;
}
