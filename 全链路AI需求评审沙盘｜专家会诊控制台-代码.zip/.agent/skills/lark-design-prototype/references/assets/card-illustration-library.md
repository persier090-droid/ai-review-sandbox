# Cloud Card Illustration Library Index

This index is used for welcome banners, recommended content, business cards, product entries, empty states, avatars, product images, and important entry icons in workspaces, office home pages, collaboration workspaces, portal aggregation pages, CRM home pages, and sales dashboards. Whenever a page needs illustration or visual assets, match a cloud CDN image URL from this file first, then consider UD illustrations, UD icons, product screenshots, avatar assets, or generated-image capability.

## Accessibility Judgment

- Current images use versioned, content-hashed URLs on the public `lf3-static.bytednsdoc.com` CDN and require no intranet or VPN access.
- Images can be referenced directly in `<img src="...">`, CSS `background-image`, or an `Image` component.
- All 28 assets were verified after upload with `HTTP 200`, `content-type: image/png`, cross-origin access, and byte-for-byte SHA-256 matching.
- For offline delivery or environments that block public network access, copy only the selected asset into the project and record that local fallback in `media_plan`.

## Asset Source

- Source type: cloud CDN URL.
- Asset format: PNG.
- Maintenance: no longer require maintaining built-in `assets/card-illustrations/` image files inside the skill, and no longer require copying assets into demo or project asset folders.
- Usage: pages reference `asset_url` directly. During implementation, keep stable `alt` copy and record tags, URL, dimensions, slot, and semantic match reason in `media_plan`.
- Protection rules: do not stretch or distort; do not use high-saturation filters or heavy shadows that damage the original feel.

## Matching Flow

1. First write `media_decision` and decide whether the current module needs a visual anchor. Hero, welcome areas, recommended content, product entries, empty states, workspace home pages, and business summaries that carry first-glance explanation should plan a visual anchor by default. Dense data pages, settings pages, audit pages, table-first flows, ordinary metric cards, and pure operation entries can use no image.
2. When an image is needed, extract keywords from the module title, business object, user task, and media responsibility, then choose the semantically closest asset.
3. When multiple assets are close, choose by visual expression, graphic ratio, and slot responsibility. Product-interface-like visuals suit business summaries and capability explanations. 3D characters, brand IP, or event atmosphere visuals suit brand banners, welcome areas, and lightweight entries.
4. When the same area needs multiple illustrations, prefer assets with similar style and same or close ratios. Avoid mixing 3D characters, product screenshots, abstract graphics, and dark event images in one group, which creates visual jumps.
5. Size and ratio are only adaptation conditions. If the semantics fit but the ratio is imperfect, first adjust the slot, `object-fit`, alignment, and whitespace.
6. Record a minimal `media_plan`: `library_lookup`, `source_library`, `matched_asset`, `asset_url`, `semantic_match_reason`, `slot`, `handling`, and `fallback`.
7. `library_lookup` contains at least `searched_keywords`, `candidate_assets`, `decision`, and `reject_reason`. If the library has a semantically close and accessible asset, use the library first and do not generate imagery just for novelty.
8. Use `generated_bitmap` only when the library lacks a suitable asset, the CDN is inaccessible, or the current slot needs a more specific avatar, product image, data visual, or entry icon.

## Generated-Image Fallback

Generated-image prompts are assembled dynamically from the current slot: page topic, module position, module title / description, visual responsibility, content type, target ratio, and style fragment. Read `references/visual-style-prompts.md` for the style fragment.

Generated content may only be the independent visual element for the current media slot. The theme must match the current module, such as data visual, workflow thumbnail, light illustration, avatar, product image, entry icon, empty-state graphic, or recommendation cover. The style should be polished, minimal, light, and related to Feishu / Lark enterprise products. It may become a local visual focus, but must not overpower the title, main content, or actions. Do not generate a full page UI, complete dashboard, navigation bar, sidebar, table page, button/form combination, or browser shell.

## Slot Suggestions

- `top-cover`: recommended content, news cards, template cards.
- `left-cover` / `right-cover`: horizontal recommendation cards, business summary cards.
- `hero-side`: welcome areas, first-screen summaries, AI / data side visuals.
- `product-entry`: related apps, product entries, and lightweight tool cards.
- `recommendation-card`: recommended content, templates, knowledge, project materials, and learning entries. Prefer this slot when cards only have title and description, to avoid an entire recommendation group becoming only outlined icons.

Images may use `contain` or `cover`, but do not stretch, distort, crop out the subject, or only reveal a corner. Media slots keep rounded clipping consistent with nearby card structure.

## Asset Catalog

| Tags | Size | Applicable Scenarios | Recommended Role | URL |
| --- | --- | --- | --- | --- |
| welcome banner, home workspace, personal greeting, to-do reminder, avatar, female character, 3D cartoon, smiling expression, assistant image, Hi bubble, onboarding, task reminder | 332x200 | Home workspace, welcome area, personal greeting, onboarding, to-do reminder, assistant image | Lightweight visual anchor on the right side of a welcome banner, suitable for a small `hero-side` image placed to the right | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-01-02097d2d.png |
| plan upgrade, capacity expansion, storage space, recommendation banner, dark background, rocket, file card, membership benefits, SaaS upsell | 720x404 | Plan upgrade, capacity expansion, membership benefits, SaaS upsell, dark recommendation banner | Dark recommendation card or banner visual; text must follow dark-card adaptation rules | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-02-45e578fb.png |
| sales growth and forecast, sales data chart | 640x542 | CRM, sales dashboard, sales growth, forecast, opportunity value, data dashboard | CRM home first-screen visual, sales summary card, data-insight recommendation card, suitable for `hero-side` or business summary side visual | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-03-64ee2c23.png |
| AI analysis, sentiment analysis, feedback record, user feedback, positive, neutral, negative, tag classification, comment insight, text analysis, lightweight card | 560x400 | AI analysis, comment insight, user feedback, sentiment analysis, tag classification, text analysis | AI insight card, feedback summary card, lightweight data-analysis card, suitable for `hero-side` or horizontal business card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-04-ef825ae6.png |
| process analysis, process-driven, data insight, list view, filter sort, business analysis, multiple document types, pink background, lightweight data board | 542x300 | Process analysis, process-driven workflows, business analysis, multi-document summary, filter sort, data insight | Recommended content card, business analysis card, process insight card, suitable for `top-cover` or left/right cover | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-05-b052d37e.png |
| approval, activity feed, timeline, member avatars, comment record, collaboration progress, workflow state, yellow background, information summary | 542x300 | Approval, activity feed, comment record, workflow state, collaboration progress, timeline | Approval entry card, collaboration progress card, workflow-state summary card, suitable for `top-cover` or left/right cover | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-06-c10ae25c.png |
| news recommendation, activity location, map, positioning, route, lightweight card, blue background, workspace recommendation | 542x300 | News recommendation, activity location, map, positioning, route, workspace recommendation | Recommended content card, event recommendation card, location-related information card, suitable for `top-cover` or left/right cover | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-07-1b748e45.png |
| project members, team collaboration, member avatars, project plan, progress planning, task assignment, collaboration space, pink background, team management | 542x300 | Project members, team collaboration, project plan, task assignment, progress planning, team management | Project collaboration card, team management card, task assignment entry, suitable for `top-cover` or left/right cover | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-08-4b79c828.png |
| meeting summary, customer visit, attendees, avatar group, time reminder, dark card, schedule summary, meeting record | 448x320 | Meeting summary, customer visit, attendees, schedule summary, time reminder, meeting record | Meeting summary card, visit reminder card, dark meeting recommendation card, suitable for dark medium card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-09-b2a05a1c.png |
| Lark Base, product brand, purple representation, circular orbit, smart tool, data management, business workflow, product onboarding | 336x150 | Base, data management, business workflow, smart tool, product entry | Brand visual for related apps, product entries, and tool cards, suitable for `product-entry` | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-10-b0a2bdf4.png |
| Lark Projects, project management, IPD, OTD, ITR, process management, circular orbit, project collaboration, product entry | 672x300 | Lark Projects, project management, IPD, OTD, ITR, process management, project collaboration, product entry | Project management entry card, related app card, process-management recommendation card, suitable for `product-entry` or horizontal cover | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-11-0c5eec64.png |
| Lark brand, open platform, AI capability, leaderboard, upload, app marketplace | pending browser confirmation | Open platform, app marketplace, AI capability entry, leaderboard, upload capability | Platform capability entry card, app marketplace recommendation card, product capability display | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-12-bc72c5b2.png |
| ratio-4x3, Base, sales data, customer growth, data visualization, business analysis, radar chart, line chart, metric dashboard | 4:3 | Base, sales data, customer growth, business analysis, data visualization, metric dashboard | Data product first-screen side image, business analysis summary, sales dashboard cover, suitable for `hero-side` or business summary card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-13-e8f37c0f.png |
| ratio-16x10, content analysis, data dashboard, hit-content monitoring, AI crawling, trend insight, chart statistics, operation growth, dashboard interface | 16:10 | Content operations, hit-content analysis, AI crawling, trend insight, data dashboard, growth analysis | Operations analysis tool cover, AI data insight card, content growth summary, suitable for `top-cover` or wide business card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-14-1a32918c.png |
| ratio-2x1, Lark brand, enterprise AI, brand key visual, city nightscape, technology feel, promo banner, brand slogan | 2:1 | Lark brand, enterprise AI, brand promotion, urban technology, event banner, brand slogan | Brand key visual, enterprise AI promo banner, event page header image, suitable for `top-cover` or wide hero background | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-15-abddbc0b.png |
| ratio-3x2, Lark Projects, project management, AI weekly report, AI workforce analysis, AI fields, project breakdown, progress summary | 3:2 | Lark Projects, project breakdown, AI weekly report, AI workforce analysis, AI fields, progress summary | Project management capability explanation, AI project weekly report cover, project summary side image, suitable for `hero-side` or business summary card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-16-53d86cf3.png |
| ratio-4x3, project management, task branches, workflow breakdown, node relationship, light illustration, abstract graphic, collaboration flow | 4:3 | Project management, task branches, workflow breakdown, node relationship, collaboration flow, light illustration | Workflow entry, project empty state, task decomposition explanatory image, suitable for `product-entry`, `empty-state`, or lightweight card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-17-59982e20.png |
| ratio-3x2, smart meeting notes, meeting summary, video meeting, key-point extraction, data insight, AI summary, meeting collaboration | 3:2 | Smart meeting notes, meeting summary, video meeting, key-point extraction, AI summary, data insight, meeting collaboration | Meeting-notes product introduction, meeting summary card, collaboration scene banner, suitable for `hero-side` or wide business card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-18-1ae872e2.png |
| ratio-3x2, Aily agent, AI assistant, personal intelligent partner, Lark skills, message handling, meeting handling, schedule documents | 3:2 | Aily agent, AI assistant, personal intelligent partner, Lark skills, messages, meetings, schedules, documents | Agent welcome area, AI assistant capability display, personal productivity tool entry, suitable for `hero-side` or welcome banner | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-19-95bfcecb.png |
| ratio-3x2, OpenClaw, agent platform, intelligent assistant, role agent, chat interface, team collaboration, cartoon character | 3:2 | OpenClaw, agent platform, role agent, intelligent assistant, chat interface, team collaboration | Agent platform introduction, role assistant entry, OpenClaw product capability page, suitable for `hero-side` or product entry combination | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-20-ffaad10d.png |
| ratio-2x1, OpenClaw character, Lark brand, cartoon lobster, brand IP, relaxed lively, product mascot | 2:1 | OpenClaw character, Lark brand, cartoon IP, mascot, relaxed lively, brand display | Light brand banner, OpenClaw character introduction, event entry header image, suitable for `top-cover` or wide welcome area | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-21-9cd56c8f.png |
| ratio-4x3, OpenClaw brand, cartoon lobster, Lark graphic, brand key visual, cloud technology, 3D illustration | 4:3 | OpenClaw brand, cartoon lobster, Lark graphic, cloud technology, 3D illustration, brand key visual | OpenClaw brand side image, cloud technology theme card, product entry visual, suitable for `hero-side` or `product-entry` | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-22-5da10b53.png |
| ratio-16x10, hot-news push, enterprise magazine, content distribution, news aggregation, mobile sync, announcement notification, news list | 16:10 | Hot-news push, enterprise magazine, news aggregation, announcement notification, news list, mobile sync, content distribution | Portal news card, enterprise magazine recommendation, daily hot-topic entry, suitable for `top-cover` or recommended content card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-23-19c8e0f4.png |
| ratio-4x3, Miaoda, low-code, app building, page generation, code generation, visual development, product icon | 4:3 | Miaoda, low-code, app building, page generation, code generation, visual development, product icon | Low-code tool entry, app-building recommendation card, Miaoda product introduction, suitable for `product-entry` or `hero-side` | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-24-00f110f4.png |
| ratio-16x10, software R&D, requirement management, defect management, iteration management, R&D collaboration, work item management, engineering efficiency | 16:10 | Software R&D, requirement management, defect management, iteration management, R&D collaboration, work item management, engineering efficiency | R&D management system cover, requirement / defect management entry, engineering efficiency summary, suitable for `top-cover` or wide business card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-25-c6377703.png |
| ratio-16x10, AI video generation, product video, template generation, marketing content, e-commerce assets, video production, AI creation | 16:10 | AI video generation, product video, template generation, marketing content, e-commerce assets, video production, AI creation | AI creation tool cover, product video generation entry, marketing asset production card, suitable for `top-cover` or wide tool card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-26-3ef5bcd5.png |
| ratio-1x1, cloud docs, document creation, knowledge accumulation, content editing, office collaboration, glassmorphism, light illustration | 1:1 | Cloud docs, document creation, knowledge accumulation, content editing, office collaboration, glassmorphism | Document empty state, knowledge base entry, content creation recommendation, suitable for `empty-state`, `product-entry`, or square card | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-27-e52b52f4.png |
| ratio-16x9, OpenClaw event banner, brand event, cartoon lobster, technology trend, 3D character, key visual banner | 16:9 | OpenClaw event banner, brand event, cartoon lobster, technology trend, 3D character, key visual Banner | Event key visual, OpenClaw brand banner, dark technology theme header, suitable for `top-cover` or hero background | https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/illustrations/illustration-28-111453dd.png |

## Usage Rules

- This library only serves modules that need visual anchors. It does not require every business card to have an image.
- Card theme, module title, and business action have priority over image color or size.
- Control visual intensity when multiple illustrations appear on one screen, so every image does not become a visual center.
- When combining multiple images in the same area, prefer unified ratio and expression type: product UI images for data groups, 3D characters or brand banners for brand groups, abstract graphics or product icons for lightweight entries.
- Dark assets only enter dark banners or clearly dark cards.
- For external delivery, replace internal CDN images with public URLs or project-local assets when the CDN is not accessible.

## `media_plan` Mini Example

```md
media_plan:
- source_library: card-illustration-library
  library_lookup:
    searched_keywords:
    candidate_assets:
    decision: use_library / reject_library
    reject_reason:
  matched_asset: asset tags closest to module semantics
  asset_url:
  semantic_match_reason:
  slot: hero-side / top-cover / product-entry / empty-state
  handling: contain / cover; preserve subject; keep rounded clipping
  fallback: generated_bitmap or local asset if CDN unavailable
```

## Checklist

- Image semantics match the module title and user task.
- Image renders for real, with no gray box, blank color block, or temporary placeholder.
- Image ratio is stable, with no stretching, squeezing, blur, or cropped-out key subject.
- Before using `generated_bitmap`, `library_lookup` and the reason the library does not fit have been recorded.
- When using `generated_bitmap`, the generated image only serves the current media slot.
