// Credit balances are not request quota. Only the explicit daily counter is used.
export function createQuotaGuard({baseUrl,apiKey,fetchImpl=fetch,now=Date.now}) {
  let cache=null,cachedAt=0,pending=null;
  const inspect=async({force=false,signal}={})=>{
    if(!apiKey)return {state:'auth_error',message:'未配置OpenRouter密钥；可使用网页模型协作',free_only:true};
    if(!force&&cache&&now()-cachedAt<15000)return {...cache};
    if(pending)return pending;
    pending=(async()=>{
      let result;
      try {
        const response=await fetchImpl(`${baseUrl.replace(/\/$/,'')}/key`,{headers:{Authorization:`Bearer ${apiKey}`},signal:signal?AbortSignal.any([signal,AbortSignal.timeout(5000)]):AbortSignal.timeout(5000)});
        const data=await response.json();
        const q=data?.data?.free_model_daily_requests;
        if([401,403].includes(response.status))result={state:'auth_error',message:'OpenRouter密钥无效或无访问权限；请检查服务端密钥，或转网页模型继续'};
        else if(response.ok&&q&&['used','limit','remaining'].every(k=>Number.isInteger(q[k])&&q[k]>=0)&&q.remaining<=q.limit) {
          const reset=new Date(now());reset.setUTCHours(24,0,0,0);
          result={state:'known',used:q.used,limit:q.limit,remaining:q.remaining,reset_at:reset.toISOString()};
        }else result={state:'unknown',message:'暂未取得免费次数，不能据此判断额度为零'};
      }catch(error){if(signal?.aborted)throw error;result={state:'unknown',message:'暂时无法查询免费次数，模型请求仍按免费限制执行'};}
      cache={...result,free_only:true,checked_at:new Date(now()).toISOString()};cachedAt=now();return {...cache};
    })();
    try{return await pending;}finally{pending=null;}
  };
  return {
    inspect,
    recordAttempt(){if(cache?.state==='known'){cache.remaining=Math.max(0,cache.remaining-1);cache.used++;}},
    async ensure(required=1,signal){
      const status=await inspect({signal});
      if(status.state==='auth_error')throw Object.assign(new Error(status.message),{code:'OPENROUTER_AUTH',status:401});
      const minimum=Number.isInteger(required)&&required>0?required:1;
      if(status.state==='known'&&status.remaining<minimum)throw Object.assign(new Error(`今日免费请求剩余${status.remaining}次，完成当前讨论至少需要${minimum}次；已保留进度，请转网页模型继续或在额度恢复后重试`),{code:'FREE_QUOTA_INSUFFICIENT',status:429,rate_limit_source:'platform',remaining:status.remaining,required_requests:minimum,reset_at:status.reset_at});
      return status;
    }
  };
}
