> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 评审结论结构 review-conclusion

## 用途
定义评审结论的标准结构，确保结论明确、可执行、可追踪。

## 结论结构


conclusion:
  review_id: 编号
  topic: 议题
  review_type: 需求/方案/交付/质量/复盘
  timestamp: 时间
  
  decision: 通过/有条件通过/不通过/延期
  
  summary: 一句话总结
  
  consensus:
    - item: 共识内容
      level: 全体一致/多数同意/主答决定/裁决决定
      owner: 责任人
      deadline: 时间点
      verification: 验证方式
  
  disagreements:
    - item: 分歧内容
      type: 事实/判断/优先级/责任
      resolution: 裁决结果
      minority_opinion: 保留意见
      review_trigger: 复盘触发条件
  
  conditions:  # 有条件通过时
    - condition: 条件内容
      verifier: 验证人
      verify_by: 验证时间
      fallback: 不满足时的处理
  
  execution:
    - item: 执行项
      owner: 责任人
      deadline: 时间点
      deliverable: 交付物
  
  risks:
    - risk: 风险内容
      probability: 高/中/低
      impact: 高/中/低
      mitigation: 兜底策略
  
  predictions:
    - metric: 指标
      value: 预测值
      confidence: 置信度
      verify_by: 验证时间
  
  review_at: 复盘节点
  next_action: 下一步
四种结论的处理

通过

立即执行
跟踪执行项
到复盘节点复盘
有条件通过

先满足条件
条件验证通过后执行
条件未满足则回退重新评审
不通过

说明不通过原因
给出改进方向
约定重新评审时间
延期

说明延期原因
约定补充材料
约定重新评审时间
结论的合格标准

决策明确（不含糊）
共识可执行（有责任人+时间点+验证）
分歧有处理（裁决+保留意见）
风险有兜底
prediction 可回填
禁止行为

禁止无结论
禁止结论无责任人
禁止结论无时间点
禁止分歧无保留意见
