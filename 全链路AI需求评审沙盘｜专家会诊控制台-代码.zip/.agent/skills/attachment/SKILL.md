---
name: attachment
description: "附件预处理 / Attachment Preprocessing. Use when user mentions attachments, uploaded files, or shared files. 当用户提到附件、上传文件或共享文件时使用；仅负责列出、解压和读取 .agent/{conversation_id}/attachments 下的文件，后续处理由文件内容和用户意图决定。"
metadata:
  display-names:
    zh-CN: 附件预处理
    en-US: Attachment Preprocessing
---

# Attachment Preprocessing

Preprocess user-uploaded attachments to make them accessible for subsequent workflows.

**Important**: This skill only handles attachment preprocessing (listing, extracting, reading). Subsequent processing workflows should be determined based on the extracted file contents.

## Storage Location

```text
.agent/{conversation_id}/attachments/
```

## Preprocessing Steps

### 1. List Attachments

```bash
ls -la .agent/{conversation_id}/attachments/
```

### 2. Handle Archives

For `.zip` and other archive files, preview first then extract:

```bash
# Preview contents
unzip -l .agent/{conversation_id}/attachments/archive.zip

# Extract in place
unzip -o .agent/{conversation_id}/attachments/archive.zip -d .agent/{conversation_id}/attachments/
```

### 3. Read Files

Use the Read tool to read text file contents.

## What Happens Next

After preprocessing, **determine subsequent processing based on file contents**:

- Code files → May need analysis, refactoring, or project integration
- Config files → May need to apply to project configuration
- Data files → May need data analysis or visualization
- Image files → May need to copy to project resource directories
- Document files → May need reading, comprehension, or information extraction

**This skill does not prescribe specific processing methods** — determine based on user intent and file contents.

## Notes

- All operations are confined to `.agent/{conversation_id}/attachments/` directory
- Use `offset` and `limit` parameters when reading large files
- Attachments may be cleaned up after conversation ends
