> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 校准基线 calibration-baseline v2.0

> 每条校准规则标注 confidence 和 source。
> v2.0 新增：断言级校准——当断言被回填数据推翻时，自动触发断言修订。

## 校准机制升级

### 结论级校准（原有）
预测值偏差 → 归因 → 修正判断阈值 → 写入 calibration 字段

### 断言级校准（新增，v2.0）
断言被回填数据推翻 → 标记断言为“待修订” → 触发断言更新 → 更新 assertion-library

## 各角色校准规则

### 销售专家


calibration:
  - rule: KTV回本周期估算需强制加入网络改造前置条件，未评估前不得报≤6个月的回本周期
    confidence: 高
    source: 行业实施经验
    assertion_ref: sales-roi-001
  - rule: 下沉市场单店设备预算通常在3万元以下，超过需附加ROI说明
    confidence: 高
    source: 区域市场数据
  - rule: 报价应预留15%-20%议价空间
    confidence: 中
    source: 渠道政策惯例

assertion_calibration:
  - assertion_id: sales-roi-001
    trigger: 预测回本周期连续3次偏短（实际比预测长30%以上）
    action: 将替换周期基准从“3-5年”调整为“2-4年”，并增加“网络改造前置条件”作为必选假设
    last_triggered: null
项目经理


calibration:
  - rule: 未评估客户现场网络条件前，不得报最终工期
    confidence: 高
    source: 行业实施经验
  - rule: 声场调试时间按每包厢2-4小时估算，超过8个包厢需增加驻场天数
    confidence: 中
    source: 工程实践
    assertion_ref: pm-delivery-001
  - rule: 连锁KTV标准化部署时，每个门店现场差异至少预留1天缓冲
    confidence: 高
    source: 连锁项目经验
    assertion_ref: pm-delivery-002

assertion_calibration:
  - assertion_id: pm-delivery-001
    trigger: 实际声场调试时间连续3次超过4小时/包厢
    action: 将基准调整为“3-5小时/包厢”
    last_triggered: null
产品专家


calibration:
  - rule: 单个客户提出的定制需求，默认不纳入通用产品规划，除非有≥5个客户提出类似需求
    confidence: 高
    source: 产品管理原则
  - rule: 任何新功能的验收指标必须在开发启动前定义
    confidence: 高
    source: 产品管理原则
  - rule: AI语音点歌的用户使用率初期通常低于20%，需3-6个月用户教育期
    confidence: 中
    source: 行业AI功能采纳数据
    assertion_ref: product-user-001

assertion_calibration:
  - assertion_id: product-user-001
    trigger: AI语音点歌上线后实际使用率连续3个月超过30%
    action: 将基准从“低于20%”调整为“低于30%”，并缩短用户教育期
    last_triggered: null
客户端研发


calibration:
  - rule: 低端机型（2GB RAM以下）的UI动效必须降级为2D
    confidence: 高
    source: 终端性能测试
    assertion_ref: client-perf-001
  - rule: OTA升级包体每增加10MB，升级失败率上升约0.5%
    confidence: 中
    source: OTA运维数据
  - rule: 连续运行12小时后内存增长超过20%判定为泄漏
    confidence: 高
    source: 长稳测试标准
    assertion_ref: client-perf-002

assertion_calibration:
  - assertion_id: client-perf-001
    trigger: 低端机2D降级后帧率仍低于25fps
    action: 增加“低端机还需关闭后台服务”作为附加条件
    last_triggered: null
服务端研发


calibration:
  - rule: 全国峰值QPS = 线性估算的60%-70%
    confidence: 中
    source: 分布式系统经验
    assertion_ref: server-capacity-001
  - rule: 每次ASR调用的边际成本约0.002元
    confidence: 中
    source: 云服务定价
    assertion_ref: server-cost-001
  - rule: 三端状态同步的强一致方案成本约为最终一致的3-5倍
    confidence: 高
    source: 分布式系统经验
    assertion_ref: server-cost-002

assertion_calibration:
  - assertion_id: server-capacity-001
    trigger: 实际全国峰值QPS连续3次超过线性估算的80%
    action: 将系数从“60%-70%”调整为“70%-80%”
    last_triggered: null
测试专家


calibration:
  - rule: 长稳测试必须覆盖连续12小时以上，否则不予放行
    confidence: 高
    source: 行业质量规范
    assertion_ref: qa-weaknet-002
  - rule: 弱网测试需覆盖丢包率5%、10%、20%三档
    confidence: 高
    source: 测试标准
    assertion_ref: qa-weaknet-001
  - rule: 并发测试需覆盖单店200并发，P99 < 500ms
    confidence: 高
    source: 容量规划标准
    assertion_ref: qa-perf-001

assertion_calibration:
  - assertion_id: qa-weaknet-001
    trigger: 实际弱网测试在丢包率5%时成功率低于98%
    action: 将阈值从“98%/95%/85%”调整为“95%/90%/80%”
    last_triggered: null
H5/移动端开发


calibration:
  - rule: 微信小程序实名认证增加2步，流失率增加10%-15%
    confidence: 中
    source: 小程序运营数据
    assertion_ref: h5-conv-002
  - rule: KTV场所WiFi丢包率高于家庭环境2-3倍
    confidence: 中
    source: 现场网络测试
    assertion_ref: h5-network-001
  - rule: 扫码到点歌每增加1步，转化率下降8%-12%
    confidence: 中
    source: 移动端转化数据
    assertion_ref: h5-conv-001

assertion_calibration:
  - assertion_id: h5-conv-001
    trigger: 实际转化率下降幅度连续3次超过15%
    action: 将基准从“8%-12%”调整为“10%-15%”
    last_triggered: null
