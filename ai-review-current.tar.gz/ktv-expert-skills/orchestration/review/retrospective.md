> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 复盘规则 retrospective

## 用途
在约定时间对评审结论进行复盘，验证预测、归因偏差、生成校准规则。

## 复盘触发

- prediction 字段的 verify_by 到达
- 评审结论的 review_at 到达
- 执行项全部完成或全部逾期
- 重大偏差发生（±30% 以上）

## 复盘流程
到达复盘节点
→ 收集实际结果
→ 对比原始预测
→ 计算偏差
→ 归因分析（四类归因）
→ 生成校准规则
→ 更新 calibration-baseline
→ 更新 assertion-library（如涉及断言）
→ 案例入库


## 归因四类

| 归因类型 | 含义 | 修正方向 |
|---|---|---|
| 场景识别错 | 还原场景与实际不符 | 修正场景还原模板 |
| 约束遗漏 | 漏掉关键硬约束 | 补充约束清单 |
| 模型参数偏 | 估算系数偏差 | 校准阈值 |
| 执行偏差 | 方案执行未到位 | 修正交付清单 |

## 复盘输出


retrospective:
  review_id: 所属评审
  reviewed_at: 复盘时间
  predictions:
    - metric: 指标
      predicted: 预测值
      actual: 实际值
      deviation: 偏差
      deviation_rate: 偏差率
      attribution: 归因类型
      reason: 原因
      calibration_rule: 生成的校准规则
  overall_quality: 优秀/良好/一般/差
  lessons_learned: [经验教训]
  actions: [后续行动]
复盘质量评估

维度	标准
预测覆盖率	所有 prediction 都被复盘
归因准确性	归因到四类之一，有具体原因
校准可操作性	生成的规则可被执行
案例可复用性	案例字段完整
禁止行为

禁止不复盘
禁止归因写"经验不足"
禁止不生成校准规则
禁止不复盘直接关闭评审
