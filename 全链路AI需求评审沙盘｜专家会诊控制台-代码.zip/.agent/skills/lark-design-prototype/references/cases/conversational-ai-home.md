# Conversational AI Home Case Inspiration

case_id: conversational-ai-home-001
reference_weight: low

Applies to: AI assistant home pages, conversational tools, knowledge Q&A, and agent entries.

## Borrowable

- The main anchor is the input area, assistant identity, recommended questions, or recent conversations.
- Sidebar may carry agents, history, favorites, and settings.
- AI visuals may use slight blue-purple, avatar, halo, or dynamic icon treatment, but stay restrained.
- Recommended questions are specific and scenario-based, not vague prompts.
- Input area keeps real interaction capability and tool entries.

## Risk Reminders

- Page UI uses gradients;
- Input area is over-decorated;
- AI visual steals focus from the primary task;
- Recommended questions have no specific content;
- Sidebar buttons and navigation items are centered as a whole;
- Input, buttons, menus, and floating layers are rendered as unstyled ordinary `div` elements.

## Free To Change

Whether a sidebar is needed, recommended question count, assistant identity expression, tool entries, history, and visual anchor are decided by the current task.
