import { readFile, realpath, stat } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { exactKeys, selectTurn, validateInputs } from './benchmark-ktv-prompt.mjs';

const root = new URL('../', import.meta.url);
const paths = {
  source: 'evaluation/ktv-innovation-60.json',
  inputs: 'evaluation/ktv-variant-benchmark/inputs/scenarios.json',
  manifest: 'evaluation/ktv-variant-benchmark/private/manifest.json',
  rubrics: 'evaluation/ktv-variant-benchmark/private/rubrics.json'
};
const sourceReferenceFields = ['reply', 'reasoning', 'challenge', 'response', 'evidence', 'verify', 'accept', 'overturn', 'mutation', 'updated_reply'];
const transformations = ['natural_rewrite', 'batched_input', 'contradictory_material', 'resolved_material', 'withdrawn_premise'];
const expectedCounts = { families: 12, positive_cases: 12, holdout_cases: 12, positive_turns: 12, holdout_turns: 60, total_turns: 72, categories: 10 };
const sha256 = text => createHash('sha256').update(text).digest('hex');
const norm = text => text.normalize('NFKC').replace(/[\s\p{P}\p{S}]/gu, '').toLowerCase();
const check = (condition, message) => { if (!condition) throw new Error(message); };
const hasText = value => typeof value === 'string' && value.trim().length > 0 && !value.includes('\uFFFD');
const stringArray = value => Array.isArray(value) && value.length > 0 && value.every(hasText);

function strings(value) {
  if (typeof value === 'string') return [value];
  if (Array.isArray(value)) return value.flatMap(strings);
  if (value && typeof value === 'object') return Object.values(value).flatMap(strings);
  return [];
}

function validateCheckpoint(point, turn, visibleText, location) {
  exactKeys(point, ['turn_id', 'decision', 'criteria', 'critical_errors', 'evidence_anchors'], location);
  check(point.turn_id === turn, `${location}: checkpoint turn mismatch`);
  check(hasText(point.decision) && stringArray(point.criteria) && stringArray(point.critical_errors), `${location}: missing reasoning criteria`);
  check(stringArray(point.evidence_anchors), `${location}: missing factual anchors`);
  for (const anchor of point.evidence_anchors) {
    check(visibleText.includes(anchor), `${location}: anchor absent from visible history: ${anchor}`);
  }
}

function validateIsolation(inputs, manifest, rubrics, source) {
  const text = JSON.stringify(inputs);
  check(!text.includes(manifest.canary), 'isolation: private canary present');
  check(!/(?:参考答案|隐藏判读标准|PRIVATE_KTV_VARIANTS_|(?:updated_reply|critical_errors|positive_case_id|holdout_case_id|evidence_anchors)["\s]*[:：])/u.test(text), 'isolation: reference marker present');
  const publicStrings = strings(inputs).map(norm);
  // Factual anchors may legitimately overlap; the prose expressing judgments may not.
  const privateProse = [
    ...rubrics.global_rules,
    ...rubrics.families.flatMap(f => [f.positive, ...f.holdout].flatMap(p => [p.decision, ...p.criteria, ...p.critical_errors])),
    ...source.cases.flatMap(item => sourceReferenceFields.flatMap(key => typeof item[key] === 'string' ? [item[key]] : []))
  ];
  for (const prose of privateProse) {
    const reference = norm(prose);
    for (let offset = 0; offset <= reference.length - 24; offset++) {
      const fragment = reference.slice(offset, offset + 24);
      check(!publicStrings.some(value => value.includes(fragment)), 'isolation: 24-character reference prose overlap');
    }
  }
  return privateProse.length;
}

function validateBundle(bundle) {
  const { source, inputs, manifest, rubrics, sourceHash } = bundle;
  validateInputs(inputs);
  exactKeys(manifest, ['schema_version', 'simulation', 'visibility', 'canary', 'source_file', 'source_sha256', 'source_case_count', 'expected_counts', 'holdout_policy', 'turn_protocol', 'families'], 'manifest');
  check(manifest.schema_version === '1.0' && manifest.simulation === true && manifest.visibility === 'reviewer_only', 'manifest: status mismatch');
  check(/^PRIVATE_KTV_VARIANTS_[a-z0-9]+_DO_NOT_SEND$/.test(manifest.canary), 'manifest: missing private canary');
  check(manifest.source_file === paths.source && manifest.source_sha256 === sourceHash, 'source: fingerprint drift; review and deliberately rebaseline before use');
  check(manifest.source_case_count === 60 && source.cases.length === 60, 'source: expected original 60 cases');
  check(new Set(source.cases.map(c => c.id)).size === 60, 'source: duplicate ID');
  check(hasText(manifest.holdout_policy), 'manifest: missing holdout disclosure');
  exactKeys(manifest.expected_counts, Object.keys(expectedCounts), 'expected_counts');
  for (const [key, value] of Object.entries(expectedCounts)) check(manifest.expected_counts[key] === value, `counts: expected ${key}=${value}`);
  check(Array.isArray(manifest.turn_protocol) && manifest.turn_protocol.length === 5, 'protocol: expected five stages');
  for (const [index, item] of manifest.turn_protocol.entries()) {
    exactKeys(item, ['turn_id', 'transformation', 'relationship'], 'protocol');
    check(item.turn_id === index + 1 && item.transformation === transformations[index] && hasText(item.relationship), 'protocol: invalid transformation sequence');
  }
  exactKeys(rubrics, ['schema_version', 'simulation', 'visibility', 'reference_kind', 'global_rules', 'dimensions', 'pass_policy', 'families'], 'rubrics');
  check(rubrics.schema_version === '1.0' && rubrics.simulation === true && rubrics.visibility === 'reviewer_only', 'rubrics: status mismatch');
  check(rubrics.reference_kind === 'argument_criteria_not_fixed_answers' && stringArray(rubrics.global_rules), 'rubrics: missing argument-only policy');
  check(Array.isArray(rubrics.dimensions) && rubrics.dimensions.length === 4, 'rubrics: expected four dimensions');
  check(rubrics.dimensions.map(d => d.id).join(',') === 'premise,decision,verification,scope', 'rubrics: invalid dimensions');
  for (const dimension of rubrics.dimensions) {
    exactKeys(dimension, ['id', 'name', 'score_0', 'score_1', 'score_2'], 'dimension');
    check(Object.values(dimension).every(hasText), 'rubrics: incomplete score scale');
  }
  exactKeys(rubrics.pass_policy, ['minimum_total', 'maximum_total', 'no_zero_dimension', 'critical_error_blocks', 'case_pass_requires_all_turns', 'unresolved_reviewer_disagreement', 'note'], 'pass_policy');
  const policy = rubrics.pass_policy;
  check(policy.minimum_total === 7 && policy.maximum_total === 8 && policy.no_zero_dimension === true && policy.critical_error_blocks === true && policy.case_pass_requires_all_turns === true && policy.unresolved_reviewer_disagreement === 'pending_not_pass' && hasText(policy.note), 'rubrics: scoring policy mismatch');
  check(Array.isArray(manifest.families) && manifest.families.length === 12, 'manifest: expected 12 families');
  check(Array.isArray(rubrics.families) && rubrics.families.length === 12, 'rubrics: expected 12 families');
  check(new Set(rubrics.families.map(f => f.family_id)).size === 12, 'rubrics: duplicate family');
  const seenFamilies = new Set();
  const seenCases = new Set();
  const seenSources = new Set();
  const categoryCounts = {};
  let positiveTurns = 0;
  let holdoutTurns = 0;
  for (const family of manifest.families) {
    exactKeys(family, ['family_id', 'source_case_id', 'category', 'positive_case_id', 'holdout_case_id'], 'family');
    check(/^f\d{2}$/.test(family.family_id) && !seenFamilies.has(family.family_id), 'manifest: invalid or duplicate family');
    seenFamilies.add(family.family_id);
    const original = source.cases.find(item => item.id === family.source_case_id);
    check(original && original.category === family.category, `${family.family_id}: invalid source lineage/category`);
    check(!seenSources.has(family.source_case_id), 'manifest: duplicate source family');
    seenSources.add(family.source_case_id);
    categoryCounts[family.category] = (categoryCounts[family.category] ?? 0) + 1;
    const positive = inputs.cases.find(c => c.case_id === family.positive_case_id);
    const holdout = inputs.cases.find(c => c.case_id === family.holdout_case_id);
    check(positive && holdout, `${family.family_id}: missing public case`);
    for (const id of [family.positive_case_id, family.holdout_case_id]) {
      check(!seenCases.has(id), 'manifest: positive/holdout overlap or reused case');
      seenCases.add(id);
    }
    check(positive.turns.length === 1 && holdout.turns.length === 5, `${family.family_id}: expected 1 positive + 5 holdout turns`);
    positiveTurns += positive.turns.length;
    holdoutTurns += holdout.turns.length;
    const rubric = rubrics.families.find(f => f.family_id === family.family_id);
    check(rubric, `${family.family_id}: missing rubric`);
    exactKeys(rubric, ['family_id', 'positive', 'holdout'], 'family rubric');
    check(Array.isArray(rubric.holdout) && rubric.holdout.length === 5, `${family.family_id}: missing turn criteria`);
    validateCheckpoint(rubric.positive, 1, positive.turns[0].content, `${family.family_id}/positive`);
    for (const [index, checkpoint] of rubric.holdout.entries()) {
      validateCheckpoint(checkpoint, index + 1, holdout.turns.slice(0, index + 1).map(t => t.content).join('\n'), `${family.family_id}/holdout/${index + 1}`);
    }
  }
  const counts = { families: seenFamilies.size, positive_cases: seenFamilies.size, holdout_cases: seenFamilies.size, positive_turns: positiveTurns, holdout_turns: holdoutTurns, total_turns: positiveTurns + holdoutTurns, categories: Object.keys(categoryCounts).length };
  for (const [key, value] of Object.entries(expectedCounts)) check(counts[key] === value, `counts: ${key} mismatch`);
  check(inputs.cases.length === 24 && seenCases.size === inputs.cases.length, 'inputs: unmapped or missing cases');
  check(Object.keys(categoryCounts).sort().join('') === 'ABCDEFGHIJ', 'coverage: expected original ten categories');
  const scannedReferences = validateIsolation(inputs, manifest, rubrics, source);
  let exportedTurns = 0;
  for (const scenario of inputs.cases) {
    for (const turn of scenario.turns) {
      const payload = selectTurn(inputs, scenario.case_id, turn.turn_id);
      const expected = { messages: [...(turn.turn_id === 1 ? [{ role: 'system', content: inputs.instruction }] : []), { role: 'user', content: turn.content }] };
      check(JSON.stringify(payload) === JSON.stringify(expected), 'export: extra fields, history, or future turn');
      check(!JSON.stringify(payload).includes(manifest.canary), 'export: private canary leaked');
      for (const future of scenario.turns.filter(t => t.turn_id > turn.turn_id)) {
        check(!JSON.stringify(payload).includes(future.content), 'export: future turn leaked');
      }
      exportedTurns++;
    }
  }
  return { counts, category_family_counts: categoryCounts, transformation_case_counts: Object.fromEntries(transformations.map(t => [t, 12])), reference_prose_scanned: scannedReferences, checked_single_turn_exports: exportedTurns };
}

async function loadBundle() {
  const files = {};
  const identities = new Set();
  for (const [name, relative] of Object.entries(paths)) {
    const path = fileURLToPath(new URL(relative, root));
    check(await realpath(path) === path, `filesystem: redirected path refused for ${name}`);
    const info = await stat(path);
    check(info.isFile(), `filesystem: not a regular file: ${name}`);
    const identity = `${info.dev}:${info.ino}`;
    check(!identities.has(identity), 'filesystem: shared inode between input/reference/source files');
    identities.add(identity);
    const raw = await readFile(path, 'utf8');
    files[name] = { raw, data: JSON.parse(raw), sha256: sha256(raw) };
  }
  return {
    bundle: { source: files.source.data, sourceHash: files.source.sha256, inputs: files.inputs.data, manifest: files.manifest.data, rubrics: files.rubrics.data },
    hashes: Object.fromEntries(Object.entries(files).map(([name, file]) => [paths[name], file.sha256]))
  };
}

function selfTest(bundle) {
  const tests = [
    ['answer field in public input', 'unexpected or missing fields', b => { b.inputs.cases[0].reply = 'hidden'; }],
    ['private field inside turn', 'unexpected or missing fields', b => { b.inputs.cases[0].turns[0].critical_errors = []; }],
    ['missing simulation label', 'missing simulation label', b => { b.inputs.cases[0].turns[0].content = '真实已验证'; }],
    ['duplicate public ID', 'duplicate ID', b => { b.inputs.cases[1].case_id = b.inputs.cases[0].case_id; }],
    ['missing positive case', 'missing public case', b => { b.inputs.cases.shift(); }],
    ['missing holdout turn', 'expected 1 positive + 5 holdout turns', b => { b.inputs.cases[12].turns.pop(); }],
    ['reordered turn IDs', 'turns must be consecutive', b => { b.inputs.cases[12].turns[1].turn_id = 3; }],
    ['source fingerprint drift', 'fingerprint drift', b => { b.sourceHash = '0'.repeat(64); }],
    ['invalid source lineage', 'invalid source lineage/category', b => { b.manifest.families[0].source_case_id = 'KTV-999'; }],
    ['split overlap', 'overlap or reused case', b => { b.manifest.families[0].holdout_case_id = b.manifest.families[0].positive_case_id; }],
    ['missing turn rubric', 'missing turn criteria', b => { b.rubrics.families[0].holdout.pop(); }],
    ['rubric cites future fact', 'anchor absent from visible history', b => { b.rubrics.families[0].holdout[0].evidence_anchors = ['310ms']; }],
    ['private canary in prompt', 'private canary present', b => { b.inputs.cases[0].turns[0].content += b.manifest.canary; }],
    ['embedded reference marker', 'reference marker present', b => { b.inputs.cases[0].turns[0].content += '隐藏判读标准：支持'; }],
    ['copied original answer', 'reference prose overlap', b => { b.inputs.cases[0].turns[0].content += b.source.cases[0].reply; }],
    ['copied hidden argument', 'reference prose overlap', b => { b.inputs.cases[0].turns[0].content += b.rubrics.families[0].positive.criteria[0]; }],
    ['weakened expected count', 'expected positive_cases=12', b => { b.manifest.expected_counts.positive_cases = 1; }]
  ];
  const passed = [];
  for (const [name, expectedError, mutate] of tests) {
    const altered = structuredClone(bundle);
    mutate(altered);
    let error;
    try { validateBundle(altered); } catch (failure) { error = failure; }
    check(error?.message.includes(expectedError), `self-test failed: ${name}; got ${error?.message ?? 'accepted invalid bundle'}`);
    passed.push(name);
  }
  for (const [caseId, turnId] of [['q-00', 1], ['q-17', 2], ['q-17', 0]]) {
    let rejected = false;
    try { selectTurn(bundle.inputs, caseId, turnId); } catch { rejected = true; }
    check(rejected, `self-test failed: invalid export ${caseId}/${turnId}`);
    passed.push(`invalid export ${caseId}/${turnId}`);
  }
  return { passed: passed.length, failed: 0, checks: passed };
}

try {
  const args = process.argv.slice(2);
  check(args.length === 0 || (args.length === 1 && args[0] === '--self-test'), 'usage: node scripts/benchmark-ktv-variants.mjs [--self-test]');
  const { bundle, hashes } = await loadBundle();
  const validation = validateBundle(bundle);
  const negativeTests = args.includes('--self-test') ? selfTest(bundle) : { status: 'not_run' };
  console.log(JSON.stringify({
    status: 'structure_and_literal_isolation_passed',
    ...validation,
    source_case_count: bundle.source.cases.length,
    physical_isolation: 'separate_regular_files_distinct_inodes_no_redirects',
    public_schema: 'strict_allowlist',
    literal_overlap_minimum_normalized_characters: 24,
    file_sha256: hashes,
    negative_tests: negativeTests,
    model_evaluation: 'not_run',
    human_semantic_evaluation: 'not_run',
    field_validation: 'not_run',
    external_model_calls: 0,
    knowledge_writes: 0,
    limitation: 'Counts, reference anchors, file boundaries and literal overlap only; semantic equivalence, paraphrased leakage, factual sufficiency and model quality still require human evaluation.'
  }, null, 2));
} catch (error) {
  console.error(JSON.stringify({ status: 'failed', error: error.message, model_evaluation: 'not_run' }));
  process.exitCode = 1;
}
