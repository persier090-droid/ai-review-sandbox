import {localCrossChecks} from './review-local-reference.mjs';
import {localScope} from './review-local-scope.mjs';
import {assessFeasibility} from './review-feasibility.mjs';
import {assessComprehensive} from './review-comprehensive.mjs';

export const PRELIMINARY_VERSION='preliminary-v4';
// Cost workstreams are proposed estimation inputs, not quotes or staffing commitments.
const costs={
  A:['素材制作与授权','播放或渲染接入','设备兼容与性能测试','素材发布和维护'],
  B:['歌曲元数据与检索','点歌交互改造','识别或推荐效果测试','曲库更新维护'],
  C:['多人会话与消息同步','内容治理和退出机制','并发与异常测试','门店现场处理'],
  D:['订单状态与服务台对接','员工接单和履约流程','撤销及异常恢复测试','员工培训与运行维护'],
  E:['计费规则与账务对接','支付退款和对账','交易异常及权限测试','客服与财务处理'],
  F:['授权或数据处理范围核对','权限、留存与删除能力','供应商能力核查','内容审核和持续维护'],
  G:['终端适配与资源评估','网络和故障恢复','边界设备及长时测试','升级回滚与运维'],
  H:['门店配置和系统接入','部署及权限改造','灰度验收和回滚测试','培训及巡检'],
  I:['触达与经营流程配置','埋点及效果对照','激励或活动支出','门店执行和复盘'],
  J:['模型请求与数据整理','上下文和工具接入','输出核验及失败恢复','监测与人工复核']
};
const fragments=text=>String(text).split(/[。；\n]/).map(s=>s.trim()).filter(Boolean);
function quote(text,pattern) {return fragments(text).find(s=>pattern.test(s)) || '';}

export function assessPreliminary(review) {
  const candidate=localScope(review),input=candidate.input || candidate.latest;
  // Re-retrieve from the current input so cached references never revive retired scope.
  const pending=candidate.status==='clarify';
  const ref=pending?null:localCrossChecks({...review,roles:review.roles || []})[0];
  const costItems=ref?(ref.cost_items || costs[ref.category] || []):[];
  const source=ref?`${ref.case_id} 案例建议，待确认适用`:'无匹配案例';
  const feasibility=assessFeasibility(review,costItems);
  const comprehensive=assessComprehensive(review,{reference:ref,feasibility,pending});
  const audience=feasibility.factors.audience;
  const benefit=feasibility.factors.goal;
  const consequence=feasibility.factors.problem;
  const budget=feasibility.cost.budget?.quote || quote(input,/工期.{0,10}\d+\s*(天|周|月|人日|人天)/);
  const scope=feasibility.factors.boundary;
  const dimensions=[];
  const check=(label,weight,value,origin,missing)=>({label,weight,points:value&&!origin.includes('案例')?weight:0,source:value?origin:'缺失',basis:value || missing});
  const dimension=(key,name,checks)=>{const weight=checks.reduce((n,c)=>n+c.weight,0),earned=checks.reduce((n,c)=>n+c.points,0);dimensions.push({key,name,weight,earned,checks});};
  dimension('necessity','必要性定义',[
    check('明确受影响对象',10,audience || ref?.actor,audience?'提交内容（未独立核验）':source,'明确是哪类商户、员工或包厢消费者'),
    check('说明收益假设及理由',10,benefit || ref?.reasoning,benefit?'提交内容（未独立核验）':source,'说明希望改善哪个具体问题'),
    check('给出现状或不做的代价',10,consequence,'提交内容（未独立核验）','补充现状、发生频率或不做的影响')
  ]);
  dimension('cost','成本拆解',[
    check('识别实现与持续运营工作',15,feasibility.cost.workload.map(w=>w.quote).join('、')||costItems.join('、'),feasibility.cost.workload.length?'提交估算（未独立核验）':source,'补充涉及的系统、改造环节和持续维护工作'),
    check('明确预算或工期约束',10,budget,'提交约束（不是报价）','技术负责人估人日；运营核对持续费用，提出者确认上限')
  ]);
  dimension('validation','验证设计',[
    check('可执行的对照方法',15,feasibility.factors.method||ref?.verify,feasibility.factors.method?'提交方案（尚待执行）':source,'选定对象和原流程对照，安排一次最小试验'),
    check('明确成功条件',10,feasibility.factors.success||ref?.accept,feasibility.factors.success?'提交条件（尚待验证）':source,'在试验前确定指标、阈值和样本，不在看到结果后改标准'),
    check('明确停止条件',5,feasibility.factors.stop||ref?.overturn,feasibility.factors.stop?'提交条件（尚待验证）':source,'明确什么结果出现后暂停或缩小范围')
  ]);
  dimension('scope','需求边界',[
    check('描述具体功能',10,ref?input:quote(input,/(新增|增加|改为|支持|实现|允许|关闭|开启)/),'提交内容（未独立核验）','说明谁在什么情况下做什么、得到什么结果'),
    check('限定本轮范围',5,scope || ref?.boundary,scope?'提交范围':source,'列出本轮不做的内容')
  ]);
  const score=dimensions.reduce((n,d)=>n+d.earned,0);
  const recommendation=comprehensive.recommendation;
  const gaps=dimensions.flatMap(d=>d.checks.filter(c=>!c.points).map(c=>c.basis));
  const roles=review.roles || [];
  const lead=ref?.roles[0] || (roles.some(r=>r.key==='pd')?'pd':roles[0]?.key);
  const owner=roles.find(r=>r.key===lead)?.name || '需求提出者';
  return {
    version:PRELIMINARY_VERSION,score,dimensions,recommendation,feasibility,comprehensive,release_authorized:false,
    label:'初步验证评分',scope:'衡量验证准备度，不是商业价值、成功概率或上线放行分；案例方案尚待确认',
    formula:'必要性定义30 + 成本拆解25 + 验证设计30 + 需求边界15；只对本次提交的可定位内容计分，案例建议及缺失项为0；不是需求价值分',
    source:ref?'本地1000条场景案例与本轮输入的规则初评，非模型实时生成':'本轮输入的规则初评，未匹配到案例',
    input,case_id:ref?.case_id || null,owner,gaps,
    necessity:ref?(ref.reasoning.startsWith(ref.actor)?ref.reasoning:`${ref.actor}：${ref.reasoning}`):'尚未明确需求收益。先说明受影响对象、现有问题和不做的代价。',
    proposal:pending?'明确这次保留、取消和新增的要求，再重评受影响部分。':ref?.reply || '先补齐目标对象、当前做法、具体改动和资源上限，再确定试验方案。',
    cost:{items:costItems,estimate:null,constraint:budget || '未提供预算和工期',formula:'一次性成本 = 各岗位人日 × 人日成本 + 授权/接入费用；持续成本 = 调用/存储/带宽 + 运营及售后',note:'暂不能报总价或工期；上述为待估工作项，只保留本次范围涉及的部分'},
    validation:{method:ref?.verify || '需求提出者补充一个真实操作场景，由选中岗位确认目标和约束',success:ref?.accept || '对象、问题、目标和资源上限明确后重新评审',stop_when:ref?.overturn || '仍不能解释改动收益时，不进入开发排期',evidence:ref?.evidence || '现状记录、目标说明及资源约束',thresholds:'样本、指标阈值和费用上限须在试验前由责任人确认'},
    risk:ref?.scenario?.artifacts?.risk || null,
    next_action:comprehensive.focus.length?comprehensive.focus.slice(0,2).map(d=>`${d.owners[0]}：${d.action}`).join('；'):'确认候选方案适用性，按约定方法记录实测结果后复核。'
  };
}
