// Sparse TF-IDF vectors run entirely in memory. This is not an embedding model.
const synonyms=[
  [/数字人|虚拟人|虚拟舞伴|虚拟伴舞|虚拟形象/, '数字人 伴舞 舞蹈'],
  [/跳舞|跳支舞|伴舞|舞蹈展示/, '伴舞 舞蹈'],
  [/唱歌|演唱|练歌|练唱|卡拉\s*ok|k歌/i, '演唱 唱歌'],
  [/耳返|听(见|到)?自己的声音|人声.*慢半拍/, '耳返 人声 延迟'],
  [/延时|延迟|慢半拍|跟不上|不同步/, '时延 延迟 同步'],
  [/话筒|麦克风|开麦/, '麦克风 话筒'],
  [/啸叫|尖叫声|刺耳(的)?声音/, '啸叫 反馈'],
  [/调音|均衡器|音效预设|低音太重/, '调音 均衡'],
  [/断网|断线|没网|网络断|网断|网不好|掉线|弱网/, '断网 弱网 断连'],
  [/连回来|重新连接|重连|恢复网络/, '重连 恢复'],
  [/大屏|看板|旧数字|实时数据|实时指标/, '大屏 实时 指标'],
  [/过期数据|旧数字|旧数据|不是最新/, '数据 过期'],
  [/重复扣|扣(了)?两次|重复收费/, '重复 扣款 幂等'],
  [/重复提交|连续点击|点了两次|双击/, '重复 提交 幂等'],
  [/客户分层|客户分级|客户等级|客户升降级/, '客户 分级 等级'],
  [/积分换|积分兑换|用积分|积分商城/, '积分 兑换 商城'],
  [/别家(公司|企业)|别的(公司|企业)|其他(公司|企业)|跨(公司|企业|租户)|[AB甲乙两]公司.*[AB甲乙另]公司/, '租户 隔离 越权'],
  [/撤权|收回权限|撤回权限|权限取消|没权限/, '权限 撤回 授权'],
  [/恢复原状|退回旧版|回滚|恢复旧版/, '回滚 恢复'],
  [/登录失效|登录过期|会话过期|登不上/, '登录 会话 过期'],
  [/被系统杀|闪退|杀进程|进程终止/, '进程 恢复'],
  [/录音删除|删除录音|不让录音|停止录音/, '录音 撤回 删除'],
  [/多个页面|两个页面|多标签|两个标签/, '多标签 并发 冲突']
];
const stop=new Set(['功能','新增','是否','用户','本次','可以','需要','进行','我们','问题','ktv','移动','应用','车载','后台','操作','查看','记录','管理','理员','人员','支持','消费','费者','希望','如何','保证','时候','什么','应该','已经','没有','不会']);
export function searchTerms(value) {
  const terms=new Set();
  for(const run of String(value).toLowerCase().match(/[\u4e00-\u9fff]{2,}|[a-z0-9]{3,}/g)||[]) {
    if(/^[a-z0-9]/.test(run))terms.add(run);
    else for(let i=0;i<run.length-1;i++)terms.add(run.slice(i,i+2));
  }
  for(const term of stop)terms.delete(term);
  return terms;
}
const expand=text=>synonyms.filter(([pattern])=>pattern.test(text)).map(([,value])=>value).join(' ');
const positiveText=text=>String(text).split(/[，,；;。\n]/).filter(part=>!/^\s*(?:本轮|首期|暂时)?(?:不(?:增加|新增|做|需要|包括|包含|扩展|提供)|不要|取消|排除)/.test(part)).join('；');

export function createCaseSearch(cases) {
  const index=cases.map(item=>{
    const title=item.title.split(' · ')[0],keyword=(item.keywords||[]).join(' ');
    const corpus=`${title} ${item.question} ${keyword}`;
    return {item,terms:searchTerms(corpus+' '+expand(corpus)),anchors:searchTerms(title+' '+keyword+' '+expand(title+' '+keyword))};
  });
  const scenes=new Map();
  for(const scene of new Set(cases.map(c=>c.scene))) {
    const rows=index.filter(x=>x.item.scene===scene),frequency=new Map();
    for(const row of rows)for(const t of row.terms)frequency.set(t,(frequency.get(t)||0)+1);
    const idf=t=>Math.log((rows.length+1)/((frequency.get(t)||0)+1))+1;
    for(const row of rows){row.vector=new Map([...row.terms].map(t=>[t,idf(t)]));row.norm=Math.hypot(...row.vector.values());}
    scenes.set(scene,{rows,idf});
  }
  return (scene,scope)=>{
    const group=scenes.get(scene);if(!group)return [];
    const anchor=scope.focus||(scope.retired.length?scope.input:scope.latest);
    const input=positiveText(scope.input),focus=positiveText(anchor);
    const raw=searchTerms(input),expanded=expand(input),focusExpansion=expand(focus);
    const query=searchTerms(input+' '+expanded),latest=searchTerms(focus+' '+focusExpansion);
    const hasTopic=group.rows.some(row=>[...row.anchors].some(t=>latest.has(t)));
    const active=hasTopic?latest:query;
    const vector=new Map([...query].map(t=>[t,group.idf(t)*(active.has(t)?2:1)])),norm=Math.hypot(...vector.values());
    const candidates=group.rows.map(({item,terms,anchors,vector:dv,norm:dn})=>{
      const overlap=[...terms].filter(t=>query.has(t)),anchorMatches=[...anchors].filter(t=>active.has(t));
      const dot=overlap.reduce((sum,t)=>sum+(vector.get(t)||0)*(dv.get(t)||0),0),cosine=norm&&dn?dot/(norm*dn):0;
      const direct=input.includes(item.question),titleMatch=input.includes(item.title);
      const specific=anchorMatches.length>0&&(overlap.length>=2||(focus.length<=12&&item.keywords?.some(k=>focus.includes(k))));
      const vectorOnly=!specific&&overlap.length>=3&&cosine>=0.28;
      const conditionTerms=searchTerms((item.condition_label||'')+' '+expand(item.condition_label||''));
      const conditionHits=[...conditionTerms].filter(t=>active.has(t)).length;
      const conditionBonus=item.condition_index>0&&conditionHits>=2?36:0;
      const score=(direct?10000:0)+(titleMatch?1000:0)+anchorMatches.reduce((n,t)=>n+group.idf(t)*8,0)+overlap.length+cosine*30+[...terms].filter(t=>latest.has(t)).length*3+(item.condition_index===0?12:0)+conditionBonus+(item.condition_label&&input.includes(item.condition_label)?40:0);
      return {item,overlap,score,eligible:direct||specific||vectorOnly,match:{method:'关键词 + 同义词 + TF-IDF稀疏向量余弦检索（本地，无模型）',query:anchor,terms:overlap.filter(t=>raw.has(t)),expanded_terms:overlap.filter(t=>!raw.has(t)),anchors:anchorMatches,cosine:Number(cosine.toFixed(4)),confidence:direct?'原文匹配':anchorMatches.length>=2?'相关候选':'弱相关候选',status:'候选资料，适用性待核对'}};
    }).filter(x=>x.eligible).sort((a,b)=>b.score-a.score||a.item.id.localeCompare(b.item.id));
    const seen=new Set();return candidates.filter(({item})=>!seen.has(item.topic_id)&&seen.add(item.topic_id)).slice(0,3);
  };
}
