import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {spawn,execFileSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const root=fileURLToPath(new URL('../',import.meta.url)),dir=path.join(root,'.share');
const config=JSON.parse(fs.readFileSync(path.join(dir,'access.json'),'utf8'));
let host=new URL(config.origin).host;
const alive=name=>{
  try{
    const pid=Number(fs.readFileSync(path.join(dir,name+'.pid'),'utf8'));
    if(!Number.isSafeInteger(pid)||pid<2)return false;
    const command=execFileSync('/bin/ps',['-p',String(pid),'-o','command='],{encoding:'utf8'});
    const expected={server:'server.mjs',frpc:path.join(dir,'frpc'),cloudflared:path.join(dir,'cloudflared'),awake:'caffeinate'}[name];
    return expected&&command.includes(expected)?pid:false;
  }catch{return false;}
};
const launch=(name,command,args,env)=>{
  const log=fs.openSync(path.join(dir,name+'.log'),'a',0o600);
  const child=spawn(command,args,{cwd:root,env,detached:true,stdio:['ignore',log,log]});
  fs.closeSync(log);child.unref();fs.writeFileSync(path.join(dir,name+'.pid'),String(child.pid),{mode:0o600});return child.pid;
};
if(process.argv.includes('--stop')){
  for(const name of ['frpc','cloudflared','awake','server']){const pid=alive(name);if(pid)process.kill(pid,'SIGTERM');}
  console.log('Sharing stopped; original local service remains running.');
}else{
  if(process.argv.includes('--restart-app')){
    for(const name of ['awake','server']){const pid=alive(name);if(pid)process.kill(pid,'SIGTERM');}
    for(let i=0;i<30&&alive('server');i++)await new Promise(r=>setTimeout(r,100));
    if(alive('server'))throw new Error('Share service is still stopping');
  }
  let provider=process.argv.includes('--cloudflare')?'cloudflare':'frp';
  if(!process.argv.includes('--cloudflare'))try{provider=JSON.parse(fs.readFileSync(path.join(dir,'tunnel-provider.json'),'utf8')).provider;}catch{}
  if(provider==='cloudflare'){
    if(!alive('cloudflared')){
      fs.writeFileSync(path.join(dir,'cloudflared.log'),'',{mode:0o600});
      launch('cloudflared',path.join(dir,'cloudflared'),['tunnel','--no-autoupdate','--protocol','http2','--url','http://127.0.0.1:8001'],{PATH:process.env.PATH});
      let publicOrigin;
      for(let i=0;i<60;i++){
        publicOrigin=fs.readFileSync(path.join(dir,'cloudflared.log'),'utf8').match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com\b/)?.[0];
        if(publicOrigin)break;
        await new Promise(r=>setTimeout(r,500));
      }
      if(!publicOrigin)throw new Error('No Cloudflare URL was issued; see .share/cloudflared.log');
      config.origin=publicOrigin;host=new URL(publicOrigin).host;
      fs.writeFileSync(path.join(dir,'access.json'),JSON.stringify(config,null,2),{mode:0o600});
      for(const name of ['frpc','awake','server']){const pid=alive(name);if(pid)process.kill(pid,'SIGTERM');}
      for(let i=0;i<20&&alive('server');i++)await new Promise(r=>setTimeout(r,100));
    }
    fs.writeFileSync(path.join(dir,'tunnel-provider.json'),JSON.stringify({provider}),{mode:0o600});
  }else{
    const template=JSON.parse(execFileSync('python3',['-c','import tomllib,json,sys; print(json.dumps(tomllib.load(open(sys.argv[1],"rb"))))',path.join(dir,'frpc.toml')],{encoding:'utf8'}));
    if(!template.auth?.token||/^\*+$/.test(template.auth.token))throw new Error('Company FRP token is a placeholder; sharing is not available until a valid token is configured');
  }
  const server=alive('server')||launch('server',process.execPath,['server.mjs'],{PATH:process.env.PATH,PORT:'8001',REVIEW_SHARE_CONFIG:path.join(dir,'access.json'),REVIEW_DATA_DIR:path.join(dir,'base')});
  const ready=()=>new Promise(resolve=>{const r=http.get({host:'127.0.0.1',port:8001,path:'/',headers:{host}},res=>{res.resume();resolve(res.statusCode===200);});r.setTimeout(1500,()=>r.destroy());r.on('error',()=>resolve(false));});
  let healthy=false;
  for(let i=0;i<20;i++){if(await ready()){healthy=true;break;}await new Promise(r=>setTimeout(r,500));}
  if(!healthy)throw new Error('Share service did not start; see .share/server.log');
  if(provider==='frp'&&!alive('frpc'))launch('frpc',path.join(dir,'frpc'),['-c',path.join(dir,'frpc.toml')],{PATH:process.env.PATH});
  if(!alive('awake'))launch('awake','/usr/bin/caffeinate',['-i','-w',String(server)],{PATH:process.env.PATH});
  console.log(JSON.stringify({origin:config.origin,status:'started_pending_external_verification',mode:'local',port:8001,password_file:path.join(dir,'access-password.txt')}));
  if(process.argv.includes('--open'))spawn('/usr/bin/open',[config.origin],{stdio:'ignore'});
}
