# drive (v1)

## 能力范围（本沙箱仅开放 3 个只读快捷命令 + 3 个只读 API）

| 快捷命令 | 用途 |
|----------|------|
| `+search` | 按关键词搜云空间（见下方专节） |
| `+batch-query-comments` | 按评论 ID 批量获取评论卡片，见 [`references/lark-drive-batch-query-comments.md`](references/lark-drive-batch-query-comments.md) |
| `+list-replies` | 分页获取某条评论下的全部回复，见 [`references/lark-drive-list-replies.md`](references/lark-drive-list-replies.md) |

| API 命令 | 用途 |
|----------|------|
| `drive files list` | 列出某个 Drive 文件夹或根目录的直接子项（可递归盘点目录树） |
| `drive file.comments list` | 分页获取某个文档的评论列表 |
| `drive file.view_records list` | 获取文档的访问者记录（view records） |

其余 drive 能力（上传 / 下载 / 导入 / 导出 / 复制 / 移动 / 删除 / 新建文件夹、评论与回复的写入、
权限与协作者、密级标签、版本管理、封面、订阅等）在本沙箱**不作为可用入口**，不要尝试拼这些命令。

### 评论读取：shortcut 与原生 API 的分工

意图命中 shortcut 时**优先用 shortcut**——两个评论 shortcut 直接接受 `--url`（含 wiki URL
自动解包到底层文档），无需先手动解析 `file_token` / `file_type`：

| 意图 | 用什么 |
|------|--------|
| 分页遍历评论卡片、全量统计、找最新/最早评论 | `drive file.comments list`（原生 API，见下方 file.comments 节） |
| 已知 `comment_id`，精确取一批评论卡片 | `drive +batch-query-comments`（不要翻 `file.comments list` 的分页去过滤） |
| 某张评论卡片 `item.has_more=true` 回复没拉全，或要按 `comment_id` 独立分页看全部回复 | `drive +list-replies` |

### 文档类型与 Token（读取前提）

不同类型的文档有不同的 URL 格式和 Token 处理方式。用**原生 API** 列取评论或访问记录前，
必须先拿到正确的 `file_token` 与对应 `file_type`；两个评论 shortcut 则直接接受 `--url`
（含 wiki URL 自动解包），或裸 token + `--type`。

| URL 格式 | 示例 | Token 类型 | 处理方式 |
|----------|------|-----------|----------|
| `/docx/` | `https://example.larksuite.com/docx/doxcnxxxxxxxxx` | `file_token` | URL 路径中的 token 直接作为 `file_token` 使用（`file_type=docx`） |
| `/doc/` | `https://example.larksuite.com/doc/doccnxxxxxxxxx` | `file_token` | URL 路径中的 token 直接作为 `file_token` 使用（`file_type=doc`） |
| `/sheets/` | `https://example.larksuite.com/sheets/shtcnxxxxxxxxx` | `file_token` | URL 路径中的 token 直接作为 `file_token` 使用（`file_type=sheet`） |
| `/page/` | `https://example.feishu.cn/page/N1BWmMrqndT5ZcamAIBcnvDLnOf/` | apps token | 妙搭 apps 类型；列评论时作为 `file_token`，`file_type=apps` |
| `/drive/folder/` | `https://example.larksuite.com/drive/folder/fldcnxxxx` | `folder_token` | URL 路径中的 token 作为文件夹 token 使用 |

## API Resources

```bash
lark-cli schema drive.<resource>.<method>   # 调用 API 前必须先查看参数结构
lark-cli drive <resource> <method> [flags]  # 调用 API
```

> **重要**：使用原生 API 时，必须先运行 `schema` 查看 `--data` / `--params` 参数结构，不要猜测字段格式。

### files

  - `list` — 获取文件夹下的清单；使用前阅读 [`references/lark-drive-files-list.md`](references/lark-drive-files-list.md)，按模板通过 `--params` 传参并手动处理分页；不要把 `--page-all` 输出直接交给 JSON 解析脚本。

标准模板（读取普通文件夹的直接子项）：

```bash
lark-cli drive files list \
  --params '{"folder_token":"<folder_token>","page_size":200}' \
  --format json
```

读取当前用户 Drive 根目录的直接子项（`folder_token` 传空字符串）：

```bash
lark-cli drive files list \
  --params '{"folder_token":"","page_size":200}' \
  --format json
```

### file.comments

  - `list` — 分页获取某个文档的评论列表。

  说明（近原样承接上游事实，不要臆造 flag，需要参数结构先 `lark-cli schema drive.file.comments.list`）：
  - 返回的 `items` 是评论卡片列表，每个 `item` 对应用户界面中的一张评论卡片，不是平铺的互动消息列表。
  - 真正承载正文的是 `item.reply_list.replies`，其中第一条 reply 在用户视角下就是这张卡片里的"评论本身"。
  - 统计"评论数 / 评论卡片数"：统计 `items` 长度；全量统计时对所有分页返回的 `items` 长度累加。
  - 是否还有下一页以返回里的 `has_more` 为准；`page_token` 只作为 `has_more=true` 时续跑下一页的游标。
  - 如果 `item.has_more=true`，说明该评论卡片下还有更多回复未包含在当前返回中——用
    `drive +list-replies --comment-id <items[].comment_id>` 拉全该卡片的回复。
  - 已知 `comment_id` 要精确取评论卡片时，不要翻本 API 的分页去过滤，改用
    `drive +batch-query-comments`。

### file.view_records

  - `list` — 获取文档的访问者记录。查看 docx 最近访问记录、返回 open_id、最多 N 条时，建议优先使用 typed flags：`lark-cli drive file.view_records list --file-token <docx_token> --file-type docx --page-size <N> --viewer-id-type open_id --format json`；`--params` JSON 也支持，适合批量拼装、分页续跑或 raw 参数场景。

## 典型错误与解决方案

| 错误信息 | 原因 | 解决方案 |
|----------|------|----------|
| `not exist` | 使用了错误的 token | 检查 token 类型；wiki 链接背后是 docx/sheet/bitable 等不同对象，不能只按 `/wiki/<token>` 猜底层类型（两个评论 shortcut 传 `--url` 会自动解包 wiki，原生 API 没有这层解包） |
| `permission denied` | 没有相关操作权限 | 当前身份对该文档/文件没有读取权限；把 `error.hint` 转述给用户，不要自行补登录或改身份 |
| `invalid file_type` | file_type 参数错误 | 根据实际 `obj_type` 传入正确的 file_type（docx/doc/sheet/slides/bitable/apps） |

## `+search` —— 按关键词搜云空间

```bash
lark-cli drive +search --query "<关键词>" --doc-types file --mine --as user
lark-cli drive +search --query "<关键词>" --only-title --as user
```

要点：

- **默认匹配标题与正文**；加 `--only-title` 才退化为仅标题匹配
- `--query` 最长 30 字符（按 Unicode 码点算，中文每字算 1 个）；可以留空，配过滤器纯按条件浏览
- `--query` 支持服务端高级语法 `intitle:` / `""` / `OR` / `-`，**优先下推给服务端**，
  不要先模糊搜再在客户端二次过滤
- `--doc-types` 逗号分隔，取值 `doc,sheet,bitable,mindnote,file,wiki,docx,folder`
- `--mine` 是**服务端 owner 语义**，与 `--created-by-me`（原始创建者）不同，别混用
- 时间窗过滤按动作分：`--created-since/until`（文档创建）、`--edited-since/until`（我编辑过）、
  `--opened-since/until`（我打开过）、`--commented-since/until`（我评论过）；值支持 `7d` / `1m` /
  `2026-04-01` / RFC3339
- `--page-size` 1-20 默认 15，配 `--page-token` 翻页
- `--folder-tokens` 与 `--space-ids` 互斥，分别限定云盘文件夹与 wiki 空间
- `--sort` 取值 `default|edit_time|edit_time_asc|open_time|create_time`

### 按完整标题定位

用户按**完整标题**定位某个资源时，使用 `--only-title`：

- 标题不超过 30 个字符时直接查询；超长标题使用不超过限制的稳定片段召回，再按返回标题严格匹配
- 使用相同 query 和过滤条件按 `--page-token` 检查，最多 3 页
- 仅在 `has_more=false` 且跨页恰好一个严格匹配时才把该结果当作唯一定位继续后续操作，
  否则请用户缩小范围或补充信息
- `drive files list` 只用于枚举已知文件夹的直接子项，不当作标题检索手段

### 标题词 + 正文词要同时满足时

用户同时给标题关键词和正文关键词、且要求同一资源同时满足两项时，**发一条联合搜索**：

```bash
lark-cli drive +search --query "标题词 正文词" --folder-tokens <FOLDER_TOKEN> --as user
```

把用户指定的 `--folder-tokens` / `--doc-types` 等过滤条件叠在同一条命令里。**不要**拆成
「标题搜索 + 正文搜索」再自行拼交集，也**不要**把 `--only-title` 或 `intitle:` 当主候选路径——
只有用户明确只查标题时才用它们。

### 用户要 N 条结果时

**N 是输出上限，不等于 `--page-size N`。** 逐页按返回里的 `title` 与 `summary_highlighted`
保留同时满足两项条件的候选；有效候选不足 N 且 `has_more=true` 时，保持同一 query 与过滤条件、
用 `--page-token` 继续，**最多检查 3 页**。摘要不足以判断正文条件时，只对标题已匹配的候选
**串行**读正文，确认一个再处理下一个，找到 N 条即停——不要并发拉正文。检查 3 页仍不足就返回
已确认结果，并建议用户调整标题词 / 正文词 / 搜索范围，不要无界扫描。

### 分页与放宽范围

- 默认只返回第一页，并说明 `has_more` 与下一页命令。用户明确要「全部 / 全量 / 继续翻」才继续。
- 上面的标题词 + 正文词联合搜索最多检查 3 页；其他场景单轮翻页上限 5 页。
- 扩展 query 时优先保留用户已指定的空间、文件夹、群聊、人员、时间和类型等过滤条件；
  确需放宽检索范围时，先向用户说明原因并征得确认。
- 结果被截断时不要据此回答「一共有多少」，先翻页或收窄条件。
