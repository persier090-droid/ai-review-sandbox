import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';

// Browser plugin not available in this session; use the existing Playwright runtime.
const require=createRequire(import.meta.url);
let playwright;try{playwright=require('playwright');}catch{playwright=require(process.env.PLAYWRIGHT_MODULE||'/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}
const data=fs.mkdtempSync(path.join(os.tmpdir(),'multiscene-browser-'));
let app,browser;
try {
  const reserve=http.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));const port=reserve.address().port;await new Promise(r=>reserve.close(r));
  const origin=`http://127.0.0.1:${port}`;
  app=spawn(process.execPath,['server.mjs'],{cwd:fileURLToPath(new URL('../',import.meta.url)),env:{...process.env,PORT:String(port),REVIEW_DATA_DIR:data,AI_PROVIDER:'openrouter',OPENROUTER_API_KEY:''},stdio:['ignore','pipe','pipe']});
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('server startup timeout')),10000);app.stdout.on('data',data=>{if(String(data).includes('AI review server')){clearTimeout(timer);resolve();}});app.once('exit',code=>{clearTimeout(timer);reject(Error('server exit '+code));});});
  browser=await playwright.chromium.launch({headless:true,...(process.platform==='darwin'?{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}:{})});
  const page=await browser.newPage({viewport:{width:1440,height:1000}}),errors=[],failedResources=[];
  page.on('pageerror',error=>errors.push(error.message));
  page.on('response',response=>{if(response.status()>=400)failedResources.push(response.status()+' '+response.url());});
  page.on('console',message=>{if(message.type()==='error')errors.push(message.text());});
  const complete=()=>page.waitForFunction(()=>document.querySelector('#statusTag').textContent.includes('初评完成')&&!document.querySelector('#endBtn').disabled,{},{timeout:30000});
  const record=async()=>{const id=await page.evaluate(()=>sessionStorage.getItem('ktv-review-id'));return (await fetch(origin+'/api/reviews/'+id)).json();};
  await page.goto(origin+'/?mode=local');
  assert.ok((await page.title()).length);assert.ok((await page.locator('body').innerText()).includes('评审'));
  assert.deepEqual(await page.locator('#runMode option').allTextContents(),['Agent模型落地','网页模型协作','本地交叉验证']);
  assert.equal(await page.locator('#runMode').inputValue(),'local');
  assert.equal(await page.locator('#continueInBrowser, #refreshModelStatus').count(),0);
  const scenarios=[
    ['ktv','给唱歌的人加个虚拟舞伴，想关就关','KTV-001'],
    ['car','在车里唱卡拉OK，听见自己的声音慢半拍','CAR-03'],
    ['saas','A公司的客户不应该给B公司看到','SAAS-01'],
    ['app','用积分换礼物，点了两次不能扣两遍','APP-00'],
    ['web','后台看板网断了还显示旧数字','WEB-00']
  ];
  for(const [scene,input,prefix] of scenarios) {
    await page.selectOption('#bizScene',scene);
    if(scene==='car'){assert.match(await page.locator('#reqInput').inputValue(),/驻车KTV/);assert.doesNotMatch(await page.locator('#reqInput').inputValue(),/POI|导航/);}
    for(const tab of ['score','risk','todo','prd'])assert.equal(await page.locator(`[data-tab="${tab}"]`).isDisabled(),true);
    await page.fill('#reqInput',input);await page.click('#interveneBtn');await complete();
    const r=await record();assert.equal(r.failure,null);assert.equal(r.reference_only,true);assert.equal(r.usage.calls,0);
    assert.ok(r.artifacts.score.preliminary.case_id.startsWith(prefix));
    assert.equal(await page.locator('#phaseTrack [data-state="reference"]').count(),6);
    assert.equal(await page.locator('#manualDialog').evaluate(el=>el.open),false);
    assert.ok(await page.locator('#chatBox .msg-reference').count()>=9);
    await page.locator('#chatBox .msg-reference summary').first().click();
    assert.match(await page.locator('#chatBox .msg-reference').first().innerText(),/输入锚点：[\s\S]*TF-IDF/);
    for(const tab of ['score','risk','todo','prd']){await page.click(`[data-tab="${tab}"]`);assert.ok((await page.locator(`#panel-${tab}`).innerText()).length>60);}
    assert.match(await page.locator('#docContent').innerText(),/初步验证评分[\s\S]*成本构成/);
    await page.click('[data-tab="chat"]');
  }
  const before=await record();
  await page.fill('#reqInput','预算500元，工期2人日');await page.click('#interveneBtn');
  await page.fill('#reqInput','只做本轮大屏，不增加导出');await page.click('#interveneBtn');
  await page.waitForFunction(()=>document.querySelector('#queueList li'),{},{timeout:5000});
  await page.waitForFunction(()=>document.querySelector('#queueList').children.length===0&&!document.querySelector('#endBtn').disabled,{},{timeout:45000});
  const after=await record();assert.equal(after.revision,before.revision+2);assert.equal(after.failure,null);assert.equal(after.usage.calls,0);
  assert.equal(await page.locator('#runMode').inputValue(),'local');
  assert.equal(await page.locator('#manualDialog').evaluate(el=>el.open),false);
  await page.reload();await complete();assert.equal(await page.locator('#runMode').inputValue(),'local');
  await page.click('[data-tab="score"]');await page.screenshot({path:'/tmp/multiscene-score-desktop.png',fullPage:true,animations:'disabled'});
  await page.setViewportSize({width:390,height:844});
  for(const tab of ['chat','score','risk','todo','prd']){await page.click(`[data-tab="${tab}"]`);assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),tab+' horizontal overflow');}
  await page.click('[data-tab="chat"]');await page.screenshot({path:'/tmp/multiscene-chat-mobile.png',fullPage:true,animations:'disabled'});
  assert.deepEqual(failedResources,[]);assert.deepEqual(errors,[]);
  console.log('多场景浏览器验收通过：三个唯一模式、五场景改写检索与六阶段、四项交付、连续追问/队列/刷新不跳网页、桌面/手机无溢出、无控制台错误。真实模型调用0。');
} finally {
  if(browser)await browser.close();
  if(app&&app.exitCode===null){app.kill();await new Promise(r=>app.once('exit',r));}
  fs.rmSync(data,{recursive:true,force:true});
}
