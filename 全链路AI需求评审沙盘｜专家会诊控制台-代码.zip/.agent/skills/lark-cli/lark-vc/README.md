# vc (v1)

> [!IMPORTANT]
> - 运行 `lark-cli --version`，确认可用，无需询问用户。

## 身份

vc 域命令默认使用 `--as user`。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| [`+recording`](references/lark-vc-recording.md) | 查会议录制信息：回看链接、时长、关联妙记 token |

- 使用 Shortcut 前，必须先读 [references/lark-vc-recording.md](references/lark-vc-recording.md)。

## 输入要求 —— 必须直接给 ID

`+recording` 只接受 `meeting_id` 或日程实例 ID。本域没有按会议链接、会议号或自然语言描述
定位会议的命令，所以拿到这些形式时**先向用户索取 ID**，不要试其它域的命令绕。

| 用户给了什么 | 怎么做 |
|---|---|
| `meeting_id` | `+recording --meeting-ids <id>` |
| 日程实例 ID | `+recording --calendar-event-ids <id>` |
| 会议链接 / 会议号 / 「上周三那个会」 | 告知用户需要提供会议 ID 或日程实例 ID |

## 意图路由

| 用户需求 | 命令 |
|---|---|
| 这个会有没有录制、能不能回看 | `+recording --meeting-ids <meeting_id>` |
| 这个会录了多长 | 同上，读返回的 `duration` |
| 从日程查对应会议的录制 | `+recording --calendar-event-ids <日程实例 ID>` |

## 拿到 minute_token 之后

`+recording` 返回体含 `minute_token`。需要下载录制的音视频文件时，切到
[lark-minutes](../lark-minutes/README.md) 用 `minutes +download`——那是本 skill 内可用的下载入口。
