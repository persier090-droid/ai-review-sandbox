import crypto from 'node:crypto';
import {ROLE_NAMES,selectAssertions} from './expert-skills.mjs';
import {roleName} from './role-personas.mjs';
import {scoreReview} from './review-scoring.mjs';
import {collectReviewRisks} from './review-risks.mjs';
import {scopeText} from './review-scope.mjs';
import {assessScene} from './review-scene.mjs';
import {routeQuestions} from './review-routing.mjs';
import {assessPreliminary} from './review-preliminary.mjs';
import {localScope} from './review-local-scope.mjs';
import {feasibilityText} from './review-feasibility.mjs';

export const DELIVERY_STAGES = ['score','risk','todo','prd'];
export function initialWorkflow() { return {chat:'running',score:'locked',risk:'locked',todo:'locked',prd:'locked'}; }
const list = value => Array.isArray(value) ? value : [];

export function reviewMethodReferences(review) {
  const candidates=selectAssertions(review.roles,scopeText(review),review.scene);
  const selected=new Map();
  for(const a of candidates) {
    const cited=list(review.role_results).filter(o=>o.role===a.role).some(o=>list(o.references).some(r=>r.id===a.id&&r.quote===a.assertion&&r.source===a.source));
    if(!cited&&!review.reference_only)continue;
    const id=a.reference_id || a.id;
    const saved=selected.get(id);
    if(saved){saved.roles.push(a.role);continue;}
    selected.set(id,{id,title:a.source,url:a.source_url,claim:a.assertion,roles:[a.role],applicability:a.applicable_scenario,limitations:a.limitations || '仅确认规则出处，不代表本项目取得许可或设备完成测试。',checked_at:a.last_verified,usage:cited?'本轮意见引用':'按议题匹配的方法参考，非本轮实测依据'});
  }
  return [...selected.values()];
}

function evaluate(review) {
  const included = list(review.role_results);
  const excluded = Object.entries(review.role_status || {}).filter(([,s])=>s.status !== 'included').map(([role,s])=>({role,name:roleName(review,role),status:s.status==='reference'?'已参与本地岗位模拟，建议待确认':s.status==='unavailable'?'模型讨论中断':'意见待核验',reason:review.failure?.message || s.reason}));
  const missing = review.precheck?.missing_materials || [];
  const uncovered = list(review.required_roles).filter(role=>!included.some(r=>r.role===role));
  const scored=scoreReview(review);
  scored.preliminary=assessPreliminary(review);
  scored.scene_assessment=assessScene(review);
  scored.question_routing=review.question_routing || routeQuestions(review.scene,scopeText(review),review.roles);
  scored.local_references=review.local_references || [];
  scored.focus_dimensions=scored.score===null?[]:scored.dimensions.filter(d=>d.deducted>0).sort((a,b)=>b.deducted-a.deducted).slice(0,3);
  const ready = scored.verdict==='通过';
  const reasons = [];
  if (missing.length) reasons.push(`尚未提供可定位的材料：${missing.join('、')}。`);
  if (uncovered.length) reasons.push(`必要专业覆盖尚未齐备：${uncovered.map(r=>ROLE_NAMES[r] || r).join('、')}。这是覆盖缺口，不是这些岗位对功能投反对票。`);
  if (!included.length) reasons.push('本轮没有满足前提引用、具体对象、推导及反例要求的专业意见，不能形成可通过的专业结论。');
  if (review.conclusion && !review.failure && review.quality?.decision_ready) reasons.push(`责任角色建议：${review.conclusion.decision}；${review.conclusion.reason}`);
  if (!review.conclusion || review.failure) reasons.push('本轮未取得完整且可追溯的决策记录，不作开发或上线放行。');
  if (!review.quality?.decision_ready && included.length) reasons.push('执行依据或结论核对条件未全部满足，本轮不放行。');
  reasons.push(...scored.rules.filter(r=>!r.passed).map(r=>`${r.id} ${r.name}：${r.reason}`));
  const perspectives=included.map(o=>({role:o.role,name:roleName(review,o.role),stance:o.stance || '未表态',stance_reason:o.stance_reason,...o.analysis}));
  const localSpeakers=new Set((review.messages || []).filter(m=>m.revision===review.revision&&m.phase==='LOCAL_REFERENCE'&&review.roles.some(r=>r.key===m.role)).map(m=>m.role));
  return {...scored,summary:scored.decision_status==='awaiting_discussion'?'当前提供初步验证方案与评分，正式放行仍需责任决策及证据核验。':ready ? '本轮需求评审通过，按已记录范围推进；实际验收仍需证据。' : '本轮评审不通过；仅说明当前放行条件未满足，不等于功能本身不可行。',reasons,perspectives,excluded,coverage:{included:included.length,selected:review.roles.length,local_speakers:localSpeakers.size},stances:review.roles.map(r=>({role:r.key,name:r.name,stance:included.find(o=>o.role===r.key)?.stance || (review.reference_only?'案例待确认':'待讨论')}))};
}

function risks(review, assessment) {
  const items=collectReviewRisks(review);
  const f=assessment.preliminary.feasibility;
  const businessGaps=f.actions.filter(a=>f.blockers.some(b=>b.key===a.key)||a.key==='budget'&&f.cost.budget_status.includes('超预算')||a.key==='budget'&&f.cost.budget_status==='超出已列预算').map(a=>({text:`${a.item}；${a.done_when}`,owner:a.owner,source:a.key,kind:'投入与边界待确认',level:'high'}));
  const gaps=[...list(review.precheck?.missing_materials).map(text=>({text:`材料缺口：${text}`,owner:'产品经理',source:'材料检查',kind:'评审阻塞'})),...list(review.closure?.undecided).map(text=>({text,owner:'产品经理',source:'本轮未决事项',kind:'待确认'}))];
  for(const key of list(review.precheck?.missing_roles)) gaps.push({text:`必要岗位尚未参会：${roleName(review,key)}`,owner:'产品经理',source:'岗位检查',kind:'评审阻塞'});
  for(const output of list(review.role_results)) {
    if(output.stance==='有条件') for(const condition of list(output.stance_conditions)) if(!list(review.conditions).some(c=>c.revision===review.revision&&c.condition===condition&&c.status==='通过'))gaps.push({text:condition,owner:roleName(review,output.role),source:'岗位附加条件',kind:'评审阻塞'});
    if(output.stance==='反对')gaps.push({text:`复核反对依据：${output.stance_reason}`,owner:roleName(review,output.role),source:'岗位反对意见',kind:'待确认'});
  }
  if(review.reference_only) gaps.push({text:'围绕本次需求开展岗位交流，完成质询回应，再由产品经理收口；案例不代表参会岗位已表态',owner:'产品经理',source:'待开展讨论',kind:'讨论准备'});
  else if(review.failure) gaps.push({text:`讨论中断：${review.failure.message}；需继续交流的岗位：${assessment.excluded.map(r=>r.name).join('、')}`,owner:'产品经理',source:'服务故障',kind:'讨论准备'});
  else for(const row of assessment.excluded) if(list(review.required_roles).includes(row.role)) gaps.push({text:`补齐${row.name}的有效意见：${row.reason}`,owner:row.name,source:'专业覆盖',kind:'评审阻塞'});
  for(const ref of review.local_references || []) gaps.push({text:`本地参考 ${ref.case_id}：核对“${ref.title}”是否适用；${ref.evidence}`,owner:roleName(review,ref.roles[0]||'pd'),source:ref.case_id,kind:'参考待核实'});
  const seen=new Set();for(let i=gaps.length-1;i>=0;i--){const key=gaps[i].text.replace(/\s/g,'');if(seen.has(key))gaps.splice(i,1);else seen.add(key);}
  for(const check of assessment.scene_assessment.checks.filter(c=>!c.passed)) gaps.push({text:`${check.label}：${check.reason}。核对要求：${check.expectation}`,owner:roleName(review,check.owner),source:check.id,kind:'评审阻塞'});
  if(assessment.scene_assessment.error)gaps.push({text:assessment.scene_assessment.error,owner:'产品经理',source:'场景专项验收',kind:'评审阻塞'});
  for(const issue of assessment.question_routing.issues.filter(i=>i.missing_roles.length))gaps.push({text:`核对${issue.label}是否需要补充责任岗位：${issue.missing_roles.map(r=>roleName(review,r)).join('、')}；匹配原文：${issue.quote}`,owner:'产品经理',source:'问题责任匹配',kind:'待确认'});
  if(assessment.decision_status==='awaiting_discussion') {
    const initial=assessment.preliminary;
    const focused=gaps.filter(g=>g.source===initial.case_id);
    for(const text of initial.gaps)focused.push({text,owner:initial.owner,source:'初步验证评分',kind:'待确认'});
    // Candidate risks stay separate from admitted model risk observations and release gates.
    if(initial.risk)focused.unshift({text:`${initial.risk.text}；停止条件：${initial.validation.stop_when}`,owner:roleName(review,initial.risk.owner),source:'初评风险假设',kind:'参考待核实',level:initial.risk.level==='高'?'high':initial.risk.level==='低'?'low':'mid'});
    return {verdict:assessment.verdict,preliminary:initial.recommendation,items,gaps:[...businessGaps,...focused],summary:'先核对以下风险假设及资料缺口，再决定试验范围。'};
  }
  return {verdict:assessment.verdict,items,gaps:[...businessGaps,...gaps],summary:items.length ? `记录${items.length}条有前提依据的风险假设，${gaps.length+businessGaps.length}项证据/决策缺口。` : '本轮暂无可纳入的业务风险判断；不代表没有风险，证据缺口需继续验证。'};
}

function tasks(review, assessment, risk) {
  const previous=list(review.execution).filter(e=>e.revision===review.revision);
  const items=[];
  const add=(item,owner,deliverable,source,kind='verification',deadline='下一轮评审前')=>items.push({id:crypto.randomUUID(),revision:review.revision,item,owner,deliverable,source,kind,deadline,status:'待开始'});
  if (assessment.verdict==='通过') for (const e of list(review.conclusion?.execution)) items.push({...e,revision:review.revision,id:crypto.randomUUID(),status:'待开始',kind:'implementation'});
  else {
    for(const saved of previous.filter(e=>e.kind==='implementation')) items.push({...saved,status:'暂停',blocked_reason:'本轮放行条件已失效，须重新评审',history:[...list(saved.history),...(saved.status!=='暂停'?[{status:saved.status,evidence:saved.evidence,at:new Date().toISOString()}]:[])]});
    for (const g of risk.gaps) {
      if(g.source==='初评风险假设'||g.text==='技术负责人估人日；运营核对持续费用，提出者确认上限')continue;
      const scenario=(review.local_references || []).find(r=>r.case_id===g.source)?.scenario;
      if(scenario) for(const task of scenario.artifacts.tasks) {
        add(`先确认案例适用性，再${task.item}`,task.owner,`${task.done_when}；回填实际记录，不以案例参考代替验证结果`,g.source,'verification',task.due);
        Object.assign(items.at(-1),{reference_task_id:task.id,evidence_ids:task.evidence_ids || scenario.validation.required_evidence,validation_id:task.validation_id || null,cost_estimate:Boolean(task.cost_estimate),reference_only:true});
      } else add(g.text,g.owner,'提交原始记录，并注明适用范围及核对人',g.source);
    }
    if (!items.some(item=>item.kind==='verification')) add('产品负责人核对本轮有效意见与放行条件','产品经理','逐项对应需求范围、原文证据及验收条件的复核记录','本轮准入结果');
  }
  if(assessment.decision_status==='awaiting_discussion') {
    const p=assessment.preliminary;
    if(!items.some(t=>t.cost_estimate))add('估算最小验证的实现与持续成本',p.owner,`${p.cost.items.join('、') || '先确定改造系统和维护工作'}；列明人日、外部费用与费用上限`,'初评成本估算','verification','试验启动前');
  }
  for(const action of assessment.preliminary.feasibility.actions)if(!items.some(t=>t.source===action.key || action.key==='cost'&&(t.cost_estimate||t.source==='初评成本估算')))add(action.item,action.owner,action.done_when,action.key,'verification','试验启动前');
  for (const r of risk.items.filter(r=>r.status!=='已解除')) add(`验证：${r.text}`,r.owner,`${r.mitigation}；记录${r.impact}是否发生`,r.evidence_quote || r.id);
  if (!items.length) add('核对交付范围与实际验收证据','产品经理','本轮范围确认及实际验收记录','评审结论');
  for(const item of items) {
    item.owner=roleName(review,item.owner);
    const person=assessment.stances.find(s=>s.name===item.owner || s.role===item.owner);
    item.stance=person?.stance&&person.stance!=='未参与'?person.stance:person?'待讨论':'未参会';
    item.participation_reason=person?assessment.excluded.find(r=>r.role===person.role)?.reason || '已有有效意见': '任务责任岗位尚未参加本轮讨论';
    const related=risk.items.find(r=>r.evidence_quote===item.source);
    item.priority=related ? ({high:'高',mid:'中',low:'低'}[related.level]) : item.kind==='verification'?'高':'中';
    const saved=previous.find(p=>p.item===item.item&&p.owner===item.owner&&p.kind===item.kind&&p.deliverable===item.deliverable);
    if(saved) for(const key of ['id','status','evidence','updated_at','history']) if(saved[key]!==undefined&&!(item.status==='暂停'&&['status','history'].includes(key)))item[key]=saved[key];
  }
  review.execution = [...list(review.execution).filter(e=>e.revision!==review.revision),...items];
  return {verdict:assessment.verdict,items,preliminary:assessment.decision_status==='awaiting_discussion'?assessment.preliminary.recommendation:null,summary:assessment.decision_status==='awaiting_discussion'?'先确认责任人、费用上限和验收口径，再执行验证任务':assessment.verdict==='通过' ? '按本轮范围执行并验证' : '先补证和验证，不自动安排功能开发'};
}

function document(review, assessment, risk, todo) {
  const originalInputs=review.inputs || [];
  const localDraft=assessment.decision_status==='awaiting_discussion';
  const currentScope=localDraft?localScope(review).input || localScope(review).latest:scopeText(review);
  review={...review,requirement:currentScope,inputs:[currentScope]};
  const cell=value=>String(value??'待确认').replace(/\|/g,'\\|').replace(/[\r\n]+/g,'<br>');
  const table=(headers,rows)=>[headers,headers.map(()=>'---'),...rows].map(row=>`| ${row.map(cell).join(' | ')} |`).join('\n');
  const pending=[...risk.gaps.map(g=>({content:g.text,owner:g.owner,level:'高',action:'补充原始依据，由责任岗位重新评审'})),...risk.items.filter(r=>r.status!=='已解除').map(r=>({content:r.text,owner:r.owner,level:{high:'高',mid:'中',low:'低'}[r.level],action:r.mitigation})),...list(review.conditions).filter(c=>c.revision===review.revision&&c.status!=='通过').map(c=>({content:c.condition,owner:c.verifier,level:'高',deadline:c.verify_by,action:`${c.verification_method}；通过标准：${c.pass_criteria}`}))];
  const distribution=['支持','有条件','反对','待讨论','案例待确认'].map(s=>`${s} ${assessment.stances.filter(r=>r.stance===s).length}`).join(' / ');
  const parts=key=>list(review.role_results).flatMap(o=>list(o.deliverables?.[key]).map(d=>`- ${d.text}（${roleName(review,o.role)}；范围原文：${d.scope_quote}；建议，待责任人确认）`));
  const referenceDraft=localDraft?(review.local_references || []).find(r=>r.case_id===assessment.preliminary.case_id)?.scenario?.artifacts?.prd_sections:null;
  const section=(title,key,fallback)=>`### ${title}\n${parts(key).join('\n') || (referenceDraft?.[title]?`${referenceDraft[title]}（本地候选方案，待确认适用）`:fallback)}`;
  const opinions = assessment.perspectives.map(p=>`### ${p.name} · ${p.stakeholder}\n判断：${p.claim}\n理论/原则：${p.principle}\n依据：${p.basis.map(b=>`[${b.kind}] ${b.quote}`).join('；')}\n推导：${p.reasoning}\n反例：${p.counterargument}\n边界：${p.boundary}\n验证：${p.verification}`).join('\n\n');
  const markdown=[`# 本轮评审交付文档`, `评审编号：${review.id} / 第${review.revision}轮\n场景：${review.scene}\n结果：${assessment.verdict}`,`## 本次范围\n${review.requirement}\n${review.inputs.slice(1).map((s,i)=>`补充${i+1}：${s}`).join('\n')}`,`## 智能评测\n${assessment.summary}\n${assessment.reasons.join('\n')}`,`## 有效观点与证据\n${opinions || '本轮暂无满足纳入条件的专业观点，不编造专业结论。'}`,`## 暂不参与岗位\n${assessment.excluded.map(r=>`${r.name}：${r.status}；不计入本轮专业判定。`).join('\n') || '无'}`,`## 风险看板\n${risk.summary}\n${risk.items.map(r=>`${r.owner} / ${r.stakeholder}：${r.text}\n依据：${r.evidence_quote}\n影响：${r.impact}\n措施：${r.mitigation}`).join('\n')}\n${risk.gaps.map(g=>g.text).join('\n')}`,`## 待办任务\n${todo.items.map((t,i)=>`${i+1}. ${t.item}\n责任：${t.owner}；期限：${t.deadline}\n交付物：${t.deliverable}\n依据：${t.source || t.scope_quote}`).join('\n')}`,`## 本次不做\n${list(review.closure?.parking_lot).join('\n') || '不增加原始需求及明确变更之外的范围。'}`,`## 再次评审条件\n${review.closure?.reopen_when || '补齐本轮缺失证据，并由产品经理核对需求边界。'}`].join('\n\n');
  const basic=`## 基本信息\n场景：${review.scene}\n需求：${review.requirement}\n日期：${review.closure?.at || new Date().toISOString()}\n参会岗位：${review.roles.map(r=>r.name).join('、')}\n立场分布：${distribution}\n结论：${assessment.verdict}\n${assessment.decision_status==='awaiting_discussion'?'文档性质：评审准备草案，不是会议决议。':''}\n${assessment.formula}\n${assessment.policy.status}\n${assessment.rules.map(r=>`${r.id}：${r.status==='pending'?'待评估':r.passed?'满足':'触发不通过'}；${r.reason}`).join('\n')}`;
  const confirm=`## 待确认清单\n${table(['序号','内容','岗位','风险等级','建议完成时间','确认后动作'],pending.length ? pending.map((p,i)=>[i+1,p.content,p.owner,p.level,p.deadline || '下一轮评审前',p.action]) : [['—','暂无待确认事项','产品经理','—','下一验收节点','按本轮范围验证，不扩展功能']])}`;
  const draft=[`## PRD 草稿\n状态：${assessment.verdict==='通过'?'设计建议，尚非上线验收证明':'验证方案草案，不作开发放行'}。${referenceDraft?'本地建议来自匹配案例；本次适用范围、参数和实际效果须由责任人确认。':'以下建议来自本轮有效角色记录；未提供的规则明确留待确认。'}`,
    `### 功能概述\n${review.requirement}\n${review.inputs.slice(1).map(s=>`本轮补充：${s}`).join('\n')}`,
    section('业务流程','business_flow','待确认：提交实际操作顺序与各步骤结果，不能从场景模板推定现场流程。'),
    `### 前置条件\n${list(review.intake?.materials).filter(m=>m.quote&&review.inputs.join('\n').includes(m.quote)).map(m=>`- ${m.name}：${m.quote}（提交材料，未独立实测）`).join('\n') || referenceDraft?.前置条件 || '待确认：补齐本轮材料及资源约束。'}`,
    section('功能规则','functional_rules',assessment.perspectives.map(p=>`- ${p.claim}（${p.name}建议；${p.boundary}）`).join('\n') || '待确认：本轮暂无可纳入的功能规则。'),
    section('异常处理','exception_handling',risk.items.map(r=>`- ${r.text}：${r.mitigation}（待验证）`).join('\n') || '待确认：异常触发条件、反馈和恢复路径。'),
    `### 开发分工\n${table(['岗位','事项','优先级'],todo.items.map(t=>[`${t.owner}（${t.stance}）`,`${t.kind==='verification'?'补证/验证：':''}${t.item}`,t.priority]))}`,
    section('运营配置','operations','待确认：运营负责人需明确开关、权限、发布和撤回规则；本轮未提供配置，不臆造。'),
    section('交付售后','handover','待确认：实施及售后负责人补齐部署、验收、诊断和恢复交接材料。'),
    `### 风险清单\n${table(['岗位','风险','等级','影响'],risk.items.length ? risk.items.map(r=>[r.owner,r.text,{high:'高',mid:'中',low:'低'}[r.level],r.impact_tag]) : risk.gaps.filter(g=>g.source==='初评风险假设').map(g=>[g.owner,g.text,{high:'高',mid:'中',low:'低'}[g.level],'待澄清（未实测）']).concat(risk.gaps.some(g=>g.source==='初评风险假设')?[]:[['—','尚无有效业务风险意见，不代表没有风险','待评','待澄清']]))}`,
    section('验收标准','acceptance',assessment.perspectives.map(p=>`- ${p.verification}（${p.name}建议；尚需记录实际结果）`).join('\n') || '待确认：责任岗位补齐可执行用例、预期结果和准出阈值。')
  ].join('\n\n');
  const tracking=`## 验证与执行回填\n${todo.items.filter(t=>t.evidence).map(t=>`- ${t.item}：${t.status}；证据：${t.evidence}`).join('\n') || '暂无执行回填。'}\n${risk.items.filter(r=>r.verification).map(r=>`- ${r.text}：${r.status}；证据：${r.verification.evidence}`).join('\n')}`;
  const history=`## 历史原文（非当前执行范围）\n${originalInputs.map((input,i)=>`${i+1}. ${input}`).join('\n')}`;
  const references=`## 本地交叉验证参考（不作为放行证据）\n${(review.local_references || []).map(r=>`### ${r.case_id} ${r.title}\n匹配词：${r.matched_terms.join('、')}\n${r.applicability}\n前提：${r.premise}\n参考：${r.reply}\n推导：${r.reasoning}\n反驳：${r.challenge}\n回应：${r.response}\n需提供：${r.evidence}\n验证：${r.verify}\n通过条件：${r.accept}\n推翻条件：${r.overturn}\n边界：${r.boundary}`).join('\n\n') || '未启用本地参考。'}`;
  const foundations=(review.local_references || []).filter(r=>r.scenario).map(({scenario:s})=>[
    `### ${s.case_id} ${s.title}\n${s.status}。仅供确认本次适用性，不能替代上方本轮PRD或真实证据。`,
    `现场：${s.context.setting}\n触发：${s.context.trigger}\n受影响对象：${s.context.affected_actor}\n现状对照：${s.context.baseline}\n范围：${s.context.out_of_scope}`,
    `#### 场景流程\n${s.business_flow.map((step,i)=>`${i+1}. ${step.actor}：${step.action}；预期：${step.expected}（${step.status}）`).join('\n')}\n异常：${s.validation.exception}`,
    `#### 责任与原始证据\n${s.participants.map(p=>`- ${p.name}：${p.responsibility}`).join('\n')}\n${s.evidence_requirements.map(e=>`- ${e.id}：${e.required}；责任：${roleName(review,e.owner)}；${e.status}；${e.provenance}`).join('\n')}`,
    `#### 验证及判定分支\n${s.validation.id}：${s.validation.method}\n通过条件：${s.validation.success}\n不通过触发：${s.validation.falsifier}\n待补证：${s.decision.defer.condition}；${s.decision.defer.result}\n阈值与样本：${s.validation.thresholds.status}，${s.validation.thresholds.rule}\n执行状态：${s.validation.execution.status}`,
    `#### 补证任务\n${table(['资料任务编号','岗位','事项','完成条件'],s.artifacts.tasks.map(t=>[t.id,roleName(review,t.owner),t.item,t.done_when]))}`,
    `#### 场景PRD参考\n${Object.entries(s.artifacts.prd_sections).map(([name,value])=>`- ${name}：${value}`).join('\n')}`,
    `#### 变更与经验回流\n追加场景：${s.follow_up.input}\n需要修正：${s.follow_up.expected_revision}\n重审条件：${s.follow_up.reopen_when}\n失效项：${s.follow_up.invalidates.join('、')}\n经验状态：${s.learning.status}\n确认要求：${s.learning.confirmation_requires.join('、')}\n撤回：${s.learning.withdrawal}`
  ].join('\n\n')).join('\n\n');
  const p=assessment.preliminary;
  const c=p.comprehensive;
  const comprehensive=`## 综合研判\n${c.recommendation}\n已评项综合参考分：${c.score===null?'待评':`${c.score}/100`}；覆盖权重${c.coverage}%\n全量区间：${c.interval.min}至${c.interval.max}分\n可信度：${c.confidence}\n${c.formula}\n${c.scope}\n${table(['维度','权重','得分','判断','关键制约','责任岗位与下一步'],c.dimensions.map(d=>[d.name,d.weight,d.rating===null?'待评':`${d.points}/${d.weight}`,d.judgment,d.constraint,`${d.owners.join('、')}：${d.next_action}`]))}\n${c.dimensions.map(d=>`### ${d.name}依据\n${d.criterion}\n${d.sources.map(s=>`- ${s.label}：${s.quote}`).join('\n') || '无可定位依据，保持待评'}`).join('\n')}\n优先处理：${c.blockers.join('；') || '尚未发现规则可识别的硬阻塞，不代表不存在风险'}`;
  const feasibility=`## 必要性、投入与证据\n${feasibilityText({...p.feasibility,recommendation:p.recommendation})}\n${p.feasibility.cost.basis.map(b=>`- 估算原文：${b.quote}`).join('\n')}`;
  const preliminary=`## 初步验证评分\n${p.score} / 100：${p.recommendation}\n${p.scope}\n来源：${p.source}\n必要性：${p.necessity}\n建议方案：${p.proposal}\n成本构成：${p.cost.items.join('、') || '改造范围待确认'}\n${p.cost.constraint}；${p.cost.note}\n${p.cost.formula}\n最小验证：${p.validation.method}\n成功条件：${p.validation.success}\n停止条件：${p.validation.stop_when}\n下一步：${p.next_action}\n${p.formula}\n${table(['维度','得分','满分'],p.dimensions.map(d=>[d.name,d.earned,d.weight]))}\n${p.dimensions.flatMap(d=>d.checks.map(c=>`- ${c.label}：${c.points}/${c.weight}；${c.source}；${c.basis}`)).join('\n')}`;
  const scoreStatus=`## 正式评分状态\n${assessment.score===null?'正式放行待讨论；初步建议与评分见上方':`过程总分：${assessment.score} / 100`}\n${assessment.score===null?'初评分不替代岗位决策和现场验证。':assessment.scoring_reason}`;
  const provenance=review.import_source?`## 回复来源\n${review.import_source.label}\n材料编号：${review.import_source.package_id}\n多角色来自同一份${review.import_source.kind?.startsWith('automatic_')?'模型生成':'人工导入'}回复，不代表独立专家或外部事实核验。`:'';
  const routing=`## 问题与岗位分工\n${assessment.question_routing.method}\n${table(['问题','主答','协作','质询','匹配原文'],assessment.question_routing.issues.map(i=>[i.label,i.lead?roleName(review,i.lead):'责任岗位缺席',i.collaborators.map(r=>roleName(review,r)).join('、'),i.challenger?roleName(review,i.challenger):'待补齐',i.quote]))}`;
  const sceneChecks=`## 场景专项验收\n${assessment.scene_assessment.policy.status}\n${assessment.scene_assessment.scope}\n${assessment.scene_assessment.evidence_required?'本类评审需要人工回填验证证据。':'本类评审核对验收方案，不等于上线验收通过。'}\n${table(['验收项','责任岗位','通过条件','验证方法','失败判据及处置','状态与证据'],assessment.scene_assessment.checks.map(c=>[c.label,roleName(review,c.owner),c.plan?.criterion || '待定义',c.plan?.method || c.expectation,c.plan?.failure_condition || '待定义',`${c.reason}；${c.evidence || '暂无实测记录'}`]))}`;
  const methodReferences=reviewMethodReferences(review);
  const methodAppendix=methodReferences.length?`## 方法出处与适用范围\n以下资料可支持方案设计，不是本项目的实测或放行依据。\n${methodReferences.map(r=>`### ${r.id}\n[${r.title}](${r.url})\n核对日期：${r.checked_at}；${r.usage}；岗位：${r.roles.map(k=>roleName(review,k)).join('、')}\n方法：${r.claim}\n适用：${r.applicability}\n限制：${r.limitations}`).join('\n\n')}`:'';
  return {verdict:assessment.verdict,preliminary:assessment.preliminary.recommendation,pending,method_references:methodReferences,markdown:[basic,provenance,comprehensive,feasibility,preliminary,scoreStatus,routing,sceneChecks,confirm,draft,markdown,tracking,methodAppendix,references,foundations?`## 场景底层资料与闭环（模拟，待确认适用性）\n${foundations}`:'',history].filter(Boolean).join('\n\n')};
}

export function rebuildReviewArtifacts(review,{save=()=>{},emit=()=>{}}={}) {
  if (!review.discussion_complete) throw new Error('讨论尚未结束，不能生成结果');
  review.artifacts={};review.workflow={...initialWorkflow(),chat:'complete'};
  const builders={score:()=>evaluate(review),risk:()=>risks(review,review.artifacts.score),todo:()=>tasks(review,review.artifacts.score,review.artifacts.risk),prd:()=>document(review,review.artifacts.score,review.artifacts.risk,review.artifacts.todo)};
  for (const stage of DELIVERY_STAGES) {
    review.workflow[stage]='running'; save('delivery_started');
    emit({type:'workflow',review_id:review.id,revision:review.revision,workflow:{...review.workflow}});
    review.artifacts[stage]=builders[stage]();
    review.workflow[stage]='complete';save('delivery_completed');
    emit({type:'artifact',review_id:review.id,revision:review.revision,stage,artifact:review.artifacts[stage],workflow:{...review.workflow}});
  }
}

export async function deliverReview(review, hooks) { rebuildReviewArtifacts(review,hooks); }
