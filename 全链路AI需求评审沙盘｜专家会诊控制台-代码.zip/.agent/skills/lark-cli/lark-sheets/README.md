# sheets

## 术语约定

下列词在本 skill 各文档中可能交替出现，但**指同一对象**；解析用户口语时按此映射，不要当成不同概念：

| 标准用语 | 同义 / 口语（均指同一对象） | 说明 |
| --- | --- | --- |
| 工作表（sheet） | 子表、tab、标签页 | spreadsheet 内的单张表；`sheet_id` 是其稳定标识 |
| 电子表格（spreadsheet） | 工作簿、表格 | 顶层容器；由 `--url` 或 `--spreadsheet-token` 定位 |
| reference_id | id | **表内对象**的稳定标识，即各对象主键 flag 接受的值（见下表） |

各类只读对象命令用各自的主键 flag 过滤定位（命名不统一，按此表对照，不要凭直觉拼）：

| 对象 | 主键 flag | 对象 | 主键 flag |
| --- | --- | --- | --- |
| 工作表 sheet | `--sheet-id` | 条件格式规则 | `--rule-id` |
| 图表 chart | `--chart-id` | 筛选视图 | `--view-id` |
| 透视表 pivot | `--pivot-table-id` | 迷你图（按组） | `--group-id` |
| 浮动图片 | `--float-image-id` | | |

## 场景 → 命令速查（拿不准命令名先查这里，别按直觉拼）

把高频**只读**意图映射到**真实存在**的 shortcut。agent 常从 Excel / Google Sheets / 飞书 OpenAPI 误迁移命令名或 flag，先对照本表，避免一次必然失败的试错。完整 shortcut 见各工具参考。**选定命令后先读"参考"列指向的 reference**：命令名对得上不代表用法对，读取分页 / 定位尤其容易漏掉 reference 里的防错规则。

| 你要做的事 | ✅ 正确写法 | 参考 |
| --- | --- | --- |
| 读数据（纯值 / CSV） | `+csv-get`（`--range` 可省略 = 读整个子表，无需先探行列；限定范围才传） | `lark-sheets-read-data` |
| 按列类型结构化读出（喂 DataFrame / round-trip） | `+table-get` | `lark-sheets-read-data` |
| 读值 + 公式 / 样式 / 批注 / 数据验证 | `+cells-get --include value,formula,style,comment,data_validation` | `lark-sheets-read-data` |
| 看某区域下拉框（数据验证）的选项 | `+dropdown-get`（范围用 `--range`） | `lark-sheets-read-data` |
| 查找 / 定位文本 | `+cells-search`（关键字用 `--find`） | `lark-sheets-search-replace` |
| 看子表结构（合并 / 行高列宽 / 冻结 / 隐藏 / 分组） | `+sheet-info` | `lark-sheets-sheet-structure` |
| 看工作簿 / 子表清单 | `+workbook-info` | `lark-sheets-workbook` |
| 取当前文档 revision（版本号） | `+revision-get` | `lark-sheets-workbook` |
| 复核某次（AI）编辑改了什么 / 取两个版本间的变更 | `+changeset-get --start-revision <编辑前版本>`（省略 `--end-revision` 取到最新；版本差 ≤ 20） | `lark-sheets-changeset` |
| 看历史版本列表 | `+history-list` | `lark-sheets-history` |
| 查回滚任务的当前状态 | `+history-revert-status --transaction-id <id>` | `lark-sheets-history` |
| 公式健康自检（扫全表 / 子表的公式错误） | `+formula-verify` | `lark-sheets-formula-verify` |
| 看已有图表配置 | `+chart-list` | `lark-sheets-chart` |
| 看条件格式规则 | `+cond-format-list` | `lark-sheets-conditional-format` |
| 看筛选器配置 | `+filter-list` | `lark-sheets-filter` |
| 看筛选视图 | `+filter-view-list` | `lark-sheets-filter-view` |
| 看透视表配置 | `+pivot-list` | `lark-sheets-pivot-table` |
| 看迷你图 | `+sparkline-list` | `lark-sheets-sparkline` |
| 看浮动图片 | `+float-image-list` | `lark-sheets-float-image` |

> ⚠️ **定位 flag**：`+cells-get` / `+csv-get` / `+dropdown-get` 用 `--range`；**读取附加信息**一律走 `+cells-get --include …`，**没有** `--with-styles` 这类 flag；**看合并单元格**用 `+sheet-info` 的 `merged_cells`，不要在 `+cells-get` 里找 merge flag。
> ⚠️ **要按名称 / 关键词在云空间里找某个表格文件**（不是读某张已知表的内容）：当前沙箱不可用（lark-drive 域仅开放只读查询，不含按名称搜索能力）；需用户直接提供表格的 URL / token，再回本 skill 读内容。

## 执行要点（读取 / 陷阱）

端到端只读工作流：了解结构（`scripts/lark_inspect_workbook.py` / `+workbook-info`）→ 读数据 → 理解语义 → 按需读对象配置 / 自检公式。

### 读取：按需求选路径（细则见 `lark-sheets-read-data`）

| 用户需求 | 读取路径 |
|---|---|
| "查一下 / 看看 / 统计 / 汇总"等只读 | 小表 `+csv-get` 读到上下文；大表先 `+workbook-info` + 小窗口 `+csv-get` 定边界，再对未截断窗口跑 `scripts/lark_detect_subtables.py` / `scripts/lark_profile_table.py` |
| 需要按列类型结构化读出（喂 DataFrame） | `+table-get` |
| 需要公式 / 样式 / 批注 / 数据验证 | `+cells-get --include …` |
| 需要看某区域下拉选项 | `+dropdown-get` |

> 读大表先按 `lark-sheets-read-data` 确认真实数据末行、注意分页标志（`has_more` / `truncated`），不要一口气拉全表撑爆上下文。

### 用脚本配合 CLI 时

- **只读 stdout**：CLI 数据走 stdout、诊断走 stderr；解析 JSON 别 `2>&1`（警告混入会解析失败），用管道或单独重定向 stdout。
- **读表理解优先用 `scripts/lark_*.py`**：`lark_inspect_workbook.py` / `lark_detect_subtables.py` / `lark_profile_table.py` 是随本 skill 分发的只读脚本，用来把在线表格整理成结构摘要（底层只调 `+workbook-info` / `+sheet-info` / `+csv-get`）。可选增强，不是必经步骤——脚本不可用时直接用 CLI 等价路径（对照表见 `lark-sheets-read-data`：`+workbook-info` / `+sheet-info` / 小窗口 `+csv-get`）；需要公式 / 样式 / 批注 / 精确原始值时仍直接用 `+cells-get` / `+table-get`。
- **喂 CLI 的 CSV / JSON 用 UTF-8 无 BOM**；临时文件放系统临时目录、勿落项目目录。
- **命令失败先读 stderr 再调整**，别原样重发。

### 易漏陷阱

- **隐藏行列**：`+csv-get` 默认含隐藏行列；`--skip-hidden=true` 只看可见，真实行号会跳空——禁止按返回数组下标推导行号，用 `annotated_csv` 的 `[row=N]` 或 `row_indices`。
- **跨 sheet 对象**：图表 / 条件格式 / 透视表 / 浮动图片可能分布在多个子表，读取前先 `+workbook-info` 掌握全局。
- **大数字精度**：15 位以上的身份证 / 参考号做去重 / 比较时禁止用 `+csv-get` 的显示值（会显示成科学计数、误判重复），改用 `+cells-get` 取原始精确值（见 `lark-sheets-read-data`）。

## References

先按操作对象进入对应工具参考查具体 shortcut 与调用细节。所有参考仅覆盖只读命令。

| Reference | 描述 |
| --- | --- |
| [Lark Sheet Read Data](references/lark-sheets-read-data.md) | 读取飞书表格中的单元格数据（`+csv-get` / `+cells-get` / `+table-get` / `+dropdown-get`）。当用户需要"看看数据"、"分析数据"、"统计/汇总"，或需要查看公式、样式、批注、数据验证下拉选项时使用。 |
| [Lark Sheet Search](references/lark-sheets-search-replace.md) | 在飞书表格中搜索 / 定位文本（`+cells-search`），支持限定范围、大小写匹配、精确匹配、正则表达式。当用户需要"查找"、"搜索"、"定位"某个值时使用。不要用于理解表格结构（应读取数据）、不要把操作动作关键词（如"汇总金额"）当作搜索词。 |
| [Lark Sheet Sheet Structure](references/lark-sheets-sheet-structure.md) | 查看飞书表格的子表结构与布局（`+sheet-info`）：行高、列宽、隐藏行列、合并单元格、行列分组、冻结等布局信息。 |
| [Lark Sheet Workbook](references/lark-sheets-workbook.md) | 查看飞书表格的工作簿结构（`+workbook-info` 子表列表及元数据）与当前 revision（`+revision-get`）。当用户提到"看看这个表格有什么"、"表格结构"、"有哪些 sheet"、"当前版本号"时使用。 |
| [Lark Sheet Changeset](references/lark-sheets-changeset.md) | 读取两个版本（CS revision）之间的 changeset（原始变更操作清单，`+changeset-get`），用于复核某次编辑——尤其是 AI 编辑——是否真实满足用户诉求。当用户需要"看看这次改了什么"、"核对 AI 改动"、"对比两个版本的变更"时使用。 |
| [Lark Sheet History](references/lark-sheets-history.md) | 查询飞书表格的历史版本列表（`+history-list`）与回滚任务的异步状态（`+history-revert-status`）。当用户需要查看一张表的编辑历史版本列表、或查询某次回滚的进行中/成功/失败状态时使用。 |
| [Lark Sheet Formula Verify](references/lark-sheets-formula-verify.md) | 公式健康自检入口（`+formula-verify`）。对指定子表（或整本工作簿）扫描公式与单元格值，聚合所有 Excel 错误（#REF! / #DIV/0! / #VALUE! / #NAME? / #NULL! / #NUM! / #N/A）与编译失败清单，输出统一 JSON。需要核对一张表里公式是否零错误时使用。 |
| [Lark Sheet Chart](references/lark-sheets-chart.md) | 查看飞书表格中已有图表的配置（`+chart-list`）：类型、数据源、样式。 |
| [Lark Sheet Pivot Table](references/lark-sheets-pivot-table.md) | 查看飞书表格中已有数据透视表的配置（`+pivot-list`）：结构、数据源、展开后的占用区域与状态。 |
| [Lark Sheet Conditional Format](references/lark-sheets-conditional-format.md) | 查看飞书表格中已有条件格式规则的配置（`+cond-format-list`）：规则类型、范围、样式。 |
| [Lark Sheet Filter](references/lark-sheets-filter.md) | 查看飞书表格中已有筛选器（filter）的配置（`+filter-list`）：范围、规则、条件。 |
| [Lark Sheet Filter View](references/lark-sheets-filter-view.md) | 查看飞书表格中已有筛选视图（filter view）的配置（`+filter-view-list`）：视图名、范围、规则。 |
| [Lark Sheet Sparkline](references/lark-sheets-sparkline.md) | 查看飞书表格中已有迷你图组的配置（`+sparkline-list`）：类型、数据源、样式。 |
| [Lark Sheet Float Image](references/lark-sheets-float-image.md) | 查看飞书表格中已有浮动图片的配置（`+float-image-list`）：位置、大小、层级。 |

## 公共 flag 速查

各 reference 的每个 shortcut 标题下用一行徽章标注该 shortcut 支持的公共 / 系统 flag，例如：

- `_公共四件套 · 系统：--dry-run_` — URL/token + sheet 定位（两组各**必给一个**，详见下方「公共 flag」），加 `--dry-run`
- `_公共：URL/token（无 sheet 定位） · 系统：--dry-run_` — 只接 URL/token，常见于 `+workbook-info` / `+revision-get` / `+changeset-get` / `+history-list` 等不强制 sheet 定位的 shortcut

徽章里只列名字。type / 必填 / 描述都在本段统一声明：

### 公共 flag（定位资源）

**公共四件套** = `--url` / `--spreadsheet-token` / `--sheet-id` / `--sheet-name`，分成两组 XOR，**每组都必须给且只能给一个**（XOR = 二选一必填，不是"可选"）：

1. **spreadsheet 定位（必填）**：`--url` 与 `--spreadsheet-token` 二选一，**必须给其中之一**。两个都不给 → 校验报错 `specify at least one of --url or --spreadsheet-token`；两个都给 → 互斥冲突。
   - **`--url` 解析 `/sheets/`、`/spreadsheets/` 与 `/wiki/` 三种链接**（从路径里抽出 token；也可以直接把裸 token 传给 `--spreadsheet-token`）。其它形态的链接不会被解析成表格 token。
   - **`/wiki/` 知识库链接可直接传 `--url`**：会自动定位到链接背后的电子表格；若该链接背后不是电子表格（而是文档 / 多维表格等），则报错。
2. **sheet 定位（公共四件套 shortcut 必填）**：`--sheet-id` 与 `--sheet-name` 二选一，**必须给其中之一**。两个都不给 → 校验报错 `specify at least one of --sheet-id or --sheet-name`。
   - ⚠️ **不确定 sheet 名时禁止直接猜 `Sheet1`**：除非用户对话明确说出 sheet 名 / id，或上下文（之前的工具调用 / URL 锚点 `?sheet=xxx`）已经出现过具体值，否则**第一步先调 `+workbook-info --url "..."`**（或 `--spreadsheet-token`）拿 `sheets[].sheet_id` / `sheets[].title` 列表再选。中文环境下子表常叫"数据" / "Sheet"（无数字）/ "工作表 1" / 业务名，猜 `Sheet1` 大概率撞 `sheet not found`。
   - ⚠️ **`--range` 里的 `Sheet1!` 前缀不能替代 sheet 定位**：即使写了 `--range 'Sheet1!A1:B2'`，仍**必须**额外传 `--sheet-id` 或 `--sheet-name`，否则照样报上面的错。
   - ⚠️ **A1 reference 含 `!`**（`--range`）**：整段用单引号包裹**，如 `--range 'Sheet1!A1:B2'`——单引号能挡住 bash 的 history expansion（`!` 被拦成 `event not found`；双引号挡不住；别改用 `set +H`）。sheet 名含特殊字符（`-` / 空格 / 非 ASCII）需在内部按 A1 标准再包一层单引号时，用 `'\''` 转义保持外层单引号。
   - **例外**：徽章标为 `_公共：URL/token（无 sheet 定位）…_` 的 shortcut（如 `+workbook-info` / `+revision-get` / `+changeset-get` / `+history-list` / `+history-revert-status`）**不接受也不需要** sheet 定位，只给一组 spreadsheet 定位即可。`+table-get` 的 `--sheet-id` / `--sheet-name` 可选（省略读全部子表）。

| Flag | Type | 必填 | 说明 |
| --- | --- | --- | --- |
| `--url` | string | 二选一必填（与 `--spreadsheet-token`） | spreadsheet 或 wiki URL |
| `--spreadsheet-token` | string | 二选一必填（与 `--url`） | spreadsheet token |
| `--sheet-id` | string | 二选一必填（与 `--sheet-name`；仅公共四件套 shortcut） | 工作表 reference_id |
| `--sheet-name` | string | 二选一必填（与 `--sheet-id`；仅公共四件套 shortcut） | 工作表名称 |

**统一调用范式**（公共四件套 shortcut 的所有示例都遵循此形状，两组定位缺一不可）：

```bash
lark-cli sheets <shortcut> <workbook 定位> <sheet 定位> <其它 flag>
#   workbook 定位：--url "..."        或 --spreadsheet-token "..."           （二选一，必给）
#   sheet 定位：    --sheet-id "$SID"  或 --sheet-name "<真实表名>"            （二选一，必给；占位符不要原样填）
# 例：lark-cli sheets +csv-get --url "https://.../sheets/shtXXX" --sheet-name "<真实表名>" --range "A1:F30"
# 注意：真实表名不要直接填 "Sheet1"——大多数表的子表不叫这个；先 +workbook-info 拿 sheets[].title 再代入。
```

### 系统 flag

| Flag | Type | 必填 | 说明 |
| --- | --- | --- | --- |
| `--dry-run` | bool | 否 | 零副作用：仅打印请求路径与参数模板，不发起调用 |
| `--yes` | bool | 是（仅 `high-risk-write`） | 二次确认；不带时退出码 10，需重新带 `--yes` 确认高风险写操作 |

- **envelope**：所有 shortcut 返回统一外层结构 `{ok, identity, data, ...}`。正文里 `envelope.data` 指业务数据层（如 `+csv-get` 的 `annotated_csv`）。

## API（沙箱内仅以下原生 API 调用可用）

绝大多数只读需求都被上面的 shortcut 覆盖；shortcut 没覆盖到时，**仅**以下原生 `<service> <resource> <method>` 组合在本沙箱内可用，不要再自行拼其它 service/api 组合去试：

### spreadsheets

- `get` — 读取电子表格的元数据（等价于 `+workbook-info` 的底层调用）

```bash
lark-cli sheets spreadsheets get
```

### spreadsheet.sheets

- `find` — 在电子表格里查找单元格（等价于 `+cells-search` 的底层调用）

```bash
lark-cli sheets spreadsheet.sheets find
```

### spreadsheet.sheet.filters

- `get` — 读取某个子表的筛选器信息（等价于 `+filter-list` 的底层调用）

```bash
lark-cli sheets spreadsheet.sheet.filters get
```
