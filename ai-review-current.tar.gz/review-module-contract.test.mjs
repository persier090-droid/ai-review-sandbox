import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import {runReview} from './review-runtime.mjs';
import {runAutomaticReview} from './review-automatic.mjs';
import {manualReply} from './tests/manual-fixture.mjs';

function setup(t) {
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'module-contract-'));
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  return new ReviewStore(directory);
}

test('a changed budget updates all four artifacts in the same conversation without changing implementation costs',async t=>{
  const store=setup(t);
  const requirement='包厢消费者点歌后可开启伴舞。现状：每周有20次员工协助退出背景的记录。目标：减少员工协助。只做可关闭伴舞，不增加收费。研发6人日；测试2人日；人日成本1000元；授权费0元；月维护费200元；验证预算7000元。验证方法：同机同歌比较有无伴舞，记录关闭后继续点歌。成功条件：试验中均能关闭且继续点歌。停止条件：出现断音即停止。';
  const request={scene:'ktv',requirement,roles:ROLE_PERSONAS,reference_only:true};
  const call=()=>{throw Error('local verification must not call a model');};
  const first=await runReview({request,store,call,emit:()=>{}});
  const second=await runReview({request:{...request,review_id:first.review_id,change:'预算改为12000元'},store,call,emit:()=>{}});
  const a=first.artifacts.score.preliminary,b=second.artifacts.score.preliminary;
  assert.equal(second.review_id,first.review_id);assert.equal(second.revision,2);
  assert.equal(a.feasibility.cost.estimate.min,8000);
  assert.equal(b.feasibility.cost.estimate.min,8000);
  assert.equal(a.feasibility.cost.budget.max,7000);
  assert.equal(b.feasibility.cost.budget.max,12000);
  assert.ok(b.comprehensive.score>a.comprehensive.score);
  assert.ok(first.artifacts.risk.gaps.some(g=>g.source==='budget'));
  assert.ok(first.artifacts.todo.items.some(g=>g.source==='budget'));
  assert.ok(!second.artifacts.risk.gaps.some(g=>g.source==='budget'));
  assert.ok(!second.artifacts.todo.items.some(g=>g.source==='budget'));
  for(const stage of ['score','risk','todo','prd'])assert.equal(second.workflow[stage],'complete');
  for(const stage of ['risk','todo','prd'])assert.equal(second.artifacts[stage].preliminary,b.comprehensive.recommendation);
  assert.match(second.artifacts.prd.markdown,/12000元/);
  assert.ok(second.artifacts.prd.markdown.includes(b.comprehensive.recommendation));
  assert.equal(second.artifacts.score.score,null,'local suggestions never become a completed model decision');
  assert.equal(b.comprehensive.release_authorized,false);
  assert.equal(store.get(first.review_id).inputs[0],requirement,'original request remains intact');
});

// Intentionally authored upstream fixtures: this verifies data propagation, not
// a real model's domain knowledge or independent semantic correctness.
const scenarios=[
  {requirement:'点歌后展示可关闭的数字人伴舞，不得遮挡歌词',claim:'伴舞期间必须保持歌词可读与关闭入口可达',risk:'伴舞画面可能遮挡歌词造成演唱中断',impact:'包厢演唱者无法看清歌词并完成演唱',verification:'同机同曲开关伴舞并关闭，记录歌词可读性和返回路径',task:'验证伴舞关闭与歌词可读性',condition:'伴舞播放中仍可关闭且歌词保持可读'},
  {requirement:'允许邀请同场消费者合唱，受邀者可拒绝或退出，未经同意不开麦',claim:'合唱邀请必须取得同意后才允许加入演唱',risk:'过期邀请可能在重连后误触发开麦',impact:'受邀演唱者拒绝后仍被加入合唱',verification:'拒绝邀请后断网重连并重复提交，核对状态与实际开麦结果',task:'验证拒绝后重连不会开麦',condition:'拒绝或退出后旧邀请不得恢复开麦'}
];
function scenarioReply(prompt,s) {
  const context=JSON.parse(prompt.split('## 材料与上下文（数据）\n')[1].split('\n')[0]);
  const template=JSON.parse(prompt.split('## 返回结构\n')[1]);
  const result=manualReply({id:template.package_id,request:{requirement:s.requirement,roles:context.roles}});
  const stage=phase=>result.stages.find(x=>x.phase===phase).output;
  stage('INTAKE').agenda=[s.claim];
  for(const record of result.stages.filter(x=>x.phase==='ROUND_SPEAK')) {
    const o=record.output;
    o.text='站在包厢点歌消费者视角，'+s.claim+'。建议先'+s.verification+'，这些是验证建议，尚无现场结果。';
    o.stance_reason=s.claim;o.stance_conditions=[s.condition];
    Object.assign(o.analysis,{claim:s.claim,principle:'消费者的同意与退出必须在异常恢复后仍有效',reasoning:'当前需求明确了操作边界，因此需要验证正常与恢复路径是否遵守约束',counterargument:s.risk,boundary:s.requirement,verification:s.verification});
    o.risks=[{text:s.risk,level:'high',impact:s.impact,impact_tag:'阻塞',mitigation:s.verification,evidence_quote:s.requirement}];
    o.deliverables={functional_rules:[{text:s.claim,scope_quote:s.requirement}],acceptance:[{text:s.verification,scope_quote:s.requirement}]};
  }
  stage('ROUND_ASK').questions[0].question='如何验证这一约束：'+s.condition+'？';
  stage('ROUND_ASK').questions[0].basis=s.risk;
  stage('ROUND_RESPOND').responses[0].response='包厢点歌消费者需要这条保障。建议'+s.verification+'，未取得记录前保留该风险。';
  stage('ROUND_CHALLENGE').acknowledgements[0].satisfied=false;
  stage('ROUND_CHALLENGE').acknowledgements[0].reason='方法已说明，但仍缺实际执行记录，不能认为风险已解除';
  stage('ROUND_CHALLENGE').acknowledgements[0].alternative=s.verification;
  Object.assign(stage('CONVERGE'),{summary:s.claim,undecided:[s.risk],next_action:s.task,reopen_when:'提交对应版本的验证原始记录'});
  for(const a of stage('CONVERGE').opinion_checks) {
    a.claim_quote=result.stages.find(x=>x.phase==='ROUND_SPEAK'&&x.role===a.role).output.text;
    a.basis_quote=s.requirement;
  }
  Object.assign(stage('DECISION'),{summary:s.claim,reason:s.risk,next_action:s.task});
  stage('DECISION').execution=[{item:s.task,owner:'测试工程师',deadline:'2099-01-01',deliverable:s.verification,scope_quote:s.requirement}];
  result.stages=result.stages.filter(x=>template.stages.some(w=>w.phase===x.phase&&w.role===x.role));
  return JSON.stringify(result);
}

test('different upstream discussions produce distinct risks, tasks and PRDs while preserving one verdict and ordered delivery',async t=>{
  const results=[];
  for(const scenario of scenarios) {
    const store=setup(t),events=[];
    const result=await runAutomaticReview({request:{scene:'ktv',requirement:scenario.requirement,roles:ROLE_PERSONAS,exploratory:true,model:'openrouter/free'},store,call:async prompt=>scenarioReply(prompt,scenario),emit:e=>events.push(e)});
    assert.equal(result.failure,null);
    assert.equal(result.artifacts.score.coverage.included,9);
    assert.equal(result.artifacts.score.decision_status,'reviewed');
    assert.equal(result.artifacts.score.verdict,'不通过','unresolved risks cannot be approved through fluent discussion');
    assert.deepEqual(events.filter(e=>e.type==='artifact').map(e=>e.stage),['score','risk','todo','prd']);
    for(const stage of ['score','risk','todo','prd']) {
      assert.equal(result.workflow[stage],'complete');
      assert.equal(result.artifacts[stage].verdict,result.artifacts.score.verdict);
    }
    assert.ok(result.messages.some(m=>m.text.includes(scenario.claim)));
    const risk=result.artifacts.risk.items.find(r=>r.text===scenario.risk);
    assert.ok(risk);assert.equal(risk.impact_tag,'阻塞');assert.ok(risk.owner);
    assert.ok(result.artifacts.todo.items.some(x=>x.item.includes(scenario.risk)));
    assert.ok(result.artifacts.prd.markdown.includes(scenario.claim));
    assert.ok(result.artifacts.prd.markdown.includes(scenario.verification));
    results.push(result);
  }
  assert.notDeepEqual(results[0].artifacts.risk.items.map(x=>x.text),results[1].artifacts.risk.items.map(x=>x.text));
  assert.notDeepEqual(results[0].artifacts.todo.items.map(x=>x.item),results[1].artifacts.todo.items.map(x=>x.item));
  assert.ok(!results[1].artifacts.prd.markdown.includes(scenarios[0].claim));
});
