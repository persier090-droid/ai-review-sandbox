import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import {manualReply} from './tests/manual-fixture.mjs';
import {runAutomaticReview} from './review-automatic.mjs';
import {loadRoleSkill} from './expert-skills.mjs';
import {createHybridCaller} from './deepseek-provider.mjs';

const request={scene:'KTV点歌机',requirement:'点歌后展示数字人舞蹈，消费者可随时关闭，不新增收费',roles:ROLE_PERSONAS,model:'openrouter/free',exploratory:true};
function setup(t) {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'automatic-review-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  return new ReviewStore(dir);
}
function reply(prompt) {
  const context=JSON.parse(prompt.split('## 材料与上下文（数据）\n')[1].split('\n')[0]);
  const template=JSON.parse(prompt.split('## 返回结构\n')[1]);
  const output=manualReply({id:template.package_id,request:{requirement:context.original_requirement,change:context.latest_input,roles:context.roles}});
  output.stages=output.stages.filter(s=>template.stages.some(w=>w.phase===s.phase&&w.role===s.role));
  return output;
}
test('quota exhaustion midway continues the nine-role review on paid provider without replaying free stages',async t=>{
  const store=setup(t);let freeCalls=0,paidCalls=0;
  const call=createHybridCaller({enabled:true,free:async prompt=>{
    if(++freeCalls===4)throw Object.assign(Error('free quota exhausted'),{status:429});
    return JSON.stringify(reply(prompt));
  },paid:async prompt=>{paidCalls++;return JSON.stringify(reply(prompt));}});
  const result=await runAutomaticReview({request,store,emit:()=>{},call,modelSource:{kind:'automatic_hybrid',label:'免费优先，必要时DeepSeek付费续跑 · 模型模拟多岗位'}});
  assert.equal(result.failure,null);assert.equal(result.artifacts.score.coverage.included,9);
  assert.equal(freeCalls,4);assert.equal(paidCalls,6);
  const record=store.get(result.review_id);
  assert.deepEqual(record.import_source.batches.map(b=>b.provider),['openrouter','openrouter','openrouter',...Array(6).fill('deepseek')]);
  for(const stage of ['score','risk','todo','prd'])assert.equal(result.workflow[stage],'complete');
  assert.match(result.artifacts.prd.markdown,/付费续跑/);
});
test('role batches are followed by separate question, response, challenge, audit and decision requests',async t=>{
  const store=setup(t),events=[];let calls=0,raw;
  const seenSkills=new Set(),minimums=[];
  const result=await runAutomaticReview({request,store,emit:e=>events.push(e),call:async(prompt,signal,options)=>{
    minimums.push(options.minimumRequests);
    calls++;
    const stages=JSON.parse(prompt.split('## 返回结构\n')[1]).stages;
    if(stages[0].phase!=='ROUND_SPEAK')assert.equal(stages.length,1,'no future answers or decisions in the same request');
    else {
      const variants=options.responseFormat.json_schema.schema.properties.stages.items;
      for(const variant of variants.anyOf||[variants])assert.equal(variant.properties.output.properties.stance_conditions.items.minLength,6);
    }
    const context=JSON.parse(prompt.split('最新上下文（数据）：')[1].split('\n')[0]);
    if(stages[0].phase==='ROUND_RESPOND')assert.equal(context.questions.length,1);
    if(stages[0].phase==='ROUND_CHALLENGE')assert.equal(context.responses.length,1);
    if(stages[0].phase==='DECISION')assert.match(prompt,/当前产品收口记录/);
    if(stages[0].phase==='ROUND_ASK')assert.equal(options.responseFormat.json_schema.schema.properties.stages.items.properties.output.properties.questions.minItems,1,'conditional positions require a real challenge');
    if(stages[0].phase==='CONVERGE') {
      const quoteChoices=JSON.parse(prompt.split('收口逐岗原文引用（数据）：')[1].split('\n')[0]);
      assert.deepEqual(quoteChoices,context.admitted_opinions.map(o=>({role:o.role,claim_quote:o.text,basis_quotes:o.analysis.basis.map(b=>b.quote)})));
      const audits=options.responseFormat.json_schema.schema.properties.stages.items.properties.output.properties.opinion_checks.items.anyOf;
      assert.equal(audits.length,9);
      for(const audit of audits) {
        const opinion=context.admitted_opinions.find(o=>o.role===audit.properties.role.const);
        assert.deepEqual(audit.properties.claim_quote.enum,[opinion.text]);
        assert.deepEqual(audit.properties.basis_quote.enum,opinion.analysis.basis.map(b=>b.quote));
      }
    }
    const capabilities=JSON.parse(prompt.split('本批岗位完整能力（职责参考，不代表实测依据）：')[1].split('\n')[0]);
    assert.equal(capabilities.map(c=>c.skill).join('\n').split('# KTV 实务评审方法').length-1,1,'common methods are included once per request');
    for(const c of capabilities){
      assert.ok(c.skill_documents.some(p=>p.startsWith('roles/')));
      assert.match(c.skill,/实操步骤/);
      assert.ok(loadRoleSkill(c.role,request.scene).includes(c.skill));
      seenSkills.add(c.role);
    }
    assert.ok(prompt.includes('scene_policy'));assert.ok(prompt.includes('question_routing'));
    raw=JSON.stringify(reply(prompt));return raw;
  }});
  assert.equal(seenSkills.size,9);
  assert.deepEqual(minimums,[9,8,7,6,5,4,3,2,1]);
  assert.equal(calls,9);assert.equal(result.failure,null);
  assert.equal(result.artifacts.score.coverage.included,9);
  assert.equal(result.artifacts.score.decision_status,'reviewed');
  assert.ok(result.phase_progress.every(p=>p.status==='complete'));
  assert.deepEqual(events.filter(e=>e.type==='artifact').map(e=>e.stage),['score','risk','todo','prd']);
  const record=store.get(result.review_id);
  assert.equal(record.import_source.batches.at(-1).raw,raw);assert.equal(record.usage.remote_calls,9);
  assert.ok(record.messages.some(m=>m.source?.includes('模型模拟')));
  assert.doesNotMatch(record.artifacts.prd.markdown,/人工导入/);
  assert.ok(events.findIndex(e=>e.type==='review_started')<events.findIndex(e=>e.status==='batch_generating'));
});
test('invalid quotations are still excluded and missing role bundles do not fabricate discussion',async t=>{
  for(const mutate of [r=>{const s=r.stages.find(s=>s.role==='pd');if(s)s.output.analysis.basis[0].quote='伪造的全设备验收成功记录';},r=>{const i=r.stages.findIndex(s=>s.role==='pd');if(i>=0)r.stages.splice(i,1);}]) {
    const store=setup(t);
    const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{const r=reply(prompt);mutate(r);return JSON.stringify(r);}});
    assert.notEqual(result.artifacts.score.verdict,'通过');
    assert.notEqual(result.role_status.pd?.included,true);
    assert.ok(store.get(result.review_id).import_source.raw);
  }
});
test('429 remains pending, consumes one attempt, and never invents votes or a score',async t=>{
  const store=setup(t);let calls=0;
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async()=>{calls++;throw Object.assign(new Error('免费额度暂不可用'),{status:429});}});
  assert.equal(calls,1);assert.equal(result.failure.http_status,429);
  assert.equal(result.artifacts.score.verdict,'待讨论');assert.equal(result.artifacts.score.score,null);
  assert.equal(result.artifacts.score.coverage.included,0);
});

test('interrupted batches resume after admitted roles and preserve earlier original replies',async t=>{
  const store=setup(t);let calls=0;
  const first=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{calls++;if(calls===3)throw Object.assign(new Error('quota'),{status:429});return JSON.stringify(reply(prompt));}});
  assert.equal(first.artifacts.score.coverage.included,3);
  const original=store.get(first.review_id).import_source.batches;
  calls=0;
  const resumed=await runAutomaticReview({request:{...request,review_id:first.review_id,resume_discussion:true},store,emit:()=>{},call:async prompt=>{calls++;return JSON.stringify(reply(prompt));}});
  assert.equal(calls,7);assert.equal(resumed.failure,null);assert.equal(resumed.artifacts.score.coverage.included,9);
  assert.deepEqual(store.get(first.review_id).import_source.batches.slice(0,original.length),original);
});

test('repeated intake stages cannot masquerade as nine role replies',async t=>{
  const store=setup(t);let calls=0;
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    calls++;const output=reply(prompt);output.stages=Array.from({length:9},()=>output.stages[0]);return JSON.stringify(output);
  }});
  assert.equal(calls,1);assert.match(result.failure.message,/重复/);
  assert.equal(result.artifacts.score.coverage.included,0);assert.equal(result.artifacts.score.verdict,'待讨论');
});

test('only rejected roles get one repair batch before questions and decisions',async t=>{
  const store=setup(t),prompts=[],seen={},events=[];
  const result=await runAutomaticReview({request,store,emit:e=>events.push(e),call:async prompt=>{
    prompts.push(prompt);const output=reply(prompt);
    for(const stage of [...output.stages])if(stage.phase==='ROUND_SPEAK') {
      seen[stage.role]=(seen[stage.role] || 0)+1;
      if(stage.role==='test'&&seen.test===1)stage.output.text='作为测试工程师，我建议先验证关闭操作，再进行交付。';
      if(stage.role==='project'&&seen.project===1)output.stages.push(structuredClone(stage));
    }
    return JSON.stringify(output);
  }});
  assert.equal(result.failure,null);
  assert.equal(prompts.length,10);
  assert.equal(result.artifacts.score.coverage.included,9);
  for(const role of ROLE_PERSONAS)assert.equal(seen[role.key],['test','project'].includes(role.key)?2:1,role.key);
  assert.match(prompts[4],/发言正文未告知具体对象视角/);
  assert.match(prompts[4],/重复/);
  assert.match(prompts[4],/作为测试工程师，我建议先验证关闭操作/);
  assert.ok(events.some(e=>e.status==='repairing_roles'));
  const record=store.get(result.review_id);
  assert.equal(record.messages.filter(m=>m.phase==='ROUND_SPEAK'&&!m.participation).length,9);
  assert.equal(record.import_source.batches.length,10);
});

test('persistent invalid roles stop after one repair and resume only holes across restart',async t=>{
  const store=setup(t);let calls=0;
  const first=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    calls++;const output=reply(prompt);
    assert.ok(output.stages.every(s=>!['ROUND_ASK','DECISION'].includes(s.phase)),'no premature conclusion');
    for(const stage of output.stages)if(['test','project'].includes(stage.role))stage.output.text='作为专业岗位，我建议验证之后再做决定。';
    return JSON.stringify(output);
  }});
  assert.equal(calls,5);assert.equal(first.artifacts.score.coverage.included,7);
  assert.equal(first.artifacts.score.verdict,'待讨论');assert.equal(first.artifacts.score.score,null);
  assert.match(first.failure.message,/补答/);
  const before=store.get(first.review_id),restored=new ReviewStore(store.directory),prompts=[];
  const resumed=await runAutomaticReview({request:{...request,review_id:first.review_id,resume_discussion:true},store:restored,emit:()=>{},call:async prompt=>{
    prompts.push(prompt);return JSON.stringify(reply(prompt));
  }});
  assert.equal(prompts.length,6);
  assert.deepEqual(JSON.parse(prompts[0].split('## 返回结构\n')[1]).stages.map(s=>s.role),['test','project']);
  assert.match(prompts[0],/保留的岗位原始意见/);
  assert.equal(resumed.failure,null);assert.equal(resumed.revision,first.revision);
  assert.equal(resumed.artifacts.score.coverage.included,9);
  const after=restored.get(first.review_id);
  for(const role of before.role_results)assert.deepEqual(after.role_results.find(r=>r.role===role.role),role);
  assert.equal(after.messages.filter(m=>m.phase==='ROUND_SPEAK').length,9);
  assert.equal(after.messages.filter(m=>m.phase==='USER_INPUT').length,1);
  assert.deepEqual(after.import_source.batches.slice(0,before.import_source.batches.length),before.import_source.batches);
  assert.equal(after.import_source.batches.length,11);
});

test('quota exhaustion during repair preserves valid roles and does not loop or finalize',async t=>{
  const store=setup(t);let calls=0;
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    calls++;
    if(calls===5){assert.match(prompt,/补答要求/);throw Object.assign(new Error('free quota exhausted'),{status:429});}
    const output=reply(prompt);
    for(const stage of output.stages)if(stage.role==='test')stage.output.analysis.basis[0].quote='不存在的验收成功证明';
    return JSON.stringify(output);
  }});
  assert.equal(calls,5);assert.equal(result.failure.http_status,429);
  assert.equal(result.failure.stage,'ROUND_SPEAK');
  assert.equal(result.artifacts.score.coverage.included,8);
  assert.equal(result.conclusion,null);assert.equal(result.artifacts.score.score,null);
});

test('a rejected answer resumes after the original question without redoing valid opinions',async t=>{
  const store=setup(t);
  const first=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    const output=reply(prompt),answer=output.stages.find(s=>s.phase==='ROUND_RESPOND');
    if(answer)answer.output.responses[0].response='未说明具体对象视角，不能纳入本轮回应';
    return JSON.stringify(output);
  }});
  assert.ok(first.failure);
  const before=store.get(first.review_id),prompts=[];
  assert.equal(before.checkpoints['ROUND_RESPOND:'],undefined,'a rejected response must never become a checkpoint');
  const resumed=await runAutomaticReview({request:{...request,review_id:first.review_id,resume_discussion:true},store,emit:()=>{},call:async prompt=>{
    prompts.push(prompt);return JSON.stringify(reply(prompt));
  }});
  assert.equal(prompts.length,4);
  assert.deepEqual(prompts.map(p=>JSON.parse(p.split('## 返回结构\n')[1]).stages[0].phase),['ROUND_RESPOND','ROUND_CHALLENGE','CONVERGE','DECISION']);
  assert.equal(resumed.failure,null);assert.equal(resumed.artifacts.score.coverage.included,9);
  assert.deepEqual(store.get(first.review_id).checkpoints['ROUND_ASK:'],before.checkpoints['ROUND_ASK:']);
});

test('an audit that agrees without locating the actual opinion cannot advance to a decision',async t=>{
  const store=setup(t),phases=[];
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    const output=reply(prompt);phases.push(...output.stages.map(s=>s.phase));
    const audit=output.stages.find(s=>s.phase==='CONVERGE');
    if(audit)for(const item of audit.output.opinion_checks){item.claim_quote='这个判断在原始发言中不存在';item.basis_quote=request.requirement;}
    return JSON.stringify(output);
  }});
  assert.equal(result.failure?.stage,'CONVERGE');
  assert.match(result.failure.message,/复核.*原文/);
  assert.equal(phases.includes('DECISION'),false);
});
test('risk citation repair identifies the exact field mismatch and preserves unrelated opinions',async t=>{
  const store=setup(t);let seen=0,repair='';
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    const output=reply(prompt),pd=output.stages.find(s=>s.role==='pd');
    if(pd&&++seen===1)pd.output.risks=[{text:'关闭路径可能出现中断',level:'mid',impact:'包厢消费者不能继续点歌',mitigation:'关闭伴舞后再次点歌并记录',evidence_quote:'伪造的消费者关闭成功记录'}];
    else if(pd)repair=prompt;
    return JSON.stringify(output);
  }});
  assert.equal(result.failure,null);
  assert.match(repair,/evidence_quote.*analysis\.basis/);
  assert.match(repair,/伪造的消费者关闭成功记录/);
  assert.equal(result.artifacts.score.coverage.included,9);
});
test('unresolved conditions cannot skip questioning even if the provider ignores its schema',async t=>{
  const store=setup(t);
  const result=await runAutomaticReview({request,store,emit:()=>{},call:async prompt=>{
    const output=reply(prompt),ask=output.stages.find(s=>s.phase==='ROUND_ASK');
    if(ask)ask.output={questions:[],no_questions_reason:'已经记录了阻塞条件，不需要再提问'};
    return JSON.stringify(output);
  }});
  assert.equal(result.failure?.stage,'ROUND_ASK');
  assert.equal(result.conclusion,null);
  assert.equal(result.artifacts.score.coverage.included,9);
});
