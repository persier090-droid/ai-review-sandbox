> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 执行跟踪 execution-tracking

## 用途
跟踪评审结论的执行情况，确保结论落地。

## 跟踪对象

评审结论中的每一执行项都必须被跟踪：


tracking_item:
  id: 编号
  review_id: 所属评审
  item: 执行项内容
  owner: 责任人
  deadline: 截止时间
  deliverable: 交付物
  status: 待开始/进行中/已完成/逾期/取消
  progress: 进度百分比
  last_update: 最后更新时间
  blocker: 阻塞项（如有）
跟踪频率

执行项类型	跟踪频率
致命（影响客户）	每日
严重（影响交付）	每 2 日
一般（影响质量）	每周
观察（长期）	每 2 周
逾期处理


截止时间到达 → 检查是否完成
  → 已完成：记录，关闭
  → 未完成但进度 > 80%：延期一次，记录原因
  → 未完成且进度 < 80%：升级到责任人上级
  → 连续逾期 2 次：升级到评审主持人
跟踪报告

每周生成跟踪报告：


tracking_report:
  week: 周次
  total_items: 总数
  completed: 已完成
  in_progress: 进行中
  overdue: 逾期
  cancelled: 取消
  top_blockers: [阻塞项列表]
  escalations: [升级项列表]
禁止行为

禁止不跟踪
禁止逾期不处理
禁止不记录阻塞项
禁止连续逾期不升级
