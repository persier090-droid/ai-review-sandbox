import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {buildProviderRequest} from './server.mjs';

test('DeepSeek uses its official chat JSON stream protocol, not OpenRouter pricing parameters',()=>{
  const wire=buildProviderRequest({provider:'deepseek',apiKey:'fixture',model:'deepseek-flash',baseUrl:'https://api.deepseek.com',messages:[{role:'user',content:'返回JSON'}],responseFormat:{type:'json_schema',json_schema:{schema:{}}}});
  assert.equal(wire.url,'https://api.deepseek.com/chat/completions');
  assert.equal(wire.headers.authorization,'Bearer fixture');
  const body=JSON.parse(wire.body);
  assert.deepEqual(body.response_format,{type:'json_object'});
  assert.deepEqual(body.thinking,{type:'disabled'});
  assert.equal(body.provider,undefined);assert.equal(body.plugins,undefined);
});

test('DeepSeek cannot make any inference under the existing free-only policy',async()=>{
  const {createDeepSeekBudget}=await import('./deepseek-provider.mjs');
  const budget=createDeepSeekBudget({apiKey:'fixture',allowPaid:false,limitCny:2});
  assert.equal(budget.inspect().state,'payment_disabled');
  assert.throws(()=>budget.reserve({messages:[],max_tokens:8192}),/免费|付费/);
});

test('paid reservations persist before dispatch and cannot exceed an explicit cumulative limit',async t=>{
  const {createDeepSeekBudget}=await import('./deepseek-provider.mjs');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'deepseek-budget-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const options={apiKey:'fixture',allowPaid:true,limitCny:0.1,filename:path.join(dir,'budget.json')};
  const budget=createDeepSeekBudget(options);
  const concurrent=createDeepSeekBudget(options);
  budget.reserve({messages:[{role:'user',content:'输出JSON'}],max_tokens:8192});
  assert.ok(budget.inspect().reserved_cny>0);
  const restored=createDeepSeekBudget(options);
  assert.equal(restored.inspect().reserved_cny,budget.inspect().reserved_cny);
  assert.throws(()=>concurrent.reserve({messages:[],max_tokens:8192}),/预算/);
  assert.throws(()=>restored.reserve({messages:[],max_tokens:8192}),/预算/);
  assert.equal(restored.inspect().free_only,false);
});

test('missing keys, invalid limits and damaged ledgers fail closed',async t=>{
  const {createDeepSeekBudget}=await import('./deepseek-provider.mjs');
  assert.throws(()=>createDeepSeekBudget({apiKey:'',allowPaid:true,limitCny:2}).reserve({messages:[]}),/密钥/);
  for(const limitCny of [0,-1,NaN,Infinity])assert.throws(()=>createDeepSeekBudget({apiKey:'fixture',allowPaid:true,limitCny}).reserve({messages:[]}),/预算/);
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'deepseek-bad-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const filename=path.join(dir,'budget.json');fs.writeFileSync(filename,'broken');
  const b=createDeepSeekBudget({apiKey:'fixture',allowPaid:true,limitCny:2,filename});
  assert.throws(()=>b.reserve({messages:[]}),/账本/);
});

test('successful usage releases only unused reservation and cannot be settled twice',async t=>{
  const {createDeepSeekBudget}=await import('./deepseek-provider.mjs');
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'deepseek-settle-'));t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  const opts={apiKey:'fixture',allowPaid:true,limitCny:0.1,filename:path.join(dir,'budget.json')};
  const b=createDeepSeekBudget(opts),other=createDeepSeekBudget(opts);
  const receipt=b.reserve({messages:[],max_tokens:8192});
  assert.equal(b.settle(receipt,{prompt_tokens:1000,completion_tokens:100}),true);
  assert.equal(other.inspect().reserved_cny,0.0028);
  assert.equal(b.settle(receipt,{prompt_tokens:1,completion_tokens:1}),false);
  const next=other.reserve({messages:[],max_tokens:8192}),held=b.inspect().reserved_cny;
  assert.equal(other.settle(next,{prompt_tokens:NaN,completion_tokens:100}),false);
  assert.equal(other.settle(next,{prompt_tokens:1000000,completion_tokens:100}),false);
  assert.equal(b.inspect().reserved_cny,held);
});

test('free quota failure switches once to paid and carries the identical phase context forward',async()=>{
  const {createHybridCaller}=await import('./deepseek-provider.mjs');
  let freeCalls=0,paidCalls=0,switches=0;
  const options={minimumRequests:9};const signal=new AbortController().signal;
  const call=createHybridCaller({enabled:true,notify:()=>switches++,free:async()=>{freeCalls++;throw Object.assign(Error('quota'),{code:'FREE_QUOTA_INSUFFICIENT',status:429});},paid:async(prompt,s,opts)=>{paidCalls++;assert.equal(s,signal);assert.equal(opts,options);return prompt;}});
  assert.equal(await call('original current context',signal,options),'original current context');
  await call('next actual phase',signal,options);
  assert.equal(freeCalls,1);assert.equal(paidCalls,2);assert.equal(switches,1);
  assert.equal(call.stats().active_provider,'deepseek');
});

test('paid fallback requires authorization and never masks bad request or cancellation',async()=>{
  const {createHybridCaller}=await import('./deepseek-provider.mjs');
  let paid=0;
  for(const [enabled,status] of [[false,429],[true,400]]){
    const c=createHybridCaller({enabled,free:async()=>{throw Object.assign(Error('failed'),{status});},paid:async()=>paid++});
    await assert.rejects(c('test',new AbortController().signal),/failed/);
  }
  const controller=new AbortController();controller.abort();
  const c=createHybridCaller({enabled:true,free:async()=>{throw Object.assign(Error('quota'),{status:429});},paid:async()=>paid++});
  await assert.rejects(c('test',controller.signal));assert.equal(paid,0);
});
