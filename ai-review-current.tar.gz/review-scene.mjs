import crypto from 'node:crypto';
import {sceneKey} from './review-context.mjs';
import {scopeText} from './review-scope.mjs';

const PROFILES={
  ktv:[
    ['song-flow','点歌主流程与退出恢复',['client','test'],'核对点歌、切歌、暂停、歌词可读性；关闭新增功能后可回到既有流程'],
    ['service-recovery','弱网与服务恢复',['server','client','service'],'断网、重连和重复请求不能丢失或重复有效操作，失败保留可用路径'],
    ['content-config','内容权限与配置范围',['op','pd'],'明确素材使用范围、门店开关与发布撤回权限；无法确认的素材不得默认可用']
  ],
  saas:[
    ['tenant-isolation','租户数据隔离',['server','test'],'跨租户访问必须拒绝，列表、详情、导出和后台任务均核对租户边界'],
    ['access-audit','权限与审计',['server','h5'],'最小权限、权限撤销和关键变更可追溯，界面隐藏不能替代服务端授权'],
    ['data-recovery','一致性与恢复',['server','service'],'并发、重试及中断不重复写入，失败可定位并按已确认策略恢复']
  ],
  car:[
    ['driving-state','驻车演唱与驾驶状态约束',['client','pd'],'车载KTV首期限定驻车演唱；按车型约束验证状态变化或未知时的歌词、点歌、麦克风交互限制'],
    ['safe-fallback','音频优先级与退出恢复',['client','server'],'分别验证伴奏、人声、通话和重要提示的音频路由与优先级；断连、退出和故障时不影响原车音响及重要声音'],
    ['compatibility','车型与音响兼容',['project','test'],'覆盖承诺车型、功放、麦克风及系统版本，验证时延、失真、同步和回退；未覆盖范围不默认支持']
  ],
  app:[
    ['permission','授权与撤回',['client','pd'],'拒绝和撤销权限后仍有明确反馈与可用路径，明确数据保留和删除边界'],
    ['retry-state','重试与状态恢复',['client','server'],'弱网重试、前后台切换和进程恢复不重复操作或丢失已确认状态'],
    ['platform','平台与版本适配',['client','test'],'约定支持平台及版本，核对布局、输入与关键功能兼容，未验证范围不承诺']
  ],
  web:[
    ['authorization','访问控制与审计',['server','h5'],'服务端验证操作权限，核对会话失效、权限撤回与关键变更记录'],
    ['destructive-action','重要操作与恢复',['h5','server'],'重要变更有确认、失败反馈和恢复策略，重复提交不造成重复结果'],
    ['browser-state','浏览器与状态一致性',['h5','test'],'核对约定浏览器、刷新和多标签行为，处理中与失败状态必须可辨认']
  ]
};
export function scenePolicy(scene) {
  const key=sceneKey(scene);
  return {version:key==='car'?'scene-gates-car-v2':'scene-gates-v1',scene:key,status:'项目验收规则，非行业认证；具体阈值须由本轮材料与责任人约定',checks:(PROFILES[key] || []).map(([id,label,owners,expectation])=>({id:`${key}:${id}`,label,owners,expectation}))};
}
export const SCENE_CONTRACT='DECISION必须按scene_policy.checks逐项返回scene_checks:[{id,owner,scope_quote,criterion,method,failure_condition}]。owner为已参会且在该项owners内的岗位key；scope_quote逐字引用有效需求至少六字。criterion明确本需求可观察的通过结果，method明确测试对象、操作与记录，failure_condition明确失败判据及处置。只定义本次范围的验收，不把通用维度当作新增功能或已知事实，不编造阈值或实测。未涉及的维度应说明如何核对现有能力未受影响，不自行免检。交付/质量/复盘必须另有人工回填证据，模型不得声称完成验证。';
const detailed=s=>typeof s==='string'&&s.trim().length>=6;
const hash=value=>crypto.createHash('sha256').update(JSON.stringify(value)).digest('hex');
export function assessScene(review) {
  // Always derive requirements locally; a model or old record cannot relax policy.
  const policy=scenePolicy(review.scene),scope=scopeText(review),selected=new Set((review.roles || []).map(r=>r.key));
  const evidenceRequired=['delivery','quality','retrospective'].includes(review.review_type);
  const entries=Array.isArray(review.conclusion?.scene_checks)?review.conclusion.scene_checks:[];
  const checks=policy.checks.map(check=>{
    const matches=entries.filter(e=>e?.id===check.id),plan=matches.length===1?matches[0]:null;
    const problems=[];
    if(!plan)problems.push(matches.length?'验收项重复，须明确唯一标准':'缺少本轮验收方案');
    if(plan){
      if(!selected.has(plan.owner)||!check.owners.includes(plan.owner))problems.push('责任岗位未参会或超出专业范围');
      if(Array.isArray(review.role_results)&&!review.role_results.some(o=>o.role===plan.owner))problems.push('责任岗位尚无可纳入的专业意见');
      if(!detailed(plan.scope_quote)||!scope.includes(plan.scope_quote))problems.push('未引用当前有效需求原文');
      for(const [key,label] of [['criterion','通过条件'],['method','验证方法'],['failure_condition','失败判据及处置']])if(!detailed(plan[key]))problems.push(`缺少具体${label}`);
    }
    const contract_key=hash({version:policy.version,scene:policy.scene,scope,id:check.id,plan:plan&&Object.fromEntries(['owner','scope_quote','criterion','method','failure_condition'].map(k=>[k,plan[k]]))});
    const evidence=(review.scene_verifications || []).findLast(v=>v.contract_key===contract_key&&v.source==='human');
    const verified=evidence?.status==='通过'&&detailed(evidence.evidence);
    const plan_valid=!problems.length;
    const passed=plan_valid&&evidence?.status!=='不通过'&&(!evidenceRequired||verified);
    return {...check,plan,plan_valid,contract_key,revision:review.revision,owner:plan?.owner || check.owners.find(k=>selected.has(k)) || 'pd',status:evidence?.status || (plan_valid?'待验证':'待定义'),evidence:evidence?.evidence || '',verified,passed,reason:problems.join('；') || (evidence?.status==='不通过'?'人工验证未通过，需处理后重新复核':evidenceRequired&&!verified?'当前评审类型需要实际验证证据':verified?'已有人工验证记录，仍需责任决策复核':'验收方案已定义；尚未实测，不作为上线验收证明')};
  });
  const unknown=entries.some(e=>!policy.checks.some(c=>c.id===e?.id));
  return {policy,evidence_required:evidenceRequired,checks,passed:checks.length>0&&!unknown&&checks.every(c=>c.passed),error:unknown?'存在未定义的场景验收项':!checks.length?'场景未配置验收规则，需先明确场景':'',scope:'方案完整性检查与人工证据追踪；不自动证明阈值合理性、事实真实性或行业合规'};
}
