# 预测回填

metric/value/unit/operator/tolerance/owner/verify_by/method/assumption/assertion_ids 均须给出。
value 与 tolerance 为有限数值；operator 为 <=、>=、=；verify_by 为日期；单位和测量窗口须一致。
真实回填包含 actual、evidence、attribution、reason，自动计算偏差与是否达到目标。预测为0时偏差率留空。
回填记录不覆盖，未达到目标会触发相关断言待复核。复盘需要对比场景和约束，不能仅凭数值不符判定断言错误。
