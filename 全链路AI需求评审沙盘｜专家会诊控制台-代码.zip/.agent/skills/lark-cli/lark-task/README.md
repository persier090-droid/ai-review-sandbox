# task (v2)

## 身份

任务查询针对当前登录用户（默认 `--as user`）。当用户提到"我"（例如"分配给我""由我创建""我关注的"）时，默认取当前登录用户的 `open_id` 作为对应参数值。

## 搜索 vs 列取（意图判断）

- **任务搜索技巧**：先区分用户是否**特地指定使用搜索**，以及是否真的提供了**查询关键字**（例如任务名称、关键词、片段描述）。如果用户特地指定使用搜索，或明确给出了任务查询关键字，则目标是**任务**时优先使用 `+search`。如果用户没有特地指定使用搜索，且意图里没有查询关键字，只有范围条件（例如"今年以来""已完成""由我创建""我关注的"），并且列取与搜索都能达到目的时，应优先使用列表型能力：其中"与我相关 / 我关注的 / 由我创建"优先 `+get-related-tasks`；"我负责的 / 分配给我"优先 `+get-my-tasks`。不要把时间范围词（例如"今年以来"）本身误当成 `query` 去走搜索。
- **任务搜索相关性提示**：`+search` 当前不会自动判断搜索结果与搜索发起人的相关性。如果用户明确要求搜索"与我相关"的任务，必须先识别具体关系，获取当前用户的 `open_id`，并显式传入对应的 `--assignee`（负责人）、`--creator`（创建人）或 `--follower`（关注人）过滤条件；不能只依赖 `query` 期待自动返回与当前用户相关的任务。
- **任务清单搜索技巧**：任务清单遵循同样的判断逻辑。有清单查询关键字（清单名称、关键词、片段描述）或明确要求搜索时用 `+tasklist-search`；若只有范围条件（例如"由我创建的任务清单""今年以来创建的清单"），可用原生 `tasklists list` 列取（先 `lark-cli schema task.tasklists.list`，再 `lark-cli task tasklists list --as user ...`），再按 `creator`、`created_at` 等字段做本地筛选和分页控制。
- **意图区分补充**：像"搜索飞书中今年以来我关注的任务"这类表达，虽字面带"搜索"，但若无真正查询关键字、本质是限定"与我相关 + 时间范围"，应优先走 `+get-related-tasks`；像"搜索飞书中由我创建的任务清单"，若无清单关键字、本质是限定"清单范围 + 创建者"，应优先用原生 `tasklists list` 后本地筛选。

## 待办归属 disambiguation（必读）

用户提到「待办 / todo / 任务」时，**先判断归属**，不要默认走本 skill：

- **妙记里的待办能力在当前沙箱不可用**（也不走本 skill）：上下文含 **妙记 / 会议纪要 / minute_token / 妙记 URL**（`/minutes/`）；或「在某某妙记里新建/修改待办」「妙记 AI 待办」「会议录制里的待办」——直接告知用户该能力当前在沙箱不可用，不要用本 skill 或其它域命令替代。
- **走本 skill（lark-task）**：任务清单、分配给我、项目待办、截止日期/提醒、子任务、任务清单成员；或 applink 含 `client/todo/task?guid=`；或明确说「飞书任务」「任务中心」「我的任务清单」。
- 用户要在妙记里加待办时，不要用 task 命令去「找清单再放任务」。

## 输出与渲染

- **友好输出**：输出任务（或清单）结果时，建议同时提取并输出返回结果里的 `url` 字段（任务链接），方便用户点击跳转。
- **人员字段**：渲染负责人、创建人、owner、成员等人员字段时，除展示 `id`（如 open_id）外，应尽量通过通讯录（`lark-cli contact +search-user --user-ids <open_id>`）解析并展示真实姓名，便于识别。
- **时间字段**：渲染创建时间、截止时间等字段时使用本地时区，格式为 `2006-01-02 15:04:05`。

## Task GUID 定义

Task OpenAPI 中用于操作任务的 `guid` 是任务的全局唯一标识（GUID），不是客户端展示的任务编号（例如 `t104121` / `suite_entity_num`）。对于飞书任务 applink（例如 `.../client/todo/task?guid=...`），必须使用 URL query 里的 `guid` 参数作为 task guid。

## Shortcuts

| Shortcut | 说明 |
|----------|------|
| [`+get-my-tasks`](references/lark-task-get-my-tasks.md) | 列出分配给当前用户的任务（支持按完成状态、创建时间、截止时间过滤） |
| [`+get-related-tasks`](references/lark-task-get-related-tasks.md) | 列出与当前用户相关的任务（支持仅看我创建 / 我关注） |
| [`+search`](references/lark-task-search.md) | 按关键词与过滤条件搜索任务 |
| [`+tasklist-search`](references/lark-task-tasklist-search.md) | 按关键词与过滤条件搜索任务清单 |

## API Resources

除上述快捷命令外，本域在沙箱内**仅**以下只读原生 API 命令可用（通用格式 `lark-cli task <resource> <method> [flags]`）：

### tasks

- `get` — 获取任务详情
- `list` — 列取任务列表

### tasklists

- `get` — 获取清单详情
- `list` — 获取清单列表
- `tasks` — 获取清单任务列表

### subtasks

- `list` — 获取任务的子任务列表

示例：

```bash
# 获取单个任务详情
lark-cli task tasks get --task-guid <task_guid>

# 获取清单下的任务列表
lark-cli task tasklists tasks --tasklist-guid <tasklist_guid>
```

### 查询方法的使用方式

- 查看方法的 cli flag：`lark-cli task <resource> <method> -h`
- 查看方法 API 参数：`lark-cli schema task.<resource>.<method>`（例：`lark-cli schema task.tasks.get`）

沙箱内仅上述 API 命令可用，不要尝试其它 `service`/`api` 组合或写操作方法。

## 权限表（保留只读命令）

| 方法 | 所需 scope |
|------|-----------|
| `tasks.get` | `task:task:read` |
| `tasks.list` | `task:task:read` |
| `tasklists.get` | `task:tasklist:read` |
| `tasklists.list` | `task:tasklist:read` |
| `tasklists.tasks` | `task:tasklist:read` |
| `subtasks.list` | `task:task:read` |

## 常用其他域命令

```bash
# 把任务里的人员 open_id 解析为真实姓名，更多参数详见 lark-contact
lark-cli contact +search-user --user-ids <open_id>
```
