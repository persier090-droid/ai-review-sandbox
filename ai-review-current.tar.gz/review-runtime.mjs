import crypto from 'node:crypto';
import {ROLE_NAMES, REVIEW_CONTRACT, DISCUSSION_CONTRACT, selectAssertions, validateDiscussionOutput, validPremise, loadRoleSkill, loadProtocol, requiresChallenge} from './expert-skills.mjs';
import {buildContext, CONVERGENCE_RULES, sceneKey} from './review-context.mjs';
import {deliverReview,initialWorkflow} from './review-delivery.mjs';
import {normalizeRoles,sceneStructure,rolePrompt,roleName} from './role-personas.mjs';
import {resolveScope,scopeText} from './review-scope.mjs';
import {sourceFingerprint} from './scripts/source-fingerprint.mjs';
import {localCrossChecks,localDiscussion} from './review-local-reference.mjs';
import {localScope} from './review-local-scope.mjs';
import {assessPreliminary} from './review-preliminary.mjs';
import {assessFeasibility} from './review-feasibility.mjs';
import {routeQuestions} from './review-routing.mjs';
import {scenePolicy,SCENE_CONTRACT,assessScene} from './review-scene.mjs';

export const REVIEW_LIMITS = {maxCalls:16, maxMs:180000, maxQuestions:4};

export const REVIEW_TYPES = {
  requirement: {name:'需求评审', order:['pd','sales','test','project','client','server','h5'], required:['pd','sales','project','test'], deciders:['pd'], materials:['需求描述','目标用户','成功指标','竞品对比','不做的后果','资源估算']},
  solution: {name:'方案评审', order:['client','server','test','project','pd','h5','sales'], required:['pd','client','server','test','project'], deciders:['client','server'], materials:['技术方案','容量估算','成本估算','降级方案','风险清单','替代方案']},
  delivery: {name:'交付评审', order:['project','test','client','server','sales','pd','h5'], required:['project','sales','test'], deciders:['project'], materials:['交付范围','工期计划','现场条件','验收标准','客户配合事项','风险清单']},
  quality: {name:'质量评审', order:['test','client','server','project','pd','h5','sales'], required:['test','client','server','project'], deciders:['test'], materials:['测试报告','准出标准','异常场景清单','遗留缺陷','回滚方案']},
  retrospective: {name:'复盘评审', order:['project','pd','client','server','test','sales','h5'], required:['pd','project'], deciders:['pd','project'], materials:['原始预测','实际结果','偏差','归因','校准规则']}
};

const NEXT = {
  INIT:['INTAKE'], INTAKE:['PRECHECK'], PRECHECK:['MATERIAL_MISSING','ROLE_MISSING','AGENDA_SET'],
  AGENDA_SET:['ROUND_SPEAK'], ROUND_SPEAK:['ROUND_ASK'], ROUND_ASK:['ROUND_RESPOND'],
  ROUND_RESPOND:['ROUND_CHALLENGE'], ROUND_CHALLENGE:['CONVERGE'], CONVERGE:['DECISION'],
  DECISION:['RECORD'], RECORD:['TRACKING','NEEDS_REVIEW']
};
export function transition(review, next) {
  if (!NEXT[review.state]?.includes(next)) throw new Error(`非法评审状态转换：${review.state} -> ${next}`);
  review.state = next;
  review.state_history.push({state:next, at:new Date().toISOString(), revision:review.revision});
}

function array(value) { return Array.isArray(value) ? value : []; }
function parse(raw) {
  const text = raw.trim().replace(/^```(?:json)?\s*/, '').replace(/\s*```$/, '');
  const value = JSON.parse(text);
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('模型没有返回有效评审对象');
  return value;
}

export async function runReview({request, basePrompt, call, emit, store, signal, limits = REVIEW_LIMITS, messageSource='', repairRoles=false}) {
  const previous = request.review_id ? store.get(request.review_id) : null;
  if (request.review_id && !previous) throw new Error('原评审不存在，请重新启动');
  const roles = normalizeRoles(array(request.roles),request.scene || previous?.scene);
  if (!roles.length) throw new Error('请至少选择一个参会岗位');
  if (previous && request.scene && sceneKey(request.scene) !== sceneKey(previous.scene)) throw new Error('本次评审的业务场景已锁定，请另开新评审切换场景');
  const latestInput = request.change || request.requirement;
  if (typeof latestInput !== 'string' || !latestInput.trim()) throw new Error('请输入本次需求或变更');
  const sameRoles = previous && JSON.stringify(previous.roles.map(r=>r.key).sort()) === JSON.stringify(roles.map(r=>r.key).sort());
  const budget = {...REVIEW_LIMITS,...limits};
  const checkpointSignature=crypto.createHash('sha256').update(JSON.stringify({version:2,source:sourceFingerprint(),input:latestInput,roles,reference_only:Boolean(request.reference_only),scene:request.scene || previous?.scene || '',model:request.model || '',reasoning:request.reasoning || '',learning:previous?.learning_version || 0,assertions:store.revisions,date:new Date().toISOString().slice(0,10),contracts:[REVIEW_CONTRACT,DISCUSSION_CONTRACT,CONVERGENCE_RULES]})).digest('hex');
  if (previous?.closure && previous.artifacts?.score?.decision_status==='reviewed' && previous.inputs.at(-1) === latestInput && sameRoles && !previous.failure && previous.closure.learning_version === previous.learning_version && previous.checkpoint_signature===checkpointSignature) {
    return {...previous,review_id:previous.id,messages:[],messages_streamed:true,duplicate:true};
  }
  const resuming=Boolean(previous && (previous.failure || previous.discussion_complete===false) && previous.checkpoint_signature===checkpointSignature);
  const deadline = AbortSignal.timeout(budget.maxMs);
  const callSignal = signal ? AbortSignal.any([signal,deadline]) : deadline;
  const review = previous ? structuredClone(previous) : {id:crypto.randomUUID(), revision:0, state_history:[], messages:[], raw_outputs:[], inputs:[], predictions:[], execution:[], conditions:[], archives:[]};
  if (previous && !resuming) review.archives.push({revision:review.revision, conclusion:review.conclusion, closure:review.closure, quality:review.quality, challenges:review.challenges, responses:review.responses, conflicts:review.conflicts,import_source:review.import_source});
  if(resuming) {
    review.messages=review.messages.filter(m=>m.revision!==review.revision);
    review.state_history=review.state_history.filter(h=>h.revision!==review.revision);
    review.predictions=review.predictions.filter(p=>p.revision!==review.revision);
    review.conditions=review.conditions.filter(c=>c.revision!==review.revision);
    review.execution=review.execution.filter(e=>e.revision!==review.revision);
    review.learning=(review.learning || []).filter(m=>m.revision!==review.revision || m.status!=='candidate');
  } else review.revision++;
  review.checkpoints=resuming ? review.checkpoints || {} : {};
  review.checkpoint_signature=checkpointSignature;
  review.resumed=resuming;
  review.learning_version ||= 0;
  review.state = 'INIT';
  review.state_history.push({state:'INIT', at:new Date().toISOString(), revision:review.revision});
  review.requirement = previous?.requirement || request.requirement;
  if(!resuming) review.inputs.push(latestInput);
  review.roles = roles;
  review.scene = request.scene || previous?.scene || '';
  review.scene_structure=sceneStructure(sceneKey(review.scene),review.requirement,review.inputs.slice(1));
  review.scene_policy=scenePolicy(review.scene);
  review.question_routing=routeQuestions(review.scene,latestInput,roles);
  review.reassessment_required=false;
  review.effective_scope={status:'pending',revision:review.revision};
  review.effective_requirement='当前有效范围待解析，本轮不放行';
  review.phase_progress=['范围解析','角色立场','关键质询','依据回应','反驳校验','收口决策'].map(name=>({name,status:'pending'}));
  review.no_questions_reason='';
  review.conclusion = null;
  review.closure = null;
  review.failure = null;
  review.local_references=[];
  review.reference_only=Boolean(request.reference_only);
  review.local_scope=null;
  review.import_source=null;
  review.precheck = null;
  review.intake = null;
  review.material_requirements=[];
  review.material_evidence=[];
  review.review_type = null;
  review.agenda = [];
  review.required_roles = roles.map(r=>r.key);
  review.deferred_questions = [];
  review.self_assessment = null;
  review.role_results = [];
  review.role_status = {};
  review.discussion_complete = false;
  review.artifacts = {};
  review.workflow = initialWorkflow();
  review.usage = {calls:0,reused_stages:0, max_calls:budget.maxCalls, max_ms:budget.maxMs, max_questions:budget.maxQuestions};
  review.quality = null;
  review.challenges = [];
  review.responses = [];
  review.conflicts = [];
  review.questions = [];
  review.risks = [];
  const startingMessageCount = review.messages.length;
  const checks = [];
  let inputText = review.inputs.join('\n');
  let allowed = selectAssertions(roles, inputText, review.scene);
  const premiseRecords=()=>[...review.predictions.filter(p=>!p.scope_key||p.scope_key===review.effective_scope.key),...review.conditions.filter(c=>c.status==='通过'&&c.evidence&&(!c.scope_key||c.scope_key===review.effective_scope.key)).map(c=>({id:c.id,feedback:{evidence:c.evidence}}))];
  const memory = store.learning(review.scene, `${review.requirement}\n${latestInput}`);
  const save = kind => store.save(review, kind);
  let pendingCheckpoint;
  const move = next => {
    transition(review,next);
    pendingCheckpoint=null;
    const phase={INTAKE:0,ROUND_SPEAK:1,ROUND_ASK:2,ROUND_RESPOND:3,ROUND_CHALLENGE:4,CONVERGE:5}[next];
    if(phase!==undefined) review.phase_progress.forEach((p,i)=>{p.status=i<phase?'complete':i===phase?'running':'pending';});
    save('state');emit({type:'status',status:next,phases:review.phase_progress,review_id:review.id});
  };
  const add = (role, text, phase, reference) => {
    if (typeof text !== 'string' || !text.trim()) throw new Error('模型发言为空');
    const message = {role, name:roleName(review,role), avatar:roles.find(r=>r.key===role)?.avatar || '会',tag:roles.find(r=>r.key===role)?.tag || '',stance:review.role_results.find(r=>r.role===role)?.stance || '',text, phase, revision:review.revision,...(reference?{reference}:{})};
    if(messageSource&&roles.some(r=>r.key===role)&&!reference)message.source=messageSource;
    review.messages.push(message);
    emit({type:'message', message, review_id:review.id});
    save('message');
  };
  let reusablePrefix=resuming;
  const replayedKeys=new Set();
  const sameVerification=(a,b)=>['condition','verifier','verify_by','verification_method','pass_criteria','fallback'].every(key=>a[key]===b[key]);
  const inheritedVerification=contract=>{
    const latest=review.conditions.findLast(c=>c.condition===contract.condition&&c.scope_key===review.effective_scope.key);
    return latest&&sameVerification(latest,contract)&&latest.status==='通过'&&latest.evidence ? latest : null;
  };
  const acceptStage=()=>{
    if(pendingCheckpoint){review.checkpoints[pendingCheckpoint.key]=pendingCheckpoint.value;pendingCheckpoint=null;save('stage_checkpoint');}
  };
  const ask = async (phase, instruction, targetRole=null, options={}) => {
    callSignal.throwIfAborted();
    const key=`${phase}:${targetRole || ''}`;
    pendingCheckpoint=null;
    if((reusablePrefix || (repairRoles&&resuming&&phase==='ROUND_SPEAK'&&!options.repair))&&review.checkpoints[key]) {replayedKeys.add(key);review.usage.reused_stages++;return structuredClone(review.checkpoints[key].output);}
    if(reusablePrefix) {
      // Keep original valid opinions on either side of a failed role. Any
      // downstream dialogue must be regenerated against the repaired roster.
      review.checkpoints=Object.fromEntries(Object.entries(review.checkpoints).filter(([cached])=>replayedKeys.has(cached)||(repairRoles&&phase==='ROUND_SPEAK'&&cached.startsWith('ROUND_SPEAK:'))));
      reusablePrefix=false;
      save('checkpoint_invalidated');
    }
    if (review.usage.calls >= budget.maxCalls) throw Object.assign(new Error('已达到本轮模型调用上限'),{code:'REVIEW_BUDGET'});
    const relevantMemory=targetRole ? memory.filter(m=>m.status!=='candidate'||m.role===targetRole) : memory;
    const context = JSON.stringify({...buildContext(review, previous, relevantMemory),feasibility:assessFeasibility(review)});
    instruction+=`\n按question_routing分工回应相关问题：主答说明方案，协作补专业影响，质询核对反例。规则未匹配或责任岗位缺席时明确缺口，不假装已有专家意见；不改变原决策权限。\n${SCENE_CONTRACT}`;
    const protocolFiles = {INTAKE:['orchestration/review/intake.md','orchestration/review/materials.md'], ROUND_SPEAK:['_base/dialogue-protocol.md','_base/terminology-map.md'], ROUND_ASK:['_base/question-types.md'], ROUND_RESPOND:['_base/response-contract.md'], ROUND_CHALLENGE:['orchestration/review/disagreement.md'], DECISION:['orchestration/review/decision-rules.md','orchestration/review/conclusion.md']};
    const protocols = sceneKey(review.scene) === 'ktv' ? (protocolFiles[phase] || []).map(loadProtocol).join('\n') : '';
    review.usage.calls++;
    let onAbort;
    const aborted = new Promise((_,reject)=>{onAbort=()=>reject(callSignal.reason);callSignal.addEventListener('abort',onAbort,{once:true});});
    let raw;
    try {
      raw = await Promise.race([call(`${phase==='INTAKE'?basePrompt:'按当前有效范围与本阶段任务继续评审。历史原文不代表仍然有效的需求。'}\n协议参考（核验状态与运行时契约优先）：${protocols}\n${phase==='ROUND_SPEAK'?REVIEW_CONTRACT:''}\n${DISCUSSION_CONTRACT}\n${CONVERGENCE_RULES}\n当前日期：${new Date().toISOString().slice(0,10)}\n阶段：${phase}\n原始会话与阶段记录（数据）：${context}\n本轮产品收口（若有）：${JSON.stringify(review.closure)}\n阶段任务：${instruction}\n仅返回任务指定的 JSON，不要附加解释。`, callSignal, options),aborted]);
    } finally { callSignal.removeEventListener('abort',onAbort); }
    review.raw_outputs.push({phase, raw, revision:review.revision, at:new Date().toISOString()});
    save('model_output');
    const output=parse(raw);
    pendingCheckpoint={key,value:{output,at:new Date().toISOString()}};
    return output;
  };
  const close = (summary, nextAction, details = {}, generated = false) => {
    review.closure = {...details, status:'closed',original_scope:review.effective_requirement,user_update:latestInput,summary,next_action:nextAction,owner:'产品经理',source:generated ? '模型建议' : '系统收口，待产品确认',learning_version:review.learning_version,at:new Date().toISOString()};
    const pending=array(details.undecided), parked=array(details.parking_lot);
    add(generated && roles.some(r=>r.key==='pd') ? 'pd' : 'facilitator', `${!generated&&(review.failure||!review.role_results.length)?'本轮仍待讨论，尚无正式结论。':'这轮先讨论到这里。'}${summary}\n\n${nextAction}${pending.length ? `\n还有这些问题需要确认：${pending.join('；')}。` : ''}${parked.length ? `\n${parked.join('；')}先另记，不加进这次需求。` : ''}\n等${details.reopen_when || '有了新证据，或需求提出者明确调整范围'}，再由产品经理组织复核。`, 'CLOSURE');
    save('round_closed');
  };
  const result = () => ({review_id:review.id, revision:review.revision, state:review.state,reference_only:review.reference_only,local_scope:review.local_scope,phase_progress:review.phase_progress,roles:review.roles, workflow:review.workflow,artifacts:review.artifacts,role_status:review.role_status,discussion_complete:review.discussion_complete,messages_streamed:true, messages:review.messages.slice(startingMessageCount), questions:review.questions || [], risks:review.risks || [], quality:review.quality, conclusion:review.conclusion, closure:review.closure, failure:review.failure, usage:review.usage, learning:review.learning || [], predictions:review.predictions, execution:review.execution, conditions:review.conditions});
  const defer = (role, reason) => {
    if (review.role_status[role]?.status==='thinking'&&review.role_status[role].reason===reason) return;
    review.role_status[role]={status:'thinking',included:false,reason};
    review.role_results=review.role_results.filter(o=>o.role!==role);
    review.responses=review.responses.filter(r=>r.responder!==role);
    const index=checks.findIndex(c=>c.role===role);if(index>=0)checks.splice(index,1);
    review.predictions=review.predictions.filter(p=>p.revision!==review.revision || p.role!==role);
    review.messages.filter(m=>m.revision===review.revision && m.role===role).forEach(m=>m.participation='excluded');
    emit({type:'role_status',review_id:review.id,revision:review.revision,role,status:'thinking'});
    add('facilitator',`${roleName(review,role)}：本轮未形成有效意见。原因：${reason}。保留原始记录，不计入本轮评判。`,'ROLE_STATUS');
  };
  const finish = async () => {
    for (const role of roles) if (!review.role_status[role.key]) {
      if(review.reference_only) review.role_status[role.key]={status:'reference',included:false,reason:'本地岗位模拟；建议可供验证，不计为模型意见或实测证据'};
      else if(review.failure) review.role_status[role.key]={status:'unavailable',included:false,reason:review.failure.message};
      else defer(role.key,'本轮未形成符合纳入条件的意见');
    }
    if((review.reference_only||review.failure)&&review.state!=='CANCELLED') {
      review.local_scope=localScope(review);
      review.local_references=localCrossChecks(review);
      review.question_routing=routeQuestions(review.scene,review.local_scope.input,roles);
      emit({type:'status',status:'LOCAL_REFERENCE',review_id:review.id});
      const interruption=request.reference_only?'按本地案例做一轮岗位讨论，先看方案，再检查反例。':review.failure.http_status===429?'免费接口受限（429），本轮改用本地案例继续分析，不使用付费模型。':'模型本轮未完成，以下用本地案例继续分析。';
      add('facilitator',`${interruption}${review.local_references.length?'':review.local_scope.status==='clarify'?'这次取消后要保留哪些内容、新增什么？请先明确范围。':'没有找到足够相关的案例。请补充具体操作者、当前做法和要改变的步骤。'}`,'LOCAL_REFERENCE');
      if(review.reference_only)review.phase_progress[0].status='reference';
      for(const ref of review.local_references.slice(0,1)) {
        for(const message of localDiscussion(ref,roles,review)) {
          signal?.throwIfAborted();
          if(review.reference_only) {
            const phase=review.phase_progress.find(p=>p.name===message.phase);if(phase)phase.status='reference';
            emit({type:'status',status:'LOCAL_REFERENCE',phases:review.phase_progress,review_id:review.id});
          }
          add(message.role,message.text,'LOCAL_REFERENCE',message.reference);
        }
      }
      if(!review.local_references.length) {
        const lead=roles.find(r=>r.key==='pd') || roles[0];
        const technical=roles.find(r=>['client','server','h5'].includes(r.key)&&r.key!==lead.key);
        const tester=roles.find(r=>r.key==='test'&&r.key!==lead.key);
        const input=review.local_scope.latest;
        add(lead.key,`我先按你这句“${input}”收住范围。${review.local_scope.status==='clarify'?'先明确取消什么、保留什么和新增什么，再估影响。':'目前还缺一个可核对的操作场景：具体谁在什么情况下遇到什么问题，现在怎么处理？'}补充其中最关键的一点，就能继续拆解。`,'LOCAL_REFERENCE');
        if(technical)add(technical.key,'实现成本先看改动落在哪个系统、输入输出是什么、是否涉及外部服务。请给一个从发起到得到结果的例子；系统和依赖未明确前，我不会直接报工期。','LOCAL_REFERENCE');
        if(tester)add(tester.key,'验证先约定正常结果和一个失败反例：什么情况算解决问题，什么情况出现就停止试验？拿原流程作对照；没有匹配案例时，也不把缺资料当成方案一定不可行。','LOCAL_REFERENCE');
        if(review.reference_only) {
          for(const role of roles)if(!review.messages.some(m=>m.revision===review.revision&&m.role===role.key))review.role_status[role.key]={status:'pending_context',included:false,reason:'本轮先澄清范围，尚未形成该岗位的具体方案'};
          for(const phase of review.phase_progress)if(['范围解析','角色立场','关键质询','收口决策'].includes(phase.name))phase.status='reference';
        }
      }
      const initial=assessPreliminary(review);
      const appraisal=initial.comprehensive;
      review.closure={status:'closed',original_scope:initial.input,user_update:latestInput,summary:`${initial.recommendation}。${appraisal.score===null?'综合研判暂缺依据':`已评项综合参考分 ${appraisal.score}/100，覆盖权重${appraisal.coverage}%，尚待实证核验`}；资料准备度（初步验证评分）${initial.score}/100`,next_action:initial.next_action,owner:initial.owner,source:initial.source,in_scope:[initial.input],undecided:initial.gaps,parking_lot:review.closure?.parking_lot || [],reopen_when:'补充验证结果、成本估算或修正需求后',at:new Date().toISOString()};
      add('facilitator',`${review.closure.summary}。\n下一步：${initial.next_action}\n成本拆解、验证方法和停止条件已整理到交付页。补充想法后可以在这里继续讨论。`,'CLOSURE');
      save('round_closed');
    }
    review.discussion_complete=true;
    review.phase_progress.forEach(p=>{if(!['complete','reference'].includes(p.status)) p.status=review.failure?'incomplete':p.status==='running'?'complete':'skipped';});
    review.learning ||= [];
    for(const output of review.role_results.filter(o=>o.stance==='有条件')) for(const condition of array(output.stance_conditions)) {
      if(review.conditions.some(c=>c.revision===review.revision&&c.condition===condition))continue;
      const contract={condition,verifier:roleName(review,output.role),verify_by:'下一轮评审前',verification_method:output.analysis.verification,pass_criteria:condition,fallback:'条件未满足，保留阻塞并重新评审'};
      const old=inheritedVerification(contract);
      review.conditions.push({...contract,id:crypto.randomUUID(),revision:review.revision,scope_key:review.effective_scope.key,source:'岗位附加条件',status:old?'通过':'待验证',...(old?{evidence:old.evidence,inherited_from:old.id}:{})});
    }
    for(const output of review.role_results) {
      const challenges=review.challenges.filter(q=>q.target===output.role || q.asker===output.role);
      review.learning.push({id:crypto.randomUUID(),kind:'观点',role:output.role,text:output.analysis.claim,evidence:output.analysis.basis.map(b=>b.quote).join('；'),counterargument:output.analysis.counterargument,challenge_points:challenges.map(q=>({question:q.question,response:review.responses.find(r=>r.question_id===q.id)?.response || '',acknowledged:q.acknowledgement?.satisfied===true})),topic:review.requirement,scene:review.scene,revision:review.revision,status:'candidate',source:'模型候选观点，仅用于后续反例检查，未经事实核验',at:new Date().toISOString()});
    }
    await deliverReview(review,{save,emit});
    save('review_delivered');
    return result();
  };
  save('started');
  emit({type:'review_started', review_id:review.id,resumed:resuming,revision:review.revision,retained_messages:resuming?review.messages:undefined});
  emit({type:'workflow',review_id:review.id,revision:review.revision,workflow:review.workflow});
  add('human',latestInput,'USER_INPUT');
  try {
    if(request.reference_only) {review.state='LOCAL_REFERENCE';return await finish();}
    move('INTAKE');
    const intake = await ask('INTAKE', `作为主持人分类并核对用户实际提供的材料。配置：${JSON.stringify(REVIEW_TYPES)}。返回 {review_type,urgency,summary,agenda:[最多4个子议题],scope:{active_quotes:[],retired_quotes:[],change_quote},materials:[{name,quote}]}。scope必须区分当前保留/新增的原文片段active_quotes与已撤销的原文片段retired_quotes；change_quote逐字复制latest_input。取消或替换后只保留仍有效的原文，不把被否定的功能当需求。active_quotes不能包含retired_quotes；保留不受影响的原有约束。review_type用英文key：requirement/solution/delivery/quality/retrospective。材料quote逐字摘自当前有效原文，未提供则为空，不得用模型建议补充为事实。`);
    const typeKey=Object.hasOwn(REVIEW_TYPES,intake.review_type) ? intake.review_type : Object.keys(REVIEW_TYPES).find(key=>REVIEW_TYPES[key].name===intake.review_type);
    const type = REVIEW_TYPES[typeKey];
    if (!type) throw new Error('评审类型无效');
    review.review_type = typeKey;
    review.required_roles = type.required;
    review.material_requirements=type.materials;
    review.intake = intake;
    resolveScope(review,intake.scope,previous);
    inputText=scopeText(review);
    review.question_routing=routeQuestions(review.scene,inputText,roles);
    allowed=selectAssertions(roles,inputText,review.scene);
    review.scene_structure.current_scope=review.effective_scope;
    acceptStage();
    review.agenda = array(intake.agenda).slice(0,4);
    move('PRECHECK');
    const materials = array(intake.materials).map(m=>({...m,source:'model_quote'}));
    // Explicitly labelled input can be located without trusting a model's altered quotation.
    for(const name of type.materials) if(!materials.some(m=>m.name===name&&typeof m.quote==='string'&&m.quote.trim()&&inputText.includes(m.quote))) {
      const match=inputText.match(new RegExp(`${name}[：:][^。\\n]+[。]?`));
      if(match) materials.push({name,quote:match[0],source:'user_labeled_input'});
    }
    review.material_evidence=materials.filter(m=>typeof m.quote==='string'&&m.quote.trim()&&inputText.includes(m.quote));
    review.scene_structure.known_facts=review.material_evidence.map(m=>({name:m.name,quote:m.quote,status:'输入前提，未独立核验'}));
    const missing = type.materials.filter(name => !materials.some(m => m?.name === name && typeof m.quote === 'string' && m.quote.trim() && inputText.includes(m.quote)));
    const missingRoles = type.required.filter(key => !roles.some(r => r.key === key));
    if (typeKey === 'delivery' && !roles.some(r => ['client','server'].includes(r.key))) missingRoles.push('client/server');
    review.precheck = {missing_materials:missing, missing_roles:missingRoles, passed:!missing.length && !missingRoles.length};
    review.scene_structure.open_questions=missing;
    if ((missing.length || missingRoles.length) && request.exploratory!==true) {
      move(missingRoles.length ? 'ROLE_MISSING' : 'MATERIAL_MISSING');
      add('facilitator', `${type.name}暂未进入正式评审。\n${missing.length ? `待补材料：${missing.join('、')}。\n` : ''}${missingRoles.length ? `需参会岗位：${missingRoles.map(k => ROLE_NAMES[k] || k).join('、')}。\n` : ''}请在当前对话中补充，已有内容会保留。`, 'PRECHECK');
      review.questions = missing.map(text => ({text:`请补充${text}`, owner:'材料提交方', category:'pd', level:'high'}));
      review.quality = {valid:false, decision_ready:false, errors:['前置检查未通过'], warnings:[], scope:'材料引用和角色完整性检查，不代表材料真实性核验'};
      close('材料或岗位不足，本轮暂缓；已有需求不扩展，不继续循环追问。',`产品经理汇总并补齐${missing.length ? missing.join('、') : '必要参会岗位'}后重新评审。`,{undecided:missing,parking_lot:[],reopen_when:'缺失材料或必要岗位已补齐'});
      save('precheck_blocked');
      return await finish();
    }
    if(missing.length || missingRoles.length) add('facilitator',`本轮先做探索讨论，不能放行。待补材料：${missing.join('、') || '无'}；未参会必要岗位：${missingRoles.map(k=>roleName(review,k)).join('、') || '无'}。各角色只能基于现有原文提出假设、反例和验证，不编造缺失事实。`,'PRECHECK');
    if (!review.agenda.length) review.agenda = [review.requirement];
    move('AGENDA_SET');
    add('facilitator', `${type.name}议程：${review.agenda.join('；')}。\n按专业发言、质询、回应、挑战确认及决策建议推进；新增意见会单独记录。`, 'AGENDA_SET');
    move('ROUND_SPEAK');
    const order = [...type.order.filter(key => roles.some(r => r.key === key)), ...roles.map(r => r.key).filter(key => !type.order.includes(key))];
    const speak = async (role, options={}) => {
      let output,check;
      try {
        output = await ask('ROUND_SPEAK', `${loadRoleSkill(role, review.scene)}\n${rolePrompt(roles.find(r=>r.key===role))}\n仅以 ${roleName(review,role)}(${role}) 发言。先回应前序角色的关键判断，只补充本专业新增信息、不同观点或反例，不重复附和；超出本次边界的想法标为后续议题，不推入本次方案。返回 {role:"${role}",text,stance,stance_reason,stance_conditions:[],analysis:{stakeholder,claim,principle,reasoning,counterargument,boundary,verification,basis:[]},risks:[{text,level,impact,impact_tag,mitigation,evidence_quote}],deliverables:{business_flow:[],functional_rules:[],exception_handling:[],operations:[],handover:[],acceptance:[]},references:[],evidence_gap,alternatives:[],predictions:[],prediction_gap,handoff:{to_role,judgment,open_questions:[],acceptance}}。deliverables只提供本专业且属于当前需求的建议，每条为{text,scope_quote}，scope_quote逐字引用有效范围；无依据返回空数组。impact_tag为阻塞/待澄清/建议；正文自然说明具体对象、立场与必要理由，不要固定五段式，不强制两个方案。后台analysis必须保留前提、反例与验证；没有基线不强行预测数值，不输出其他角色发言。`,role,options);
        check = validateDiscussionOutput(output, role, allowed, store.revisions,inputText,premiseRecords());
      } catch (error) {
        defer(role,error.message);
        if (callSignal.aborted || ['REVIEW_BUDGET','FREE_CIRCUIT_OPEN'].includes(error.code) || [401,402,403,429].includes(error.status)) throw error;
        return;
      }
      if (!check.eligible) {defer(role,check.exclusion_reasons.join('；'));return;}
      acceptStage();
      checks.push({role,...check});
      review.role_results.push(output);
      review.role_status[role]={status:'included',included:true};
      add(role, output.text, 'ROUND_SPEAK');
      if (check.valid) for (const p of array(output.predictions)) review.predictions.push({...p, id:crypto.randomUUID(), role, revision:review.revision,scope_key:review.effective_scope.key, status:'待回填'});
    };
    for (const role of order) await speak(role);
    if(repairRoles) {
      const failedRoles=order.filter(role=>!review.role_status[role]?.included);
      if(failedRoles.length) {
        const reasons=Object.fromEntries(failedRoles.map(role=>[role,review.role_status[role]?.reason]));
        emit({type:'status',status:'repairing_roles',roles:failedRoles,review_id:review.id});
        add('facilitator',`${failedRoles.map(role=>roleName(review,role)).join('、')}的回复还有缺项，我会请这些岗位补答一次。其他岗位的有效发言保留，补齐后继续相互质询。`,'ROLE_REPAIR');
        for(const role of failedRoles) await speak(role,{repair:true,failedRoles,reasons});
        const unresolved=failedRoles.filter(role=>!review.role_status[role]?.included);
        if(unresolved.length) throw new Error(`${unresolved.map(role=>roleName(review,role)).join('、')}补答仍未形成有效意见，已保留其余岗位发言，请重试讨论继续补答`);
      }
    }
    let includedOrder=review.role_results.map(o=>o.role);
    if (!includedOrder.length) {
      review.quality={valid:false,decision_ready:false,errors:[],warnings:['暂无可纳入的专业意见'],roles:[],scope:'依据不足的回复已隔离，不参与评判'};
      close('本轮没有可纳入的专业意见，不作放行；不据此认定功能不可行。','产品经理补齐需求前提与验证材料后重新评审。',{undecided:['专业意见覆盖与可追溯依据尚未齐备'],parking_lot:[]});
      review.state='NEEDS_REVIEW';
      return await finish();
    }
    move('ROUND_ASK');
    const questionOutput = includedOrder.length>1 ? await ask('ROUND_ASK', `仅允许已纳入岗位 ${includedOrder.join(',')} 参与，只提出阻塞本轮决策的关键问题，按重要性排序，全体合计最多${budget.maxQuestions}个，每人最多2个；没有新信息返回空数组和具体no_questions_reason，不要求人人发问。返回 {questions:[{id,asker,target,type,question,basis}],no_questions_reason}。asker/target 用上述岗位key，不能相同；type 为 澄清/挑战/补充/验证，basis 指出具体判断或证据缺口，id 唯一。`) : {questions:[],no_questions_reason:'只有一个有效岗位，无法完成跨角色质询'};
    review.no_questions_reason=typeof questionOutput.no_questions_reason==='string'&&questionOutput.no_questions_reason.trim().length>=6&&includedOrder.length>1 ? questionOutput.no_questions_reason : '';
    const counts = {}, ids = new Set(), texts = new Set();
    review.deferred_questions = [];
    for (const q of array(questionOutput.questions)) {
      if (typeof q?.question === 'string' && texts.has(q.question.trim())) continue;
      if (review.challenges.length >= budget.maxQuestions || (counts[q?.asker] || 0) >= 2) { review.deferred_questions.push(q); continue; }
      if (!q || !includedOrder.includes(q.asker) || !includedOrder.includes(q.target) || q.asker === q.target || !['澄清','挑战','补充','验证'].includes(q.type) || !q.question || !q.basis || !q.id || ids.has(q.id)) continue;
      ids.add(q.id); texts.add(q.question.trim()); counts[q.asker] = (counts[q.asker] || 0) + 1;
      review.challenges.push(q);
      add(q.asker, `【${q.type} → ${ROLE_NAMES[q.target] || q.target}】${q.question}\n依据：${q.basis}`, 'ROUND_ASK');
    }
    if(request.audited_phases&&requiresChallenge(review)&&!review.challenges.length)throw new Error('本轮仍有材料缺口、有条件意见或风险，必须完成针对实际观点的关键质询');
    acceptStage();
    move('ROUND_RESPOND');
    const responseOutput = review.challenges.length ? await ask('ROUND_RESPOND', '逐条由被质询角色回应全部问题。返回 {responses:[{question_id,responder,stakeholder,response,basis:[{kind,quote,source_id}],revised,revision}]}。stakeholder必须为具体对象，response告知该视角，basis遵循原文前提契约；给出依据支持的回应，不把模型前序发言当独立证据；修正只新增，不抹去原发言。') : {responses:[]};
    for (const q of review.challenges) {
      const matches = array(responseOutput.responses).filter(r => r?.question_id === q.id);
      const response = matches[0];
      if (review.role_status[q.target]?.status!=='included' || matches.length !== 1 || response.responder !== q.target || typeof response.response !== 'string' || typeof response.stakeholder !== 'string' || response.stakeholder.length<3 || /^(用户|客户|商户|消费者|大家|我们)$/.test(response.stakeholder) || !response.response.includes(response.stakeholder) || !array(response.basis).length || !response.basis.every(b=>validPremise(b,allowed,store.revisions,inputText,premiseRecords()))) {
        q.acknowledgement={satisfied:false,reason:'未取得可纳入回应'};defer(q.target,'回应缺少正确角色、具体对象或可追溯依据');continue;
      }
      review.responses.push(response);
      add(response.responder, `【回应 ${q.id}】${response.response}`, 'ROUND_RESPOND');
    }
    if(review.responses.length===review.challenges.length) acceptStage();
    move('ROUND_CHALLENGE');
    const challengeOutput = review.responses.length ? await ask('ROUND_CHALLENGE', '只对已纳入的responses由仍参与的原提问方确认回应；确认只表示已理解，不代表证据已经实测。返回 {acknowledgements:[{question_id,asker,satisfied,reason,alternative}],conflicts:[{id,type,parties:[],topic,a_position,b_position,evidence,escalation_level,resolution,decider,minority_opinion,review_trigger}]}。不满意必须给替代方案并关联 question_id；分歧type为事实/判断/优先级/责任，升级1-5级，不能编造共识。未解决则保留分歧，本轮不再循环提问。') : {acknowledgements:[],conflicts:[]};
    for (const q of review.challenges) {
      const ack = array(challengeOutput.acknowledgements).find(a => a?.question_id === q.id && a.asker === q.asker);
      if (review.role_status[q.asker]?.status!=='included' || review.role_status[q.target]?.status!=='included' || !ack || typeof ack.satisfied !== 'boolean' || !ack.reason || (!ack.satisfied && !ack.alternative)) {q.acknowledgement={satisfied:false,reason:'未取得有效确认，保留未决'};continue;}
      q.acknowledgement = ack;
      add(q.asker, `【${ack.satisfied ? '确认回应' : '保留挑战'} ${q.id}】${ack.reason}${ack.alternative ? `\n替代方案：${ack.alternative}` : ''}`, 'ROUND_CHALLENGE');
    }
    review.conflicts = array(challengeOutput.conflicts);
    includedOrder=review.role_results.map(o=>o.role);
    if (review.conflicts.some(c => !c || !['事实','判断','优先级','责任'].includes(c.type) || !Array.isArray(c.parties) || c.parties.length < 2 || c.parties.some(p => !order.includes(p)) || !Number.isInteger(c.escalation_level) || c.escalation_level < 1 || c.escalation_level > 5 || !c.topic)) throw new Error('分歧结构无效');
    acceptStage();
    move('CONVERGE');
    const closure = await ask('CONVERGE', '由产品经理守住原始需求及用户明确变更的边界，给本轮收口建议，不取代专业决策。不论有无共识都停止讨论，返回 {summary,in_scope:[],parking_lot:[],undecided:[],next_action,owner,reopen_when,opinion_checks:[{role,consistent,evidence_supported,scope_respected,reason}]}。必须逐一审查admitted_opinions的正文text：与analysis立场是否一致、事实声称是否有对应依据、是否遵守当前有效范围。三个检查字段只能为布尔值，reason写出具体核对理由；不得因结构字段齐全就认为正文正确。不支持的实测/授权/上线声明、撤销要求复活、借用无关证据均为false。此检查只是语义复核，不是外部事实认证。in_scope仅本轮需求；parking_lot为跑题或待用户批准的扩展；undecided列缺证据/未决事项；next_action指定负责人及最小验证动作，reopen_when明确什么新证据到来再讨论。不得编造已解决。');
    if (typeof closure.summary !== 'string' || !closure.summary.trim() || typeof closure.next_action !== 'string' || !closure.next_action.trim() || typeof closure.reopen_when !== 'string' || !closure.reopen_when.trim() || ['in_scope','parking_lot','undecided'].some(k=>!Array.isArray(closure[k]) || closure[k].some(x=>typeof x !== 'string'))) throw new Error('产品收口缺少范围、未决事项或最小下一步');
    if(request.audited_phases) for(const opinion of review.role_results) {
      const audits=array(closure.opinion_checks).filter(a=>a.role===opinion.role),audit=audits[0];
      if(audits.length!==1||typeof audit.claim_quote!=='string'||audit.claim_quote.trim().length<6||!opinion.text.includes(audit.claim_quote)||!array(opinion.analysis?.basis).some(b=>b.quote===audit.basis_quote))throw new Error(`${opinion.role}复核缺少对应的正文与前提原文，不能据此收口`);
    }
    acceptStage();
    closure.undecided = [...new Set([...closure.undecided,...review.deferred_questions.map(q=>q?.question).filter(q=>typeof q==='string')])];
    close(closure.summary,closure.next_action,closure,true);
    move('DECISION');
    if (!type.deciders.some(role=>includedOrder.includes(role))) throw new Error('决策岗位尚无可纳入的专业意见，本轮不形成放行建议');
    const decision = await ask('DECISION', `仅由 ${type.deciders.filter(r=>includedOrder.includes(r)).join('+')} 给出决策建议，主持人不得代决策。只能采用已纳入岗位${includedOrder.join(',')}的依据，跳过岗位不参与投票也不打零分；不得用模型互相同意自证。遵循产品本轮收口，parking_lot不能进入执行项，不再开启新议题。返回 {deciders:[],basis_roles:[],decision,summary,reason,consensus:[],minority_opinions:[],conditions:[{condition,verifier,verify_by,verification_method,pass_criteria,fallback}],execution:[{item,owner,deadline,deliverable,scope_quote}],questions:[{text,level,category,owner}],risks:[{text,level,category,owner}],review_at,next_action}。basis_roles明确引用已纳入意见的岗位key，reason说明对应的原文前提与推导；scope_quote逐字引用用户需求证明执行项依据。decision只能是通过/有条件通过/不通过/延期；缺依据不得通过；有条件通过必须列明确条件。所有时间用ISO日期。`);
    if (!Array.isArray(decision.deciders) || !decision.deciders.length || decision.deciders.some(r => !type.deciders.includes(r) || !includedOrder.includes(r)) || (typeKey === 'retrospective' && type.deciders.some(r => !decision.deciders.includes(r)))) throw new Error('决策角色越权或缺席');
    if (!['通过','有条件通过','不通过','延期'].includes(decision.decision) || !decision.summary || !decision.reason || !decision.next_action || !Number.isFinite(Date.parse(decision.review_at))) throw new Error('决策结论不完整');
    const conditionErrors = [];
    for(const opinion of review.role_results) {
      const audits=array(closure.opinion_checks).filter(item=>item.role===opinion.role);
      if(audits.length!==1||!['consistent','evidence_supported','scope_respected'].every(key=>audits[0][key]===true)||typeof audits[0].reason!=='string'||audits[0].reason.trim().length<6) conditionErrors.push(`${opinion.role}正文与依据语义复核缺失或未通过`);
    }
    const today=new Date().toISOString().slice(0,10);
    const validDeadline=value=>Number.isFinite(Date.parse(value))&&new Date(value).toISOString().slice(0,10)>=today;
    if(!validDeadline(decision.review_at))conditionErrors.push('复核时间已经过期，需给出可执行的新时间');
    if (!array(decision.basis_roles).length || array(decision.basis_roles).some(role=>!includedOrder.includes(role))) conditionErrors.push('决策未明确引用可纳入的专业意见');
    if(!review.precheck.passed) conditionErrors.push('材料或必要参会岗位不足，探索意见不能作为放行依据');
    if (type.required.some(role=>!includedOrder.includes(role))) conditionErrors.push('必要专业覆盖未齐备；未纳入岗位不计为反对意见');
    if (decision.decision === '有条件通过' && !array(decision.conditions).length) conditionErrors.push('有条件通过缺少验证条件');
    if (array(decision.conditions).some(c => !c.condition || !c.verifier || !Number.isFinite(Date.parse(c.verify_by)) || !c.verification_method || !c.pass_criteria || !c.fallback)) conditionErrors.push('附加条件不可验证');
    if (!array(decision.execution).length || array(decision.execution).some(e => !e.item || !e.owner || !Number.isFinite(Date.parse(e.deadline)) || !e.deliverable)) conditionErrors.push('执行项缺责任人、期限或交付物');
    if (review.challenges.some(q => !q.acknowledgement.satisfied)) conditionErrors.push('仍有未解决质询，需要裁决或外部复核');
    if (review.deferred_questions.length) conditionErrors.push('超出本轮质询上限的问题已留待后续验证');
    if (decision.decision==='通过' && array(review.closure?.undecided).length) conditionErrors.push('仍有未决事项，不能直接放行');
    if (array(decision.execution).some(e=>typeof e.scope_quote !== 'string' || !e.scope_quote.trim() || !inputText.includes(e.scope_quote))) conditionErrors.push('执行项缺少本轮用户需求原文依据，须由产品核对范围');
    if(array(decision.execution).some(e=>!validDeadline(e.deadline))||array(decision.conditions).some(c=>!validDeadline(c.verify_by)))conditionErrors.push('执行或验证期限无效或已过期');
    const sceneAssessment=assessScene({...review,conclusion:decision});
    if(!sceneAssessment.passed) conditionErrors.push(...sceneAssessment.checks.filter(c=>!c.passed).map(c=>`${c.label}：${c.reason}`),...(sceneAssessment.error?[sceneAssessment.error]:[]));
    const errors = [...checks.flatMap(c => c.errors.map(e => `${c.role}: ${e}`)), ...conditionErrors];
    const warnings = checks.flatMap(c => c.warnings);
    review.quality = {valid:!errors.length, decision_ready:!errors.length && checks.length>0, errors, warnings, roles:checks, scope:'根据原文前提检查设计意见与准入条件；不是实测或专业质量认证'};
    review.conclusion = decision;
    review.conditions.push(...array(decision.conditions).map(c => {
      const verified=inheritedVerification(c);
      return {...c,id:crypto.randomUUID(),revision:review.revision,scope_key:review.effective_scope.key,status:verified?'通过':'待验证',...(verified?{evidence:verified.evidence,inherited_from:verified.id}:{})};
    }));
    review.execution.push(...array(decision.execution).map(e => ({...e,id:crypto.randomUUID(),revision:review.revision,status:'待开始'})));
    review.questions = array(decision.questions);
    review.risks = array(decision.risks);
    acceptStage();
    if (review.quality.decision_ready) add(decision.deciders[0], `【决策建议：${decision.decision}】${decision.summary}\n依据：${decision.reason}\n下一步：${decision.next_action}`, 'DECISION');
    else add('facilitator', '本轮准入条件未满足，评审不通过。原始建议已归档供核对，不作为放行依据；后续交付将列明缺口与补证任务。', 'QUALITY_GATE');
    move('RECORD');
    move(review.quality.decision_ready ? 'TRACKING' : 'NEEDS_REVIEW');
    review.self_assessment = {included_roles:checks.length,skipped_roles:roles.length-checks.length,scope:'只记录覆盖情况，不作模型自评分'};
    save('review_record');
    return await finish();
  } catch (error) {
    review.failure = {stage:review.state, message:error.message, code:error.code || null,http_status:error.status || null, rate_limit_source:error.rate_limit_source || null,retry_after_seconds:error.retry_after_seconds ?? null,remaining:error.remaining ?? null,required_requests:error.required_requests ?? null,reset_at:error.reset_at || null,at:new Date().toISOString(), action:'在当前对话补充或重试，保留已完成阶段和原始输出'};
    review.state = error.code==='LOCAL_REFERENCE'?'LOCAL_REFERENCE':deadline.aborted || error.code === 'REVIEW_BUDGET' ? 'BUDGET_EXHAUSTED' : signal?.aborted ? 'CANCELLED' : 'FAILED';
    review.quality = {valid:false,decision_ready:false,errors:[error.message],warnings:[],scope:'本轮未完整完成，保留原始输出，不作为放行依据'};
    review.state_history.push({state:review.state, at:new Date().toISOString(), revision:review.revision});
    save('failure');
    if(review.state==='CANCELLED')close('本轮已按停止操作中止，已产生的原始记录保留。','产品经理核对已有意见与未决事项后再决定是否继续。',{undecided:['本轮讨论尚未完成'],parking_lot:review.closure?.parking_lot || [],reopen_when:'需求提出者重新发起讨论'});
    return await finish();
  }
}
