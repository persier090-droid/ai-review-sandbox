import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import {manualReply} from '../tests/manual-fixture.mjs';

const require=createRequire(import.meta.url);
let playwright;
try{playwright=require('playwright');}catch{playwright=require(process.env.PLAYWRIGHT_MODULE || '/Users/sun/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');}
const root=fileURLToPath(new URL('../',import.meta.url));
const data=fs.mkdtempSync(path.join(os.tmpdir(),'automatic-browser-'));
let app,browser,calls=0,fail=true,roleFault='once',quotaRemaining=50;
const roleCalls=new Map();
const prompts=[],errors=[];
const upstream=http.createServer(async(req,res)=>{
  try {
    if(req.method==='GET'&&req.url==='/key'){res.writeHead(200,{'content-type':'application/json'});res.end(JSON.stringify({data:{free_model_daily_requests:{used:50-quotaRemaining,limit:50,remaining:quotaRemaining}}}));return;}
    let raw='';for await(const chunk of req)raw+=chunk;
    const body=JSON.parse(raw);calls++;
    assert.deepEqual(body.provider.max_price,{prompt:0,completion:0,request:0,image:0});
    assert.equal(body.model,'openrouter/free');assert.equal(body.max_tokens,8192);
    assert.equal(body.provider.require_parameters,true);assert.equal(body.response_format.type,'json_schema');
    const prompt=body.messages.at(-1).content;prompts.push(prompt);
    if(fail){fail=false;res.writeHead(429,{'content-type':'application/json'});res.end(JSON.stringify({error:{message:'fixture platform quota'}}));return;}
    const context=JSON.parse(prompt.split('## 材料与上下文（数据）\n')[1].split('\n')[0]);
    const template=JSON.parse(prompt.split('## 返回结构\n')[1]);
    const output=manualReply({id:template.package_id,request:{requirement:context.original_requirement,change:context.latest_input,roles:context.roles}});
    output.stages=output.stages.filter(s=>template.stages.some(w=>w.phase===s.phase&&w.role===s.role));
    for(const stage of [...output.stages])if(stage.phase==='ROUND_SPEAK') {
      roleCalls.set(stage.role,(roleCalls.get(stage.role) || 0)+1);
      if(roleFault==='persistent'||(roleFault==='once'&&roleCalls.get(stage.role)===1)) {
        if(stage.role==='test')stage.output.text='建议完成测试后，再推进交付。';
        if(stage.role==='project')output.stages.push(structuredClone(stage));
      }
    }
    res.writeHead(200,{'content-type':'text/event-stream'});
    res.end('data: '+JSON.stringify({choices:[{delta:{content:JSON.stringify(output)}}]})+'\n\ndata: [DONE]\n\n');
  }catch(error){errors.push(error.message);res.writeHead(500);res.end();}
});
try {
  await new Promise(r=>upstream.listen(0,'127.0.0.1',r));
  const reserve=http.createServer();await new Promise(r=>reserve.listen(0,'127.0.0.1',r));
  const port=reserve.address().port;await new Promise(r=>reserve.close(r));
  const origin=`http://127.0.0.1:${port}`;
  app=spawn(process.execPath,['server.mjs'],{cwd:root,env:{...process.env,PORT:String(port),AI_PROVIDER:'openrouter',REVIEW_TRANSPORT:'single',OPENROUTER_API_KEY:'fixture-only',OPENROUTER_MODEL:'openrouter/free',OPENROUTER_URL:`http://127.0.0.1:${upstream.address().port}`,REVIEW_DATA_DIR:data},stdio:['ignore','pipe','pipe']});
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('startup timeout')),5000);app.stdout.on('data',d=>{if(String(d).includes('AI review server')){clearTimeout(timer);resolve();}});app.once('exit',code=>{clearTimeout(timer);reject(Error('startup exit '+code));});});
  browser=await playwright.chromium.launch({headless:true,...(process.platform==='darwin'?{executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'}:{})});
  const page=await browser.newPage({viewport:{width:1440,height:1000}});
  page.on('pageerror',e=>errors.push(e.message));
  await page.goto(origin+'/?mode=ai');await page.locator('#runMode').selectOption('ai');
  const statuses=await page.evaluate(()=>{
    const review={artifacts:{score:{verdict:'通过'}},workflow:{chat:'complete',score:'complete',risk:'running',todo:'locked',prd:'locked'}};
    const partial=reviewStatusText(review);
    review.workflow={chat:'complete',score:'complete',risk:'complete',todo:'complete',prd:'running'};
    const finalizing=reviewStatusText(review);
    review.workflow.prd='complete';
    return [partial,finalizing,reviewStatusText(review)];
  });
  assert.deepEqual(statuses,['正在生成风险看板','正在生成交付文档','本轮通过 · 交付已完成']);
  await page.locator('#interveneBtn').click();
  await page.locator('#statusTag').filter({hasText:'初评完成 · 正式放行待复核'}).waitFor({timeout:45000});
  assert.equal(calls,1);
  const id=await page.evaluate(()=>sessionStorage.getItem('ktv-review-id'));
  await page.getByRole('button',{name:'重试讨论',exact:true}).click();
  await page.locator('#statusTag').filter({hasText:'交付已完成'}).waitFor({timeout:45000});
  let record=await(await fetch(origin+'/api/reviews/'+id)).json();
  assert.equal(calls,11);assert.equal(record.role_results.length,9);
  assert.equal(record.usage.remote_calls,10);assert.equal(record.import_source.kind,'automatic_free');
  assert.match(await page.locator('#chatBox').innerText(),/补答一次/);
  assert.ok(record.phase_progress.every(p=>p.status==='complete'));
  assert.match(await page.locator('#chatBox').innerText(),/模型模拟多岗位/);
  for(const stage of ['score','risk','todo','prd'])assert.equal(await page.locator(`[data-tab="${stage}"]`).isDisabled(),false);
  assert.doesNotMatch(await page.locator('#docContent').innerText(),/人工导入/);
  await page.reload();await page.locator('#statusTag').filter({hasText:'交付已完成'}).waitFor();
  assert.equal(await page.locator('#runMode').inputValue(),'ai');
  roleFault='persistent';
  await page.locator('#reqInput').fill('补充验证要求：消费者关闭舞蹈后能继续点歌，记录操作结果');
  await page.locator('#interveneBtn').click();
  await page.locator('#statusTag').filter({hasText:'初评完成 · 正式放行待复核'}).waitFor({timeout:45000});
  record=await(await fetch(origin+'/api/reviews/'+id)).json();
  assert.equal(calls,16);assert.equal(record.role_results.length,7);assert.equal(record.artifacts.score.score,null);
  const retained=record.role_results;
  roleFault='none';
  await page.getByRole('button',{name:'重试讨论',exact:true}).click();
  await page.locator('#statusTag').filter({hasText:'交付已完成'}).waitFor({timeout:45000});
  record=await(await fetch(origin+'/api/reviews/'+id)).json();
  assert.equal(calls,22);assert.equal(record.revision,2);assert.equal(record.usage.remote_calls,6);
  assert.equal(record.role_results.length,9);
  for(const opinion of retained)assert.deepEqual(record.role_results.find(r=>r.role===opinion.role),opinion);
  assert.equal(record.messages.filter(m=>m.revision===2&&m.phase==='ROUND_SPEAK').length,9);
  assert.ok(prompts.at(-1).includes('同意先在终端验证'));
  assert.ok(record.inputs.at(-1).includes('补充验证要求'));
  assert.equal(await page.locator('#manualDialog').isVisible(),false);
  await page.screenshot({path:'/tmp/automatic-review-desktop.png',fullPage:true});
  await page.setViewportSize({width:390,height:844});
  assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
  await page.screenshot({path:'/tmp/automatic-review-mobile.png',fullPage:true});
  quotaRemaining=1;
  await page.locator('#runMode').selectOption('manual');
  assert.equal(await page.locator('#manualDialog').isVisible(),false,'choosing a mode must not submit or open a dialog');
  await page.locator('#runMode').selectOption('ai');
  await page.waitForFunction(()=>document.querySelector('#modelAvailabilityText').textContent.includes('1/50'));
  const beforeQuota=calls;
  await page.locator('#reqInput').fill('补充要求：关闭展示后保留当前播放队列，不增加其他功能');
  await page.locator('#interveneBtn').click();
  await page.locator('#statusTag').filter({hasText:'初评完成 · 正式放行待复核'}).waitFor({timeout:45000});
  assert.equal(calls,beforeQuota,'insufficient daily quota must not consume another generation');
  record=await(await fetch(origin+'/api/reviews/'+id)).json();assert.equal(record.failure.code,'FREE_QUOTA_INSUFFICIENT');assert.equal(record.usage.upstream.attempts,0);
  const preservedInput=await page.locator('#reqInput').inputValue();
  await page.locator('#runMode').selectOption('manual');
  assert.equal(await page.locator('#manualDialog').isVisible(),false);
  assert.equal(await page.locator('#reqInput').inputValue(),preservedInput);
  assert.equal(await page.locator('#refreshModelStatus, #continueInBrowser').count(),0);
  await page.getByRole('button',{name:'打开网页协作',exact:true}).click();await page.waitForSelector('#manualDialog[open]');
  const packageId=await page.evaluate(()=>sessionStorage.getItem('ktv-manual-package'));
  const bundle=await(await fetch(origin+'/api/manual/'+packageId)).json();
  assert.equal(bundle.request.review_id,id);assert.match(bundle.request.change,/保留当前播放队列/);
  await page.locator('#manualReply').fill(JSON.stringify(manualReply(bundle)));await page.locator('#manualImport').click();
  await page.locator('#statusTag').filter({hasText:'交付已完成'}).waitFor({timeout:45000});
  assert.equal(calls,beforeQuota,'web collaboration must not call the exhausted API');
  for(const stage of ['score','risk','todo','prd'])assert.equal(await page.locator(`[data-tab="${stage}"]`).isDisabled(),false);
  assert.deepEqual(errors,[]);
  console.log('分批AI操作校验通过：429后重试、岗位补答及断点续跑、额度预检零生成、原上下文转网页协作后完成四项交付。隔离上游，不代表真实服务可用性。');
}finally {
  if(browser)await browser.close();
  if(app&&app.exitCode===null){app.kill();await new Promise(r=>app.once('exit',r));}
  await new Promise(r=>upstream.close(r));fs.rmSync(data,{recursive:true,force:true});
}
