import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {createSkillLibrary} from './skill-library.mjs';
import {ASSERTIONS,PRACTICE_REFERENCES,REVIEW_CONTRACT,validateDiscussionOutput,validateRoleOutput,loadRoleSkill,roleCapabilities,selectAssertions,validPremise} from './expert-skills.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import {reviewMethodReferences} from './review-delivery.mjs';

test('role skills actually inherit common methods once per model batch',()=>{
  const standalone=loadRoleSkill('pd','ktv');
  assert.match(standalone,/资料不足时仍给可执行建议/);
  assert.match(standalone,/一次性投入/);
  const batch=roleCapabilities(ROLE_PERSONAS,'ktv');
  assert.equal(batch.length,9);
  assert.equal(batch.map(r=>r.skill).join('\n').split('# KTV 实务评审方法').length-1,1);
  for(const r of batch){assert.ok(r.skill_documents.length);assert.match(r.skill,/实操步骤/);}
  assert.doesNotMatch(roleCapabilities(ROLE_PERSONAS,'saas').map(r=>r.skill).join('\n'),/# KTV 实务评审方法/);
});

test('skill inheritance rejects cycles, missing documents and escaped paths',t=>{
  const root=fs.mkdtempSync(path.join(os.tmpdir(),'skill-loader-'));t.after(()=>fs.rmSync(root,{recursive:true,force:true}));
  fs.writeFileSync(path.join(root,'a.md'),'A');fs.writeFileSync(path.join(root,'b.md'),'B');
  const m={roles:{pd:'a.md'},documents:{'a.md':{inherits:['b.md']},'b.md':{inherits:['a.md']}}};
  assert.throws(()=>createSkillLibrary(root,m).read('pd'),/循环/);
  assert.throws(()=>createSkillLibrary(root,{roles:{pd:'missing.md'},documents:{'missing.md':{}}}).read('pd'),/不存在/);
  assert.throws(()=>createSkillLibrary(root,{roles:{pd:'../outside.md'},documents:{'../outside.md':{}}}).read('pd'),/路径/);
});

test('checked methods are topic matched and never substitute for project observations',()=>{
  const refs=selectAssertions([{key:'server'}],'合唱邀请重复提交和接口重试','ktv');
  const method=refs.find(r=>r.evidence_scope==='method_only');
  assert.ok(method);assert.equal(method.status,'verified');assert.match(method.source_url,/aws.amazon.com/);
  assert.equal(validPremise({kind:'verified_assertion',quote:method.assertion,source_id:method.id},refs,{},'包厢邀请合唱'),false);
  assert.deepEqual(selectAssertions([{key:'server'}],'合唱邀请重复提交','saas'),[]);
  assert.ok(!selectAssertions([{key:'sales'}],'门店回本和竞品市场占有率','ktv').some(a=>a.id==='sales-competitor-002'));
});

test('delivery references preserve actual citations and label local topic matches separately',()=>{
  const roles=[{key:'server',name:'服务端研发'}],requirement='合唱邀请重复提交和接口重试';
  const review={roles,scene:'ktv',requirement,inputs:[requirement],role_results:[]};
  assert.deepEqual(reviewMethodReferences(review),[]);
  const ref=selectAssertions(roles,requirement,'ktv').find(r=>r.reference_id==='AWS-IDEMPOTENCY');
  review.role_results=[{role:'server',references:[{id:ref.id,quote:ref.assertion,source:ref.source}]}];
  const used=reviewMethodReferences(review);
  assert.equal(used.length,1);assert.equal(used[0].usage,'本轮意见引用');
  assert.match(used[0].url,/aws.amazon.com/);assert.match(used[0].limitations,/不能证明/);
  review.role_results[0].references[0].quote='编造已经实测通过';
  assert.deepEqual(reviewMethodReferences(review),[]);
  review.role_results=[];review.reference_only=true;
  assert.ok(reviewMethodReferences(review).every(r=>r.usage.includes('按议题匹配')));
});

test('every legacy assertion has a disposition and unsafe numerical claims remain quarantined',()=>{
  const audit=JSON.parse(fs.readFileSync(new URL('./ktv-expert-skills/assertion-review.json',import.meta.url),'utf8'));
  assert.deepEqual(audit.items.map(a=>a.id).sort(),ASSERTIONS.map(a=>a.id).sort());
  assert.equal(new Set(audit.items.map(a=>a.id)).size,48);
  const selected=selectAssertions(ROLE_PERSONAS,ASSERTIONS.map(a=>a.assertion).join(' '),'ktv');
  for(const a of audit.items) {
    assert.ok(a.reason.length>15);
    if(a.disposition==='quarantined')assert.ok(!selected.some(r=>r.id===a.id));
  }
  assert.match(audit.items.find(a=>a.id==='server-cost-001').reason,/6000/);
  assert.equal(PRACTICE_REFERENCES.length,9);
  for(const r of PRACTICE_REFERENCES){assert.equal(new URL(r.source_url).protocol,'https:');assert.ok(r.limitations);assert.ok(r.applicability);assert.equal(r.evidence_scope,'method_only');}
});

test('text-only JSON providers receive the full citation contract and incomplete references get actionable repairs',()=>{
  assert.match(REVIEW_CONTRACT,/references:\[\{id,quote,source,usage,scenario\}\]/);
  assert.match(REVIEW_CONTRACT,/quote.*assertion/);
  const refs=selectAssertions([{key:'server'}],'同场邀请重复提交','ktv');
  const check=validateRoleOutput({role:'server',text:'邀请重试建议绑定同一请求标识',references:[{id:refs[0].id,kind:'method_only'}],predictions:[],prediction_gap:'缺少实际请求量与时延基线'},'server',refs);
  assert.equal(check.valid,false);
  assert.ok(check.errors.some(e=>e.includes('quote、source、usage、scenario')&&e.includes('assertion')));
});

test('repair feedback identifies short conditions and the allowed risk labels',()=>{
  const result=validateDiscussionOutput({stance:'有条件',stance_conditions:['不新增收费'],risks:[{impact_tag:'待验证'}]},'pd',[],{},'本次不新增收费');
  assert.ok(result.exclusion_reasons.some(e=>/stance_conditions\[0\].*5.*6/.test(e)));
  assert.ok(result.exclusion_reasons.some(e=>e.includes('待验证')&&e.includes('阻塞、待澄清、建议')));
});
