> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 条件验证 condition-verification

## 用途
验证"有条件通过"的条件是否满足，确保条件不是空话。

## 条件结构


condition:
  id: 编号
  review_id: 所属评审
  condition: 条件内容
  verifier: 验证人
  verify_by: 验证时间
  verification_method: 验证方式
  pass_criteria: 通过标准
  fallback: 不满足时的处理
  status: 待验证/验证中/通过/不通过
验证流程


条件设定 → 验证人准备验证 → 到达验证时间
  → 执行验证（按 verification_method）
  → 对比 pass_criteria
  → 通过：进入执行阶段
  → 不通过：触发 fallback
常见条件类型

类型	示例	验证方式
数据条件	并发压测 P99 < 500ms	压测报告
材料条件	客户签字确认验收标准	签字文件
技术条件	低端机帧率 ≥ 30fps	实测报告
合规条件	版权授权已签约	合同扫描件
资源条件	驻场人员已到位	人员名单
不通过的处理（fallback）

fallback 类型	处理
退回重审	重新进入评审流程
降级执行	缩小范围，部分执行
取消执行	放弃本次方案
升级	升级到外部决策
验证记录


verification_record:
  condition_id: 编号
  verified_at: 时间
  verifier: 验证人
  method: 验证方式
  result: 通过/不通过
  evidence: 验证证据
  next_action: 下一步
禁止行为

禁止条件模糊（无法验证）
禁止不指定验证人
禁止不指定验证时间
禁止不通过不执行 fallback
