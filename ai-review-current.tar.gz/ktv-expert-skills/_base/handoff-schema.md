# 交接契约

to_role：接收角色；judgment：已有判断；open_questions：未决问题；acceptance：需要对方提供的验收口径。
可附约束、原始证据、预测编号、紧急度。接收角色缺席时请求补充，不编造应答。
