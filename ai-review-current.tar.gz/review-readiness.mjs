const stages=['chat','score','risk','todo','prd'];
export function liveReviewChecks(result,audit,roleKeys) {
  const score=result?.artifacts?.score;
  const complete=roleKeys.length>0&&!result?.failure&&Boolean(result?.conclusion)&&
    result.phase_progress?.length===6&&result.phase_progress.every(p=>p.status==='complete')&&
    roleKeys.every(role=>result.role_status?.[role]?.included===true)&&
    stages.every(stage=>result.workflow?.[stage]==='complete')&&
    ['通过','不通过'].includes(score?.verdict)&&score?.decision_status==='reviewed'&&Number.isFinite(score?.score)&&
    stages.slice(1).every(stage=>result.artifacts?.[stage]?.verdict===score.verdict)&&
    Array.isArray(result.artifacts?.risk?.items)&&Array.isArray(result.artifacts?.todo?.items)&&
    Boolean(result.artifacts?.prd?.markdown?.trim());
  return {
    api_transport:audit.length?(result?.failure?.http_status?'failed':'passed'):'unverified',
    model_contract:complete?'passed':'failed',
    free_cost:audit.some(item=>Number(item.cost)>0)?'failed':audit.length&&audit.every(item=>item.cost===0)?'passed':'unverified'
  };
}
export function releaseChecks({localPassed,live,source,now=Date.now()}) {
  const age=now-Date.parse(live?.at);
  const current=live?.source===source&&live?.full===true&&live?.transport==='batched'&&Number.isFinite(age)&&age>=0&&age<86400000;
  const checks={local_flow:localPassed?'passed':'failed',api_transport:current?live.checks?.api_transport || 'unverified':'unverified',model_contract:current?live.checks?.model_contract || 'unverified':'unverified',free_cost:current?live.checks?.free_cost || 'unverified':'unverified'};
  return {...checks,local_pilot:Object.values(checks).every(status=>status==='passed')?'passed':'blocked',scope:'本机单用户试用，不是公网多人服务上线认证',unverified:['模型专业判断的准确性及现场适用性','免费服务持续可用性和长期时延']};
}
