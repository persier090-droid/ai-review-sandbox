import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {sceneKey, relatedTopic} from './review-context.mjs';
import {rebuildReviewArtifacts} from './review-delivery.mjs';
import {collectReviewRisks} from './review-risks.mjs';
import {assessScene,scenePolicy} from './review-scene.mjs';

export class ReviewStore {
  constructor(directory) {
    this.directory = directory;
    this.file = path.join(directory, 'events.jsonl');
    this.reviews = new Map();
    this.revisions = {};
    if (fs.existsSync(this.file)) {
      const bytes=fs.readFileSync(this.file),lines=bytes.toString('utf8').split('\n');
      for (const [index,line] of lines.entries()) {
        if(!line.trim())continue;
        let event;
        try {event=JSON.parse(line);}catch {
          if(index!==lines.length-1 || bytes.at(-1)===10)throw new Error(`评审记录第${index+1}行损坏，原文件保留，请从备份核对恢复`);
          // Only an uncommitted final write can be discarded, after archiving
          // its exact bytes. Corruption in committed history must stay visible.
          const backup=path.join(this.directory,`events-interrupted-${crypto.randomUUID()}.jsonl`);
          fs.writeFileSync(backup,bytes,{flag:'wx',mode:0o600});
          fs.truncateSync(this.file,bytes.lastIndexOf(10)+1);
          this.recovery={kind:'incomplete_tail',backup};
          break;
        }
        if(!event?.review || typeof event.review.id!=='string')throw new Error(`评审记录第${index+1}行结构无效，原文件保留`);
        this.reviews.set(event.review.id, event.review);
        Object.assign(this.revisions, event.revisions || {});
      }
      if(bytes.length&&bytes.at(-1)!==10&&!this.recovery)fs.appendFileSync(this.file,'\n');
    }
  }
  recoverInterrupted() {
    let count=0;
    for(const original of this.reviews.values()) {
      if(original.discussion_complete!==false&&original.workflow?.prd==='complete')continue;
      if(original.discussion_complete===undefined)continue;
      const review=structuredClone(original);
      review.failure={stage:review.state,code:'SERVICE_RESTARTED',message:'本地服务曾中断，已保存的有效进度可继续；请点击重试讨论',at:new Date().toISOString(),action:'只续跑未完成阶段，不将中断作为需求不通过'};
      review.state='INTERRUPTED';review.discussion_complete=true;review.conclusion=null;
      review.quality={valid:false,decision_ready:false,errors:[review.failure.message],warnings:[],scope:'服务恢复记录，不是业务评审结论'};
      for(const phase of review.phase_progress || [])if(phase.status!=='complete')phase.status='incomplete';
      rebuildReviewArtifacts(review);this.save(review,'service_recovered');count++;
    }
    return count;
  }
  refreshScenePolicy() {
    let count=0;
    for(const original of this.reviews.values()) {
      if(!original.discussion_complete||!original.artifacts?.score||original.artifacts.score.scene_assessment?.policy.version===scenePolicy(original.scene).version)continue;
      const review=structuredClone(original);
      review.reassessment_required=true;
      review.artifact_policy_refresh={version:scenePolicy(review.scene).version,at:new Date().toISOString(),reason:'补充场景验收门槛，原始对话与模型建议保持不变'};
      rebuildReviewArtifacts(review);this.save(review,'scene_policy_refresh');count++;
    }
    return count;
  }
  get(id) { return this.reviews.has(id) ? structuredClone(this.reviews.get(id)) : null; }
  learning(scene, topic) {
    const entries = [];
    for (const review of this.reviews.values()) {
      if (sceneKey(review.scene) !== sceneKey(scene)) continue;
      for (const item of review.learning || []) {
        if (['confirmed','candidate'].includes(item.status) && relatedTopic(topic,item.topic)) entries.push({...item,review_id:review.id});
      }
      for (const p of review.predictions || []) {
        if (!p.feedback || !relatedTopic(topic,review.requirement)) continue;
        entries.push({kind:'实测反馈（用户回填，未独立核验）',review_id:review.id,metric:p.metric,predicted:p.value,unit:p.unit,assumption:p.assumption,...p.feedback});
      }
    }
    const recent=entries.sort((a,b)=>String(b.at).localeCompare(String(a.at)));
    const roles=new Set();
    const candidates=recent.filter(e=>e.status==='candidate'&&!roles.has(e.role)&&roles.add(e.role)).slice(0,20);
    return structuredClone([...recent.filter(e=>e.status!=='candidate').slice(0,6),...candidates]);
  }
  learn(id, input) {
    const review = this.get(id);
    if (!review) throw new Error('评审记录不存在');
    review.learning ||= [];
    if(input.action==='confirm') {
      const item=review.learning.find(item=>item.id===input.item_id && item.status==='candidate');
      if(!item || typeof input.evidence!=='string' || !input.evidence.trim()) throw new Error('确认候选观点必须补充核验依据');
      item.status='confirmed';item.confirmation_evidence=input.evidence;item.source='用户确认，未独立核验';item.confirmed_at=new Date().toISOString();
    } else if (input.action === 'withdraw') {
      const item=review.learning.find(item=>item.id === input.item_id);
      if (!item) throw new Error('经验记录不存在');
      item.status='withdrawn'; item.withdrawn_at=new Date().toISOString();
    } else {
      if (!['经验','观点','纠正'].includes(input.kind) || typeof input.text !== 'string' || !input.text.trim() || input.text.length > 2000 || typeof input.evidence !== 'string' || !input.evidence.trim() || input.evidence.length > 2000) throw new Error('需填写经验/观点/纠正及依据，各不超过2000字');
      review.learning.push({id:crypto.randomUUID(),kind:input.kind,text:input.text,evidence:input.evidence,topic:review.requirement,scene:review.scene,revision:review.revision,status:'confirmed',source:'用户确认，未独立核验',at:new Date().toISOString()});
    }
    review.learning_version = (review.learning_version || 0) + 1;
    return this.save(review,'supervised_learning');
  }
  save(review, kind = 'state', revisions = {}) {
    fs.mkdirSync(this.directory, {recursive:true, mode:0o700});
    const event = {id:crypto.randomUUID(), at:new Date().toISOString(), kind, review:structuredClone(review), revisions};
    fs.appendFileSync(this.file, JSON.stringify(event) + '\n', {mode:0o600});
    this.reviews.set(review.id, event.review);
    Object.assign(this.revisions, revisions);
    return this.get(review.id);
  }
  refresh(review, kind, revisions={}) {
    if(review.discussion_complete && review.artifacts?.score) rebuildReviewArtifacts(review);
    return this.save(review,kind,revisions);
  }
  feedback(id, input) {
    const review = this.get(id);
    if (!review) throw new Error('评审记录不存在');
    const item = (review.predictions || []).find(p => p.id === input.prediction_id);
    if (!item || !Number.isFinite(input.actual) || !input.evidence?.trim() || !input.reason?.trim() || !['场景识别错','约束遗漏','模型参数偏','执行偏差'].includes(input.attribution)) throw new Error('回填需要有效预测、实测数值、证据、归因和原因');
    if (item.feedback) throw new Error('该预测已经回填；原记录不可覆盖');
    const deviation = input.actual - item.value;
    const met = item.operator === '<=' ? input.actual <= item.value + item.tolerance : item.operator === '>=' ? input.actual >= item.value - item.tolerance : Math.abs(deviation) <= item.tolerance;
    item.feedback = {actual:input.actual, evidence:input.evidence, attribution:input.attribution, reason:input.reason, at:new Date().toISOString(), deviation, deviation_rate:item.value === 0 ? null : deviation / Math.abs(item.value), met};
    const revisions = {};
    if (!met) for (const assertionId of item.assertion_ids || []) revisions[assertionId] = {status:'needs_revision', review_id:id, prediction_id:item.id, reason:input.reason, at:item.feedback.at};
    review.retrospective = {status:review.predictions.every(p => p.feedback) ? '已回填，待复核归因' : '待回填', updated_at:item.feedback.at};
    review.learning_version = (review.learning_version || 0) + 1;
    review.reassessment_required=true;
    return this.refresh(review, 'prediction_feedback', revisions);
  }
  track(id, input) {
    const review = this.get(id);
    if (!review) throw new Error('评审记录不存在');
    if(input.kind==='scene') {
      const item=assessScene(review).checks.find(c=>c.id===input.item_id&&c.contract_key===input.contract_key);
      if(!review.discussion_complete||!item?.plan_valid||!['通过','不通过'].includes(input.status)||typeof input.evidence!=='string'||input.evidence.trim().length<6)throw new Error('场景验收项无效、标准已变更或缺少具体证据');
      review.scene_verifications ||= [];
      review.scene_verifications.push({id:item.id,contract_key:item.contract_key,scope_key:review.effective_scope?.key,revision:review.revision,status:input.status,evidence:input.evidence.trim(),source:'human',at:new Date().toISOString()});
      review.learning_version=(review.learning_version || 0)+1;
      review.reassessment_required=true;
      return this.refresh(review,'scene_verification');
    }
    const collection = input.kind === 'risk' ? collectReviewRisks(review) : input.kind === 'condition' ? review.conditions : input.kind === 'execution' ? review.execution : null;
    const item = collection?.find(x => x.id === input.item_id);
    const statuses = input.kind === 'risk' ? ['已解除','待验证'] : input.kind === 'condition' ? ['通过','不通过'] : ['待开始','进行中','已完成','取消'];
    if (!item || !statuses.includes(input.status) || !input.evidence?.trim()) throw new Error('无效跟踪项或缺少执行证据');
    if (review.revision && item.revision !== review.revision) throw new Error('不能修改历史修订的执行状态');
    if (input.kind === 'execution' && item.kind !== 'verification' && ['进行中','已完成'].includes(input.status) && (review.conditions || []).some(c => (!review.revision || c.revision === review.revision) && c.status !== '通过')) throw new Error('附加条件尚未全部验证通过');
    if (input.kind === 'execution' && item.kind !== 'verification' && !review.quality?.decision_ready) throw new Error('评审依据或输出尚未通过门禁，需先复核重审');
    if(input.kind==='execution'&&item.kind!=='verification'&&review.artifacts?.score?.verdict!=='通过') throw new Error('本轮尚未取得有效通过结论，不能启动开发执行');
    item.history ||= [];
    item.history.push({status:item.status,evidence:item.evidence || '',at:item.updated_at || null});
    item.status = input.status;
    item.evidence = input.evidence;
    item.updated_at = new Date().toISOString();
    review.learning_version=(review.learning_version || 0)+1;
    if(input.kind==='risk') {
      review.risk_verifications ||= [];
      review.risk_verifications.push({id:item.id,risk_key:item.risk_key,scope_key:review.effective_scope?.key,revision:review.revision,status:input.status,evidence:input.evidence,at:item.updated_at});
    }
    if(input.kind!=='execution') review.reassessment_required=true;
    if (input.kind === 'condition' && input.status === '不通过') { review.state = 'CONDITION_FAILED'; review.next_action = item.fallback; }
    return this.refresh(review, 'tracking_update');
  }
}
