import fs from 'node:fs';
import crypto from 'node:crypto';
const root=new URL('../',import.meta.url);
export function sourceFingerprint() {
  const hash=crypto.createHash('sha256');
  for(const name of fs.readdirSync(root).filter(n=>n==='index.html'||(n.endsWith('.mjs')&&!n.endsWith('.test.mjs'))).sort())hash.update(name).update(fs.readFileSync(new URL(name,root)));
  const visit=directory=>{
    for(const entry of fs.readdirSync(new URL(directory,root),{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))) {
      const name=`${directory}${entry.name}`;
      if(entry.isDirectory())visit(`${name}/`);
      else if(/\.(md|json)$/.test(name))hash.update(name).update(fs.readFileSync(new URL(name,root)));
    }
  };
  visit('ktv-expert-skills/');
  hash.update(fs.readFileSync(new URL('evaluation/ktv-innovation-60.json',root)));
  hash.update(fs.readFileSync(new URL('evaluation/ktv-scenario-foundation-60.json',root)));
  hash.update(fs.readFileSync(new URL('evaluation/review-cases-1000.json',root)));
  hash.update(fs.readFileSync(new URL('evaluation/scenario-catalog.mjs',root)));
  return hash.digest('hex');
}
