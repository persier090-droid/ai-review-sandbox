import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ASSERTIONS, selectAssertions, assertionStatus, validateRoleOutput} from './expert-skills.mjs';
import {ReviewStore} from './review-store.mjs';
import {runReview, transition, REVIEW_TYPES} from './review-runtime.mjs';
import {readModelStream} from './server.mjs';
import {ktvScenePlans} from './tests/scene-fixture.mjs';

const roles=['pd','sales','project','client','server','test','h5'].map(key=>({key,name:key}));
const request={roles,requirement:'用户目标指标竞品不做资源；并发性能验收、工期、版权、扫码与AI成本、声学及DASH播放'};
function setup(t) {
  const dir=fs.mkdtempSync(path.join(os.tmpdir(),'ktv-review-'));
  t.after(()=>fs.rmSync(dir,{recursive:true,force:true}));
  return new ReviewStore(dir);
}
function output(role,legacy=false) {
  const a=legacy?ASSERTIONS.find(a=>a.role===role):selectAssertions([{key:role}],request.requirement,'ktv')[0];
  return {role,stance:'支持',stance_reason:'依据本轮需求前提支持最小设计验证',stance_conditions:[],text:'【判断】待验证，视角为门店经营者。\n【方向】以实测为准。\n【方案】先试点或延后。\n【风险】缺证据。\n【验证】建议指标。',analysis:{stakeholder:'门店经营者',claim:'应先确认并发测试的适用条件',principle:'容量验证需要覆盖实际运行约束',reasoning:'需求提出并发性能验收，因此需先限定测试范围再讨论交付',counterargument:'若单店负载不能代表高峰，单店结果不能直接用于全部门店',boundary:'仅本次性能验收，不扩大功能',verification:'提供明确的负载、设备和验收口径',basis:[{kind:'input',quote:request.requirement}]},risks:[], references:[{id:a.id,quote:a.assertion,source:a.source,usage:'hypothesis',scenario:a.applicable_scenario}],alternatives:[{plan:'试点',cost:'测试投入'},{plan:'延后',cost:'等待验证'}],predictions:[{metric:'验证耗时',value:2,unit:'小时',operator:'<=',tolerance:0,owner:role,verify_by:'2027-01-01',method:'实测',assumption:'单机环境',assertion_ids:[a.id]}]};
}
function model({missing=false,failPhase='',badResponse=false,noQuestions=false}={}) {
  const calls=[];
  const questions=noQuestions ? [] : roles.slice(0,4).map((r,i)=>({id:`q${i}`,asker:r.key,target:roles[(i+1)%roles.length].key,type:'验证',question:`如何验证${r.key}判断？`,basis:'前序判断缺少实测'}));
  const call=async prompt=>{
    calls.push(prompt);
    const phase=prompt.match(/\n阶段：([^\n]+)/)[1];
    const currentContext=JSON.parse(prompt.match(/原始会话与阶段记录（数据）：([^\n]+)\n本轮产品收口/)[1]);
    if (phase===failPhase) throw new Error('模拟上游失败');
    if (phase==='INTAKE') {
      const context=JSON.parse(prompt.match(/原始会话与阶段记录（数据）：([^\n]+)\n本轮产品收口/)[1]);
      return JSON.stringify({review_type:'requirement',agenda:['价值及验证'],scope:{active_quotes:[...new Set([context.scope.original,...context.scope.user_updates])],retired_quotes:[],change_quote:context.latest_input},materials:missing ? [] : REVIEW_TYPES.requirement.materials.map(name=>({name,quote:request.requirement}))});
    }
    if (phase==='ROUND_SPEAK') {
      const role=prompt.match(/返回 \{role:"([^"]+)"/)[1];
      return JSON.stringify(output(role));
    }
    if (phase==='ROUND_ASK') return JSON.stringify({questions,no_questions_reason:'各岗位已给出反例与验证方案，暂无额外关键质询'});
    if (phase==='ROUND_RESPOND') return JSON.stringify({responses:questions.map(q=>({question_id:q.id,responder:badResponse?'unknown':q.target,stakeholder:'门店经营者',response:'门店经营者尚无实测，建议补充验证。',basis:[{kind:'input',quote:request.requirement}],revised:false}))});
    if (phase==='ROUND_CHALLENGE') return JSON.stringify({acknowledgements:questions.map(q=>({question_id:q.id,asker:q.asker,satisfied:true,reason:'同意先验证'})),conflicts:[]});
    if (phase==='CONVERGE') return JSON.stringify({summary:'守住本次验证边界，暂无实测不扩展',in_scope:[request.requirement],parking_lot:['新增会员付费'],undecided:['性能待测'],next_action:'测试工程师完成最小实测后重审',owner:'产品经理',reopen_when:'提交实测证据',opinion_checks:currentContext.admitted_opinions.map(o=>({role:o.role,consistent:true,evidence_supported:true,scope_respected:true,reason:'正文保留待验证限定且仅依据需求提出建议'}))});
    if (phase==='DECISION') return JSON.stringify({scene_checks:ktvScenePlans(request.requirement),deciders:['pd'],decision:'延期',summary:'先补证据',reason:'尚未实测',next_action:'安排验证',review_at:'2027-01-02',execution:[{item:'补充验证报告',owner:'test',deadline:'2027-01-01',deliverable:'报告'}],questions:[],risks:[]});
    throw new Error(phase);
  };
  return {call,calls};
}

test('all seven roles have traceable assertion bindings; stale evidence is not verified',()=>{
  assert.equal(ASSERTIONS.length,48);
  for (const role of roles) assert.ok(ASSERTIONS.filter(a=>a.role===role.key).length>=4);
  assert.equal(assertionStatus(ASSERTIONS[0]),'unverified');
  assert.equal(assertionStatus({...ASSERTIONS[0],status:'verified',last_verified:'2020-01-01'}),'expired');
});
test('gate rejects altered numbers, invented sources, role leakage and falsely verified evidence',()=>{
  const base=output('test',true);
  assert.equal(validateRoleOutput(base,'test',ASSERTIONS).valid,true);
  assert.equal(validateRoleOutput(base,'test',ASSERTIONS).decision_ready,false);
  for (const mutation of [o=>o.references[0].quote+='300',o=>o.references[0].source='假标准',o=>o.references[0].usage='verified',o=>o.references[0].id='sales-roi-001',o=>o.predictions[0].value='未知']) {
    const candidate=structuredClone(base); mutation(candidate);
    assert.equal(validateRoleOutput(candidate,'test',ASSERTIONS).valid,false);
  }
});
test('incomplete materials stop before expert calls and retain review id for continuation',async t=>{
  const store=setup(t), engine=model({missing:true}), events=[];
  const result=await runReview({request,basePrompt:'',call:engine.call,emit:e=>events.push(e),store});
  assert.equal(result.state,'MATERIAL_MISSING');
  assert.equal(engine.calls.length,1);
  assert.equal(result.questions.length,6);
  assert.equal(result.closure.status,'closed');
  assert.match(result.closure.next_action,/补齐/);
  assert.ok(store.get(result.review_id));
  assert.ok(events.some(e=>e.type==='message'));
});
test('real stage loop calls all seven roles then links every question, response and acknowledgement',async t=>{
  const store=setup(t), engine=model();
  const result=await runReview({request,basePrompt:'原始需求',call:engine.call,emit:()=>{},store});
  assert.equal(engine.calls.length,13);
  assert.equal(result.state,'NEEDS_REVIEW');
  const record=store.get(result.review_id);
  assert.equal(record.challenges.length,4);
  assert.equal(record.responses.length,4);
  assert.equal(record.predictions.length,7);
  assert.deepEqual(new Set(record.messages.filter(m=>m.phase==='ROUND_SPEAK').map(m=>m.role)),new Set(roles.map(r=>r.key)));
  assert.ok(engine.calls[2].includes('【判断】待验证'));
  assert.ok(record.state_history.some(s=>s.state==='ROUND_CHALLENGE'));
  assert.equal(record.quality.decision_ready,false);
  const restored=new ReviewStore(store.directory).get(record.id);
  assert.deepEqual(restored,record);
});

test('exploratory discussion covers all nine selected personas and custom roles without inventing missing material',async t=>{
  const store=setup(t),engine=model({missing:true});
  const selected=[...roles,{key:'op',name:'运营'},{key:'service',name:'售后运维'},{key:'custom_access',name:'无障碍顾问',professional_view:'视障操作者的关闭路径',style:'给出可操作的验证'}];
  const prompts=[];
  const call=async prompt=>{
    prompts.push(prompt);
    if(prompt.includes('\n阶段：ROUND_SPEAK\n')) {
      const role=prompt.match(/返回 \{role:"([^"]+)"/)[1];const value=output('pd');value.role=role;value.references=[];value.evidence_gap='仅需求前提，没有实测依据';value.predictions=[];value.prediction_gap='暂无性能基线，不编造预测';return JSON.stringify(value);
    }
    return engine.call(prompt);
  };
  const result=await runReview({request:{...request,roles:selected,exploratory:true},basePrompt:'',call,emit:()=>{},store});
  assert.equal(result.failure,null);assert.equal(result.artifacts.score.coverage.included,10);
  assert.equal(result.artifacts.score.verdict,'不通过');assert.equal(result.phase_progress.length,6);assert.ok(result.phase_progress.every(p=>p.status==='complete'));
  assert.ok(result.messages.some(m=>m.name==='无障碍顾问'&&m.stance==='支持'));
  assert.ok(prompts.some(p=>p.includes('视障操作者的关闭路径')));
  assert.equal(store.get(result.review_id).learning.filter(l=>l.status==='candidate').length,10);
});
test('changed requirements retain original text and create a new revision',async t=>{
  const store=setup(t);
  const first=await runReview({request,basePrompt:'',call:model({missing:true}).call,emit:()=>{},store});
  const engine=model();
  await runReview({request:{...request,review_id:first.review_id,change:'新想法：增加离线降级'},basePrompt:'',call:engine.call,emit:()=>{},store});
  const record=store.get(first.review_id);
  assert.equal(record.revision,2);
  assert.equal(record.inputs[0],request.requirement);
  assert.equal(record.inputs[1],'新想法：增加离线降级');
  assert.ok(engine.calls[0].includes('待补材料'));
});
test('incorrect target responses are excluded and do not stop remaining roles or become approval',async t=>{
  const store=setup(t); let id;
  const result=await runReview({request,basePrompt:'',call:model({badResponse:true}).call,emit:e=>{if(e.review_id)id=e.review_id;},store});
  assert.equal(result.failure,null);
  assert.equal(store.get(id).state,'NEEDS_REVIEW');
  assert.equal(result.artifacts.score.verdict,'不通过');
  assert.equal(result.role_status.sales.status,'thinking');
  assert.ok(!result.artifacts.score.perspectives.some(p=>p.role==='sales'));
  assert.equal(result.closure.status,'closed');
});
test('one invalid specialist is skipped while later roles continue and rejected words never reach the discussion context',async t=>{
  const store=setup(t),engine=model();
  const call=async prompt=>{
    const raw=await engine.call(prompt);
    if(prompt.includes('\n阶段：ROUND_SPEAK\n') && prompt.includes('返回 {role:"client"')) return JSON.stringify({role:'client',text:'INVALID_OUTPUT_SENTINEL'});
    return raw;
  };
  const result=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  assert.equal(result.role_status.client.status,'thinking');
  assert.equal(result.role_status.h5.status,'included');
  assert.equal(result.artifacts.prd.verdict,'不通过');
  assert.ok(result.messages.every(m=>!m.text.includes('INVALID_OUTPUT_SENTINEL')));
  assert.ok(engine.calls.every(prompt=>!prompt.includes('INVALID_OUTPUT_SENTINEL')));
  assert.ok(store.get(result.review_id).raw_outputs.some(o=>o.raw.includes('INVALID_OUTPUT_SENTINEL')));
});
test('free quota failure makes one call, no paid retry, and still produces all deliverables',async t=>{
  const store=setup(t);let calls=0;
  const result=await runReview({request,basePrompt:'',call:async()=>{calls++;throw Object.assign(new Error('quota'),{status:429});},emit:()=>{},store});
  assert.equal(calls,1);
  assert.deepEqual(Object.keys(result.artifacts),['score','risk','todo','prd']);
  assert.equal(result.artifacts.score.verdict,'待讨论');
  assert.equal(result.artifacts.score.perspectives.length,0);
  assert.ok(result.messages.filter(m=>m.phase==='ROUND_SPEAK').every(m=>!m.text.includes('quota')));
  assert.equal(result.role_status.pd.status,'unavailable');
  assert.match(result.artifacts.score.excluded[0].reason,/quota/);
});
test('local reference mode and quota fallback preserve evidence gates and fill all deliverables',async t=>{
  for(const local of [true,false]) {
    const store=setup(t);let calls=0;
    const result=await runReview({request:{...request,requirement:'KTV点歌机新增数字人跳舞功能',reference_only:local},basePrompt:'',call:async()=>{calls++;throw Object.assign(new Error('额度受限429'),{status:429});},emit:()=>{},store});
    assert.equal(calls,local?0:1);
    assert.ok(result.messages.some(m=>m.phase==='LOCAL_REFERENCE'&&m.reference?.case_id==='KTV-001'));
    assert.ok(result.messages.filter(m=>m.reference).every(m=>!/(反驳点|参考回应|验证办法|通过条件|推翻条件|适用前提)：/.test(m.text)));
    assert.equal(result.artifacts.score.coverage.included,0);assert.equal(result.artifacts.score.score,null);
    assert.ok(result.artifacts.score.local_references.length>0);
    assert.ok(result.artifacts.risk.gaps.some(g=>g.kind==='参考待核实'));
    assert.ok(result.artifacts.todo.items.some(item=>item.source==='KTV-001'));
    const referenceTasks=result.artifacts.todo.items.filter(item=>item.source==='KTV-001');
    assert.equal(referenceTasks.length,2);
    assert.ok(referenceTasks.every(t=>t.kind==='verification'&&t.reference_only&&t.evidence_ids.includes('KTV-001-E1')));
    assert.ok(referenceTasks.some(t=>t.validation_id==='KTV-001-V1'));
    assert.equal(result.artifacts.score.local_references[0].scenario.validation.execution.status,'未执行');
    assert.ok(result.artifacts.todo.items.every(item=>item.stance!=='未参与'));
    assert.match(result.artifacts.prd.markdown,/KTV-001/);
    assert.match(result.artifacts.prd.markdown,/KTV-001-E1/);
    assert.match(result.artifacts.prd.markdown,/KTV-001-T2/);
    assert.match(result.artifacts.prd.markdown,/场景底层资料与闭环/);
    assert.ok(Object.values(result.artifacts).every(a=>a.verdict==='待讨论'));
    if(local){assert.ok(result.artifacts.todo.items.every(item=>item.stance==='案例待确认'||item.stance==='未参会'));assert.ok(result.artifacts.risk.gaps.every(g=>g.source!=='服务故障'));}
    assert.equal(result.learning.length,0);
  }
});
test('quota fallback explains the interruption, discusses references, then closes before delivering',async t=>{
  const events=[],store=setup(t);
  const result=await runReview({request:{...request,requirement:'KTV点歌机新增数字人跳舞功能'},basePrompt:'',call:async()=>{throw Object.assign(new Error('免费额度或速率受限'),{status:429});},emit:event=>events.push(structuredClone(event)),store});
  const references=events.map((e,i)=>e.type==='message'&&e.message.reference?i:-1).filter(i=>i>=0);
  const closure=events.findIndex(e=>e.type==='message'&&e.message.phase==='CLOSURE');
  assert.ok(references.length>0);
  assert.ok(closure>references.at(-1),'closing must follow all fallback discussion turns');
  assert.ok(events.findIndex(e=>e.type==='artifact')>closure,'deliverables must follow closure');
  const first=result.messages.find(m=>m.role!=='human');
  assert.equal(first.phase,'LOCAL_REFERENCE');assert.match(first.text,/429/);
  assert.doesNotMatch(first.text,/已收口|讨论到这里/);
  assert.equal(result.artifacts.score.verdict,'待讨论');
  assert.equal(result.usage.calls,1);
});
test('Chinese review type labels are accepted without changing raw model output',async t=>{
  const store=setup(t),engine=model({missing:true});
  const result=await runReview({request,basePrompt:'',call:async prompt=>{
    const value=JSON.parse(await engine.call(prompt));value.review_type='需求评审';return JSON.stringify(value);
  },emit:()=>{},store});
  assert.equal(result.failure,null);
  assert.equal(store.get(result.review_id).review_type,'requirement');
  assert.match(store.get(result.review_id).raw_outputs[0].raw,/需求评审/);
});
test('explicit labelled material is located from input when the model alters a quote, without rewriting raw output',async t=>{
  const store=setup(t);
  const requirement=REVIEW_TYPES.requirement.materials.map(name=>`${name}：样例原文要求需要核对而非现场实测。`).join('');
  const raw=JSON.stringify({review_type:'requirement',agenda:['验证边界'],materials:REVIEW_TYPES.requirement.materials.map(name=>({name,quote:'模型改写的非原文内容'}))});
  const result=await runReview({request:{...request,requirement},basePrompt:'',call:async()=>raw,emit:()=>{},store,limits:{maxCalls:1}});
  const record=store.get(result.review_id);assert.equal(record.precheck.passed,true);assert.equal(record.material_evidence.length,6);assert.ok(record.material_evidence.every(m=>requirement.includes(m.quote)&&m.source==='user_labeled_input'));assert.equal(record.raw_outputs[0].raw,raw);
});
test('automatic reflection is retrieved for the speaking persona, without becoming verified evidence',async t=>{
  const store=setup(t),first=await runReview({request,basePrompt:'',call:model({noQuestions:true}).call,emit:()=>{},store});
  const next=model({noQuestions:true});await runReview({request:{...request,review_id:first.review_id,change:'补充并发性能验收的设备约束'},basePrompt:'',call:next.call,emit:()=>{},store});
  for(const prompt of next.calls.filter(p=>p.includes('\n阶段：ROUND_SPEAK\n'))) {
    const role=prompt.match(/返回 \{role:"([^"]+)"/)[1];const context=JSON.parse(prompt.match(/原始会话与阶段记录（数据）：([^\n]+)\n本轮产品收口/)[1]);assert.ok(context.reflection_memory.length);assert.ok(context.reflection_memory.every(m=>m.role===role&&m.status==='candidate'));assert.equal(context.supervised_memory.length,0);
  }
});
test('verified condition feedback enters the next dialogue and invalidates duplicate-result reuse',async t=>{
  const store=setup(t),first=await runReview({request,basePrompt:'',call:model({noQuestions:true}).call,emit:()=>{},store});
  const record=store.get(first.review_id);record.conditions.push({id:'verified-path',revision:1,condition:'核对关闭后的点歌路径',status:'待验证'});store.save(record);
  store.track(record.id,{kind:'condition',item_id:'verified-path',status:'通过',evidence:'人工测试记录：关闭后点歌控件可达'});
  const engine=model({noQuestions:true});
  const result=await runReview({request:{...request,review_id:record.id,change:request.requirement},basePrompt:'',store,emit:()=>{},call:async prompt=>{
    const value=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：ROUND_SPEAK\n'))value.analysis.basis=[{kind:'observation',source_id:'verified-path',quote:'人工测试记录：关闭后点歌控件可达'}];
    return JSON.stringify(value);
  }});
  assert.equal(result.revision,2);assert.equal(result.artifacts.score.coverage.included,7);assert.ok(engine.calls[0].includes('condition_verifications'));assert.ok(engine.calls[0].includes('人工测试记录：关闭后点歌控件可达'));
});
test('every specialist condition gets a trackable item even when decision omits it',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const condition='核验关闭按钮不遮挡点歌主控件';
  const call=async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：ROUND_SPEAK\n')&&out.role==='pd') {out.stance='有条件';out.stance_conditions=[condition];}
    return JSON.stringify(out);
  };
  const first=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  const item=first.conditions.find(c=>c.condition===condition);
  assert.ok(item,'omitted specialist condition must remain verifiable');
  store.track(first.review_id,{kind:'condition',item_id:item.id,status:'通过',evidence:'人工验收记录：关闭与点歌控件均可达'});
  const next=await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call,emit:()=>{},store});
  assert.equal(next.conditions.find(c=>c.condition===condition&&c.revision===next.revision)?.status,'通过');
});
test('grounded design approval reaches every deliverable without treating missing empirical numbers as made-up scores',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const call=async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：ROUND_SPEAK\n')) {out.references=[];out.evidence_gap='本轮只基于需求前提，不声称实测';out.predictions=[];out.prediction_gap='尚无实测基线，不编造性能指标';}
    if(prompt.includes('\n阶段：CONVERGE\n')) out.undecided=[];
    if(prompt.includes('\n阶段：DECISION\n')) {out.basis_roles=roles.map(r=>r.key);out.decision='通过';out.execution[0].scope_quote=request.requirement;}
    return JSON.stringify(out);
  };
  const result=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  assert.equal(result.quality.decision_ready,true);
  for(const artifact of Object.values(result.artifacts))assert.equal(artifact.verdict,'通过');
  assert.ok(result.artifacts.score.score>=75);
});
test('missing or negative semantic audit cannot be overridden by an approval suggestion',async t=>{
  for(const bad of ['missing','negative']) {
    const store=setup(t),engine=model({noQuestions:true});
    const result=await runReview({request,basePrompt:'',emit:()=>{},store,call:async prompt=>{
      const out=JSON.parse(await engine.call(prompt));
      if(prompt.includes('\n阶段：CONVERGE\n')) {out.undecided=[];if(bad==='missing')delete out.opinion_checks;else out.opinion_checks[0].evidence_supported=false;}
      if(prompt.includes('\n阶段：DECISION\n')) {out.basis_roles=roles.map(r=>r.key);out.decision='通过';out.execution[0].scope_quote=request.requirement;}
      return JSON.stringify(out);
    }});
    assert.equal(result.artifacts.score.verdict,'不通过');
    assert.ok(result.quality.errors.some(e=>e.includes('语义复核')));
  }
});
test('preparation work remains trackable without treating it as a completed review',async t=>{
  const store=setup(t),result=await runReview({request,basePrompt:'',call:model({missing:true}).call,emit:()=>{},store});
  assert.equal(result.artifacts.score.verdict,'待讨论');
  const task=result.execution.find(item=>item.kind==='verification');
  const updated=store.track(result.review_id,{kind:'execution',item_id:task.id,status:'已完成',evidence:'补证材料及核对记录'});
  assert.equal(updated.execution.find(e=>e.id===task.id).status,'已完成');
  assert.equal(updated.artifacts.score.verdict,'待讨论');
});
test('an interrupted new revision cannot reuse the previous round material check as a current approval',async t=>{
  const store=setup(t),first=await runReview({request,basePrompt:'',call:model().call,emit:()=>{},store});
  const next=await runReview({request:{...request,review_id:first.review_id,change:'增加新的待验证约束'},basePrompt:'',call:async()=>{throw Object.assign(new Error('unavailable'),{status:503});},emit:()=>{},store});
  assert.equal(next.revision,2);
  assert.equal(store.get(first.review_id).precheck,null);
  assert.equal(next.artifacts.score.dimensions[0].earned,0);
  assert.equal(next.artifacts.score.verdict,'待讨论');
  assert.equal(next.failure.http_status,503);
  assert.equal(next.artifacts.score.coverage.included,0);
});
test('upstream failure records partial progress and never claims completion',async t=>{
  const store=setup(t); let id;
  await runReview({request,basePrompt:'',call:model({failPhase:'ROUND_ASK'}).call,emit:e=>{if(e.review_id)id=e.review_id;},store});
  const record=store.get(id);
  assert.equal(record.failure.stage,'ROUND_ASK');
  assert.equal(record.state,'FAILED');
  assert.ok(record.messages.length>=7);
});
test('same-input retry reuses valid stages across service restart without duplicate messages',async t=>{
  const store=setup(t),failed=model({failPhase:'ROUND_ASK'});
  const first=await runReview({request,basePrompt:'',call:failed.call,emit:()=>{},store});
  const restored=new ReviewStore(store.directory),engine=model();
  const result=await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call:engine.call,emit:()=>{},store:restored});
  assert.equal(result.revision,first.revision);
  assert.equal(engine.calls.length,5);
  assert.ok(engine.calls.every(p=>!p.includes('\n阶段：INTAKE\n')&&!p.includes('\n阶段：ROUND_SPEAK\n')));
  const record=restored.get(first.review_id);
  assert.equal(record.messages.filter(m=>m.phase==='ROUND_SPEAK').length,roles.length);
  assert.equal(record.messages.filter(m=>m.phase==='USER_INPUT').length,1);
  assert.equal(record.failure,null);
});
test('a newly admitted earlier role invalidates cached downstream discussions',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const first=await runReview({request,basePrompt:'',call:async prompt=>{
    if(prompt.includes('\n阶段：ROUND_SPEAK\n')&&prompt.includes('返回 {role:"pd"'))return JSON.stringify({role:'pd',text:'invalid'});
    return engine.call(prompt);
  },emit:()=>{},store});
  assert.ok(first.failure);
  const retry=model({noQuestions:true});
  await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call:retry.call,emit:()=>{},store});
  assert.ok(retry.calls.some(p=>p.includes('\n阶段：ROUND_ASK\n')));
  assert.ok(retry.calls.some(p=>p.includes('\n阶段：CONVERGE\n')));
});
test('stricter verification criteria never inherit weaker historical success',async t=>{
  const store=setup(t),engine=model({noQuestions:true});let strict=false;
  const call=async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：DECISION\n'))out.conditions=[{condition:'关闭能力检查',verifier:'测试工程师',verify_by:'2027-01-01',verification_method:strict?'验证全部100台设备':'验证1台设备',pass_criteria:strict?'100台全部成功':'1台成功',fallback:'停止上线'}];
    return JSON.stringify(out);
  };
  const first=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  store.track(first.review_id,{kind:'condition',item_id:first.conditions[0].id,status:'通过',evidence:'一台设备关闭成功'});
  strict=true;
  const next=await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call,emit:()=>{},store});
  assert.equal(next.conditions.find(c=>c.revision===next.revision)?.status,'待验证');
});
test('later failed verification blocks inheritance of an earlier passing record',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const call=async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：DECISION\n'))out.conditions=[{condition:'关闭能力检查',verifier:'测试工程师',verify_by:'2027-01-01',verification_method:'验证全部100台设备',pass_criteria:'100台全部成功',fallback:'停止上线'}];
    return JSON.stringify(out);
  };
  const first=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  store.track(first.review_id,{kind:'condition',item_id:first.conditions[0].id,status:'通过',evidence:'初次检查通过'});
  const next=await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call,emit:()=>{},store});
  store.track(first.review_id,{kind:'condition',item_id:next.conditions.find(c=>c.revision===next.revision).id,status:'不通过',evidence:'复测发现关闭入口失效'});
  const third=await runReview({request:{...request,review_id:first.review_id},basePrompt:'',call,emit:()=>{},store});
  assert.equal(third.conditions.find(c=>c.revision===third.revision)?.status,'待验证');
});
test('new changes invalidate stage reuse and require an explicit effective scope',async t=>{
  const store=setup(t),first=await runReview({request,basePrompt:'',call:model({failPhase:'ROUND_ASK'}).call,emit:()=>{},store});
  const engine=model({missing:true});
  const next=await runReview({request:{...request,review_id:first.review_id,change:'取消原有摄像头方案，只保留本地舞蹈'},basePrompt:'',call:async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：INTAKE\n')) delete out.scope;
    return JSON.stringify(out);
  },emit:()=>{},store});
  assert.equal(next.revision,2);
  assert.equal(engine.calls.length,1);
  assert.equal(next.artifacts.score.verdict,'待讨论');
  assert.match(next.failure?.message || '',/有效范围/);
});
test('retired requirements cannot be reused as current evidence or appear in the current PRD scope',async t=>{
  const store=setup(t),original='需求描述：使用摄像头生成舞蹈。目标用户：包厢演唱者。';
  const first=await runReview({request:{...request,requirement:original},basePrompt:'',call:model({missing:true}).call,emit:()=>{},store});
  const change='取消使用摄像头生成舞蹈，改为只播放现有授权角色。';
  const engine=model({noQuestions:true});
  const result=await runReview({request:{...request,review_id:first.review_id,change,exploratory:true},basePrompt:'',call:async prompt=>{
    const out=JSON.parse(await engine.call(prompt));
    if(prompt.includes('\n阶段：INTAKE\n')) {out.scope={active_quotes:['只播放现有授权角色','目标用户：包厢演唱者。'],retired_quotes:['使用摄像头生成舞蹈'],change_quote:change};out.materials=[];}
    if(prompt.includes('\n阶段：ROUND_SPEAK\n')) out.analysis.basis=[{kind:'input',quote:'使用摄像头生成舞蹈'}];
    return JSON.stringify(out);
  },emit:()=>{},store});
  const record=store.get(first.review_id);
  assert.equal(record.requirement,original);
  assert.match(record.effective_requirement,/只播放现有授权角色/);
  assert.doesNotMatch(record.effective_requirement,/使用摄像头/);
  assert.equal(result.artifacts.score.coverage.included,0);
  assert.ok(engine.calls.filter(p=>p.includes('\n阶段：ROUND_SPEAK\n')).every(p=>p.includes('effective_scope')));
  const basic=result.artifacts.prd.markdown.split('## 待确认清单')[0];
  assert.doesNotMatch(basic,/使用摄像头/);
});
test('changed model configuration invalidates a completed duplicate result',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const first=await runReview({request:{...request,model:'free-a'},basePrompt:'',call:engine.call,emit:()=>{},store});
  const count=engine.calls.length;
  const next=await runReview({request:{...request,model:'free-b',review_id:first.review_id},basePrompt:'',call:engine.call,emit:()=>{},store});
  assert.ok(engine.calls.length>count);assert.equal(next.revision,2);assert.notEqual(next.duplicate,true);
});
test('discussion closes without forced questions and duplicate submissions do not consume more calls',async t=>{
  const store=setup(t),engine=model({noQuestions:true});
  const result=await runReview({request,basePrompt:'',call:engine.call,emit:()=>{},store});
  assert.equal(engine.calls.length,11);
  assert.equal(result.closure.status,'closed');
  assert.ok(result.closure.parking_lot.includes('新增会员付费'));
  const repeated=await runReview({request:{...request,review_id:result.review_id,change:request.requirement},basePrompt:'',call:engine.call,emit:()=>{},store});
  assert.equal(engine.calls.length,11);
  assert.equal(repeated.revision,1);
  assert.equal(repeated.messages.length,0);
});
test('budget exhaustion produces a scoped closure and no release decision',async t=>{
  const store=setup(t),engine=model();
  const result=await runReview({request,basePrompt:'',call:engine.call,emit:()=>{},store,limits:{maxCalls:1,maxMs:1000}});
  assert.equal(engine.calls.length,1);
  assert.equal(result.state,'BUDGET_EXHAUSTED');
  assert.equal(result.closure.original_scope,request.requirement);
  assert.equal(result.quality.decision_ready,false);
  assert.equal(result.conclusion,null);
});
test('a stalled call is cancelled at the discussion deadline',async t=>{
  const store=setup(t);
  const result=await runReview({request,basePrompt:'',call:()=>new Promise(resolve=>setTimeout(()=>resolve('{}'),60)),emit:()=>{},store,limits:{maxCalls:16,maxMs:10}});
  assert.equal(result.state,'BUDGET_EXHAUSTED');
  assert.equal(result.closure.status,'closed');
});
test('confirmed experience and observed feedback are passed to the next model turn; withdrawing experience removes it',async t=>{
  const store=setup(t),first=await runReview({request,basePrompt:'',call:model().call,emit:()=>{},store});
  const confirmed=store.learn(first.review_id,{kind:'纠正',text:'专业经验：本次只验证低配机',evidence:'用户确认的试点约束'});
  const item=confirmed.learning.find(item=>item.status==='confirmed');
  store.feedback(first.review_id,{prediction_id:first.predictions[0].id,actual:4,evidence:'实测报告 ABC',attribution:'约束遗漏',reason:'低配机性能不同'});
  const engine=model({missing:true});
  await runReview({request:{...request,review_id:first.review_id,change:request.requirement},basePrompt:'',call:engine.call,emit:()=>{},store});
  assert.equal(engine.calls.length,1);
  assert.match(engine.calls[0],/专业经验：本次只验证低配机/);
  assert.match(engine.calls[0],/实测报告 ABC/);
  assert.match(engine.calls[0],/previous_closure/);
  store.learn(first.review_id,{action:'withdraw',item_id:item.id});
  const next=model({missing:true});
  await runReview({request:{...request,review_id:first.review_id,change:request.requirement},basePrompt:'',call:next.call,emit:()=>{},store});
  assert.equal(next.calls.length,1);
  assert.doesNotMatch(next.calls[0],/专业经验：本次只验证低配机/);
});
test('excess questions are held for follow-up and never start a second discussion loop',async t=>{
  const store=setup(t),engine=model();
  const call=async(prompt,signal)=>{
    const raw=await engine.call(prompt,signal);
    if (!prompt.includes('\n阶段：ROUND_ASK\n')) return raw;
    const value=JSON.parse(raw);
    value.questions.push({id:'extra',asker:'test',target:'client',type:'验证',question:'后续扩展性能需求',basis:'更多想法'});
    return JSON.stringify(value);
  };
  const result=await runReview({request,basePrompt:'',call,emit:()=>{},store});
  assert.equal(engine.calls.length,13);
  assert.equal(store.get(result.review_id).challenges.length,4);
  assert.ok(result.closure.undecided.includes('后续扩展性能需求'));
  assert.equal(result.quality.decision_ready,false);
});
test('feedback persists evidence and flags assertions without rewriting their values',t=>{
  const store=setup(t), original=ASSERTIONS[0].assertion;
  store.save({id:'test-review',predictions:[{...output('sales',true).predictions[0],id:'p1'}]});
  const record=store.feedback('test-review',{prediction_id:'p1',actual:4,evidence:'现场测试报告A',attribution:'约束遗漏',reason:'网络条件不符'});
  assert.equal(record.predictions[0].feedback.met,false);
  assert.equal(store.revisions[ASSERTIONS[0].id].status,'needs_revision');
  assert.equal(ASSERTIONS[0].assertion,original);
  assert.throws(()=>store.feedback('test-review',{prediction_id:'p1',actual:4,evidence:'报告',attribution:'约束遗漏',reason:'重填'}),/不可覆盖/);
  assert.ok(new ReviewStore(store.directory).revisions[ASSERTIONS[0].id]);
});
test('condition failure executes fallback status; execution cannot bypass prerequisites',t=>{
  const store=setup(t);
  store.save({id:'condition-review',quality:{decision_ready:true},conditions:[{id:'c1',status:'待验证',fallback:'退回重审'}],execution:[{id:'e1',status:'待开始'}]});
  assert.throws(()=>store.track('condition-review',{kind:'execution',item_id:'e1',status:'已完成',evidence:'记录'}),/尚未全部/);
  assert.equal(store.track('condition-review',{kind:'condition',item_id:'c1',status:'不通过',evidence:'未达标报告'}).state,'CONDITION_FAILED');
});
test('state machine disallows skipping precheck',()=>{
  assert.throws(()=>transition({state:'INIT',state_history:[]},'DECISION'),/非法/);
});
test('SSE reader preserves split Chinese bytes, ignores comments, handles last line and upstream errors',async()=>{
  const encoded=Buffer.from(': keepalive\n\ndata: '+JSON.stringify({choices:[{delta:{content:'中文回复'}}]})+'\n\ndata: [DONE]');
  async function* chunks(){for(let i=0;i<encoded.length;i+=2)yield encoded.subarray(i,i+2);}
  assert.equal(await readModelStream(chunks(),true),'中文回复');
  async function* failure(){yield Buffer.from('data: {"error":{"message":"quota"}}\n');}
  await assert.rejects(readModelStream(failure(),true),/quota/);
});
