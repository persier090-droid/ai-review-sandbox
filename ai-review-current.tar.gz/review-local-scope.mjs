// Offline scope is a review draft, never a substitute for approved model/human scope.
export function localScope(review) {
  if(review.effective_scope?.status==='resolved')return {status:'candidate',input:review.effective_requirement,latest:review.inputs?.at(-1)||review.requirement,retired:[]};
  const inputs=(review.inputs?.length?review.inputs:[review.requirement]).filter(Boolean);
  const constraintOnly=text=>/^(补充[：:]?\s*)?(预算|成本上限|工期|人日|资源上限|费用上限)/.test(text)&&!/新增|改为|改成|改做/.test(text);
  let active=[],retired=[],pending=false;
  for(const raw of inputs) {
    const text=String(raw).trim();
    const budgetChange=text.match(/^(?:补充[：:]?\s*)?(预算|验证预算|预算上限)(?:改为|调整为|变更为)(.+)$/);
    if(budgetChange&&active.length) {
      active=active.map(s=>s.replace(/(?:验证预算|预算上限|预算)[^。；\n]*/g,'')).filter(Boolean);
      active.push(`${budgetChange[1]}${budgetChange[2]}`);continue;
    }
    const cancellation=/(取消|不做|不要|改为|改做|改成|只做|仅做|只需要|只要)/.test(text);
    const replacement=text.match(/(?:改为|改做|改成|只做|仅做|只需要|只要)[：:\s]*([^。；\n]+)/);
    if(cancellation&&active.length&&replacement) {
      retired.push(...active.filter(s=>!constraintOnly(s)));active=[replacement[1],...active.filter(constraintOnly)];
      pending=/^(其他|其它|这个|那个|别的|新的)(功能|内容|方案)?[。？?]?$/.test(replacement[1]);
    } else if(cancellation&&active.length&&/(取消|不要|不做)/.test(text)) {
      // A negated object cannot be used as positive retrieval evidence.
      const object=text.match(/(?:取消|不要|不做)[：:\s]*([^，。；\n]+)/)?.[1];
      if(object) {retired.push(...active.filter(s=>s.includes(object)));active=active.filter(s=>!s.includes(object));}
      pending=true;
    } else {active.push(text);if(inputs.length===1)pending=false;}
  }
  const focus=active.findLast(text=>!constraintOnly(text)) || active.at(-1) || '';
  return {status:pending?'clarify':'candidate',input:active.join('；'),latest:inputs.at(-1)||'',focus,retired,source:'根据原文整理的本地候选范围，待提出者确认'};
}
