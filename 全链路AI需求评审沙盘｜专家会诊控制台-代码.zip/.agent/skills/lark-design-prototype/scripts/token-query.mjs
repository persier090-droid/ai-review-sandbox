#!/usr/bin/env node
import { createHash } from 'node:crypto';

const SOURCES = {
  semantic: {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/db71a6cd-33f97519-0d446cd5/semantic.json',
    sha256: '33f975193bcd0b5b12df9003e6f8586bf4662336e0bd5cf73ea1f362cfa4eb50',
  },
  keys: {
    url: 'https://lf3-static.bytednsdoc.com/obj/eden-cn/pshi/lark-design-prototype/1.0.4/db71a6cd-33f97519-0d446cd5/keys.json',
    sha256: '0d446cd57b0beaaaa9ba485009b31a73be77d5f87a8481ec032c54f33b3bb471',
  },
};

function usage() {
  return `Usage:
  node token-query.mjs --query "<token name or intent>" [--source semantic|keys] [--limit 5]

Fetches the versioned public token resource, verifies SHA-256, and returns compact matches.`;
}

function argValue(name, fallback = '') {
  const index = process.argv.indexOf(name);
  return index === -1 ? fallback : process.argv[index + 1] || fallback;
}

function tokenize(value) {
  return String(value || '')
    .toLowerCase()
    .split(/[\s,，、:：;；/|()（）\[\]{}'"`<>.!?？。_-]+/)
    .map((item) => item.trim())
    .filter(Boolean);
}

function scoreEntry([key, value], query, queryTokens) {
  const normalizedKey = key.toLowerCase();
  const searchText = `${key} ${value?.$description || ''} ${value?.$extensions?.id || ''} ${
    value?.$extensions?.name || ''
  }`.toLowerCase();
  let score = normalizedKey === query ? 100 : normalizedKey.includes(query) ? 40 : 0;
  for (const token of queryTokens) {
    if (normalizedKey.includes(token)) score += 10;
    if (searchText.includes(token)) score += 3;
  }
  return score;
}

const sourceName = argValue('--source', 'semantic');
const source = SOURCES[sourceName];
const query = argValue('--query').trim().toLowerCase();
const limit = Math.max(1, Number.parseInt(argValue('--limit', '5'), 10) || 5);

if (!source || !query) {
  console.error(usage());
  process.exit(2);
}

const response = await fetch(source.url);
if (!response.ok) {
  throw new Error(`Token request failed with HTTP ${response.status}`);
}
const text = await response.text();
const actualHash = createHash('sha256').update(text).digest('hex');
if (actualHash !== source.sha256) {
  throw new Error(`Token integrity check failed: expected ${source.sha256}, got ${actualHash}`);
}

const queryTokens = tokenize(query);
const matches = Object.entries(JSON.parse(text))
  .map((entry) => ({ entry, score: scoreEntry(entry, query, queryTokens) }))
  .filter(({ score }) => score > 0)
  .sort((a, b) => b.score - a.score || a.entry[0].localeCompare(b.entry[0]))
  .slice(0, limit)
  .map(({ entry: [key, value] }) => ({ key, ...value, source: source.url }));

console.log(JSON.stringify(matches, null, 2));
