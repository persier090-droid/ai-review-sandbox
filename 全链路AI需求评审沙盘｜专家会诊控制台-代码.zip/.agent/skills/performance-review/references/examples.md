# Performance Review Examples

> Extracted from stability-check-examples.md. Covers P1, P2, P3, P4, Q1 rules.

---

## P1 · Data Access Performance

**BAD — Unlimited query**:
```typescript
const allProducts = await db.query('SELECT * FROM products'); // full table → OOM
```

**GOOD — Specific fields + pagination**:
```typescript
const products = await db.query(
  'SELECT id, name, price FROM products WHERE active = true LIMIT 50 OFFSET $1',
  [page * 50]
);
```

---

## P2 · Memory Usage

**BAD — Large file fully read into memory**:
```typescript
const file = fs.readFileSync(req.file.path); // 2GB → OOM
```

**GOOD — Stream**:
```typescript
await pipeline(fs.createReadStream(req.file.path), transform, fs.createWriteStream(out));
```

**BAD — Module-level Map growing without bound**:
```typescript
const userCache = new Map(); // never evicted → memory leak
app.get('/user/:id', async (req, res) => {
  if (!userCache.has(req.params.id)) userCache.set(req.params.id, await User.findById(req.params.id));
  res.json(userCache.get(req.params.id));
});
```

**GOOD — LRU cache**:
```typescript
import { LRUCache } from 'lru-cache';
const userCache = new LRUCache<string, User>({ max: 1000, ttl: 300_000 });
```

---

## P3 · Algorithm Complexity

**BAD — O(n²)**:
```typescript
function findCommon(a: string[], b: string[]) { return a.filter(x => b.includes(x)); }
```

**GOOD — Set O(n)**:
```typescript
function findCommon(a: string[], b: string[]) { const s = new Set(b); return a.filter(x => s.has(x)); }
```

---

## P4 · Concurrency & Backpressure

**BAD — Unbounded Promise.all**:
```typescript
const results = await Promise.all(records.map(r => fetch(`/api/${r.id}`))); // 10000 concurrent
```

**GOOD — p-limit**:
```typescript
import pLimit from 'p-limit';
const limit = pLimit(10);
const results = await Promise.all(records.map(r => limit(() => fetch(`/api/${r.id}`))));
```

**BAD — Stream without backpressure handling**:
```typescript
readable.on('data', (chunk) => { writable.write(transform(chunk)); }); // does not check return value
```

**GOOD — pipeline**:
```typescript
await pipeline(fs.createReadStream('in.csv'), new TransformStream(), fs.createWriteStream('out.csv'));
```

---

## Q1 · Anti-pattern Detection

**BAD — Deep nesting**:
```typescript
if (user) { if (user.isActive) { if (user.hasPermission('edit')) { if (item) { if (item.isEditable) { /* ... */ } } } } }
```

**GOOD — Guard Clause**:
```typescript
if (!user) return res.status(401).json({ error: 'Unauthorized' });
if (!user.isActive) return res.status(403).json({ error: 'Disabled' });
if (!user.hasPermission('edit')) return res.status(403).json({ error: 'No permission' });
if (!item?.isEditable) return res.status(400).json({ error: 'Not editable' });
// business logic, no more nesting
```
