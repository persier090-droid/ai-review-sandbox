# 本机小范围分享

分享服务与原本机服务独立：原服务使用8000端口与原有配置，分享服务使用8001端口，不读取本机.env、不传入模型凭据，服务端强制本地交叉验证。

访问者需要口令登录。每个浏览器登录会话使用单独的评审、学习反馈和网页材料目录；换浏览器或重新登录不会自动找回旧会话。会话有效期7天，清除Cookie会失去该浏览器的访问关联。本方案适用于小范围试用，不等同于有账号管理、共享协作和找回机制的正式多租户服务。

## 启动与停止

有效公司FRP配置放在 `.share/frpc-template.toml`。运行 `node scripts/prepare-share.mjs` 会验证配置并生成映射。此文件含通道令牌，不提交Git。

双击 `start-share.command` 启动，`stop-share.command` 停止。启动脚本会阻止空令牌或星号占位令牌。服务启动不等于公网验证通过；必须检查外部HTTPS页面和WSS完整流程。

当前改用经用户授权的 Cloudflare 临时隧道。运行 `node scripts/start-share.mjs --cloudflare` 首次启动后，后续双击启动入口沿用该提供方；现有隧道存活时复用原地址，隧道重启后会生成新地址，并同步到 `.share/access.json`。口令和本地记录不重置。该方式供小范围临时分享，不保证固定域名或长期服务可用性。

访问口令保存在 `.share/access-password.txt`，口令散列与公开域名保存在 `.share/access.json`。私有配置、Cookie会话记录、评审资料和日志均保存在 `.share/` 并已加入Git忽略列表。

电脑必须开机、联网。分享服务运行时阻止空闲休眠，但合盖、手动休眠、断网或关机仍会中断链接。

## 当前验证

- 单元检查：登录、错误口令、限流、Cookie过期、跨站拒绝、持久化会话目录隔离。
- 服务检查：未登录HTTP/WS拒绝、九岗位本地评审、四项结果、跨会话读取404、API模型调用拦截、私有文件拒绝。
- 公司模板中的令牌是星号占位符，原公司域名不能作为分享链接；当前有效临时地址以 `.share/access.json` 为准。外网验收结果保存在 `.share/public-verification.json`，应核对其中域名与当前域名一致。

验证命令：`node --test share-access.test.mjs server.test.mjs`、`node scripts/check-share-service.mjs`。

实际公网浏览器验收：`node scripts/check-share-public.mjs`，验证登录、WSS、完整评审与追问、四项交付、匿名拒绝和跨会话隔离，不消耗模型额度。
