import crypto from 'node:crypto';
import {roleName} from './role-personas.mjs';

const list = value => Array.isArray(value) ? value : [];
const present = value => typeof value === 'string' && value.trim();

export function collectReviewRisks(review) {
  const items = new Map();
  const add = (risk, role, source) => {
    if (!risk || typeof risk !== 'object') return;
    const text = present(risk.text) || '风险内容尚未说明，需责任岗位补充';
    const owner = roleName(review, role || risk.owner || risk.category || 'pd');
    const key = text.normalize('NFKC').replace(/[\s，。；、：:,.!?！？;]/g,'').toLowerCase();
    const riskKey=crypto.createHash('sha256').update(JSON.stringify([key,owner,risk.level,risk.impact_tag,risk.impact,risk.mitigation,risk.evidence_quote])).digest('hex');
    const id = crypto.createHash('sha256').update(`${review.id}:${review.revision}:${key}`).digest('hex').slice(0,24);
    const level = ['high','mid','low'].includes(risk.level) ? risk.level : 'high';
    const impact = ['阻塞','待澄清','建议'].includes(risk.impact_tag) ? risk.impact_tag : level==='high'?'阻塞':level==='mid'?'待澄清':'建议';
    const item = {
      ...risk, id,risk_key:riskKey, contracts:[riskKey],revision:review.revision, text, owner, level, impact_tag:impact,
      source_role:role || risk.category || '', sources:[source],owners:[owner],observations:[{owner,stakeholder:risk.stakeholder || review.role_results?.find(o=>o.role===role)?.analysis?.stakeholder || '',text,level,impact:risk.impact || '',mitigation:risk.mitigation || '',evidence_quote:risk.evidence_quote || ''}],
      stakeholder:present(risk.stakeholder) || review.role_results?.find(o=>o.role===role)?.analysis?.stakeholder || '本次需求涉及的具体对象待确认',
      evidence_quote:present(risk.evidence_quote) || '',
      impact:present(risk.impact) || '尚需责任岗位核对影响，不能视为已解除',
      mitigation:present(risk.mitigation) || '补充原始依据、影响和处置方案后复核',
      kind:present(risk.evidence_quote) ? '风险假设，需按记录核验' : '决策补充风险，依据待核验',
      status:'待验证',verification:null
    };
    const old = items.get(key);
    if (old) {
      old.sources=[...new Set([...old.sources,source])];
      old.owners=[...new Set([...old.owners,owner])];
      if(!old.observations.some(o=>JSON.stringify(o)===JSON.stringify(item.observations[0])))old.observations.push(item.observations[0]);
      old.contracts=[...new Set([...old.contracts,riskKey])];
      if (['high','mid','low'].indexOf(level)<['high','mid','low'].indexOf(old.level)) old.level=level;
      if (['阻塞','待澄清','建议'].indexOf(impact)<['阻塞','待澄清','建议'].indexOf(old.impact_tag)) old.impact_tag=impact;
      if (!old.evidence_quote && item.evidence_quote) old.evidence_quote=item.evidence_quote;
    } else items.set(key,item);
  };
  for (const output of list(review.role_results)) for (const risk of list(output.risks)) add(risk,output.role,'角色意见');
  for (const risk of list(review.conclusion?.risks)) add(risk,null,'最终决策');
  for (const risk of list(review.risks)) add(risk,null,'评审风险记录');
  return [...items.values()].map(item=>{
    item.risk_key=crypto.createHash('sha256').update(JSON.stringify(item.contracts.sort())).digest('hex');
    delete item.contracts;
    const verification=list(review.risk_verifications).filter(v=>v.risk_key===item.risk_key&&((v.id===item.id&&v.revision===review.revision)||(review.effective_scope?.key&&v.scope_key===review.effective_scope.key))).at(-1);
    item.verification=verification || null;
    item.status=verification?.status==='已解除'&&present(verification.evidence)?'已解除':'待验证';
    return item;
  });
}
