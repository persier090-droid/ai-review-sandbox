import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {ASSERTIONS, loadRoleSkill, loadProtocol} from '../expert-skills.mjs';

const root = fileURLToPath(new URL('../ktv-expert-skills/',import.meta.url));
const ids=new Set();
for (const role of ['pd','sales','project','client','server','test','h5']) {
  const skill=loadRoleSkill(role);
  assert.ok(skill.includes('assertion_binding'));
  const entries=ASSERTIONS.filter(a=>a.role===role);
  assert.ok(entries.length>=4,role);
  for (const a of entries) {
    for (const key of ['id','assertion','source','confidence','applicable_scenario','verification_method','status']) assert.ok(a[key],`${a.id}:${key}`);
    assert.ok(!ids.has(a.id),a.id); ids.add(a.id);
    assert.ok(skill.includes(a.id),`unbound ${a.id}`);
  }
  for (const match of skill.matchAll(/^  - (_base\/[a-z-]+\.md)$/gm)) assert.ok(loadProtocol(match[1]));
}
assert.ok(loadRoleSkill('facilitator'));
for(const role of ['op','service'])assert.ok(loadRoleSkill(role).includes('专业判断与验证'));
for (const name of ['intake','materials','roles','agenda','precheck','dependency','challenge-protocol','disagreement','decision-rules','time-box','state-machine','conclusion','execution-tracking','condition-verification','retrospective','self-assessment','record','failure','type-requirement','type-solution','type-delivery','type-quality','type-retrospective']) assert.ok(loadProtocol(`orchestration/review/${name}.md`));
const yamlFiles=fs.readdirSync(path.join(root,'assertion-library')).filter(f=>f.endsWith('.yaml'));
assert.equal(yamlFiles.length,7);
assert.equal(ASSERTIONS.length,48);
console.log('OK: 9 professional roles + facilitator, 48 candidate assertions, 23 review protocols; references resolved.');
