import fs from 'node:fs';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import {ROLE_PERSONAS} from '../role-personas.mjs';
import {SCORE_POLICY} from '../review-scoring.mjs';

const directory=new URL('../evaluation/',import.meta.url);
const source=fs.readFileSync(new URL('ktv-innovation-60.json',directory),'utf8');
const bank=JSON.parse(source);
const profiles={
  A:{setting:'营业中的包厢，点歌机与大屏正在播放歌曲',assets:['终端与系统版本','歌曲与素材版本','显示区域及音频链路'],baseline:'不启用新增体验时的点歌、歌词、切歌与演唱表现',observer:'包厢演唱者与值班员工'},
  B:{setting:'消费者正在找歌或演唱，可能有背景音乐和多人说话',assets:['检索曲库快照','输入样本与音频条件','算法或评分版本'],baseline:'原有检索、手动点歌和演唱操作',observer:'提出找歌请求或正在演唱的消费者'},
  C:{setting:'同场或跨包厢多人参与，身份和操作顺序可能冲突',assets:['场次与包厢标识','参与者权限','消息与操作日志'],baseline:'单端点歌、原队列和不接收陌生互动的体验',observer:'操作发起者、其他演唱者与被邀请者'},
  D:{setting:'包厢消费者发起服务请求，员工通过门店系统履约',assets:['房态与场次','订单或工单标识','员工接单与履约记录'],baseline:'人工确认、原收银或服务工单处理流程',observer:'发起请求的消费者及实际履约员工'},
  E:{setting:'消费者确认价格、付款或申请售后，门店需核对账务',assets:['价格或权益版本','订单与支付流水','退款和对账记录'],baseline:'原定价、确认支付与人工异常处理流程',observer:'付款消费者、收银员工和门店负责人'},
  F:{setting:'门店拟使用内容或处理消费者相关信息，授权范围尚需核对',assets:['内容或数据目录','对应授权凭证','处理目的、访问及删除记录'],baseline:'不增加采集或传播时可完成的原有服务',observer:'权益相关方、被记录者及操作人员'},
  G:{setting:'营业设备存在版本、网络和负载差异，必须保护演唱主流程',assets:['设备与软件清单','网络故障点','请求标识与运行日志'],baseline:'当前已支持范围内的播放、切歌和恢复行为',observer:'演唱消费者、门店负责人和运维人员'},
  H:{setting:'门店或连锁计划变更配置、部署版本或处理故障',assets:['门店与发布批次','配置和构建版本','值班、回滚与验收记录'],baseline:'变更前仍可营业的已知配置和服务表现',observer:'实施负责人、值班员工与受影响消费者'},
  I:{setting:'门店准备试验新玩法或营销方案，需要区分新增效果和原有生意',assets:['触达与分组记录','业务指标定义','完整成本及退款数据'],baseline:'同口径原有流程或事先定义的对照条件',observer:'门店经营者、运营人员及实际接受体验的消费者'},
  J:{setting:'产品团队在本地评审工具中讨论需求，并回填实际执行结果',assets:['需求修订号','角色发言及引用记录','调用状态与验证回填'],baseline:'原始需求、上一轮有效范围与既有证据状态',observer:'需求提出者、产品负责人及各专业岗位'}
};

// Each entry is authored for one existing case; no new product scope or measured result is added.
const flows=[
  ['消费者点完一首歌','主动开启伴舞，再关闭并切歌','低配设备播放卡顿或歌词被遮挡'],
  ['准备播放一首未验证曲目','播放、变速段、拖动进度与暂停恢复','节拍识别不稳定或重新同步失败'],
  ['消费者提交一张包含人物的照片','确认呈现对象与使用范围，再申请生成并删除','照片中的他人不同意或撤回后仍可访问'],
  ['消费者购买生日祝福','确认播放时间，与正在演唱的人协调后插播','插播打断演唱或购买后未播放'],
  ['员工开启灯光联动','关联当前包厢，触发效果后退出联动','灯控指令异常或影响不属于本场的设备'],
  ['消费者准备剪辑演唱片段','确认拍摄和发布对象，预览后决定分享或删除','同行者入镜或撤回后内容仍可传播'],
  ['消费者用心情描述想唱的歌','澄清描述，展示候选，再由消费者点歌','候选偏题或曲库没有对应歌曲'],
  ['消费者主动哼唱找歌','获得本次输入，返回候选，确认后结束采集','环境噪声误识别或持续录到旁边的人'],
  ['多人加入本场歌单','分别表达偏好，形成候选并允许个人调整','一人的偏好覆盖其他人或退出后仍被引用'],
  ['演唱者尝试音域辅助','采样并给出可撤销的降调建议，由演唱者选择','建议不适合实际唱法或被误当成专业诊断'],
  ['消费者输入方言或模糊歌名','返回候选、允许纠正，再确认具体版本','相似歌名误选或没有候选却假装命中'],
  ['门店准备按演唱评分排比赛名次','限定评分用途，检查样本和设备差异后解释结果','评分受设备或曲目影响却被当成专业能力结论'],
  ['多人扫描同一包厢入口','核对场次身份，并发点歌后确认队列顺序','跨场残留权限、重复提交或队列冲突'],
  ['消费者购买插队资格','明确插队规则及影响，确认支付后更新队列','排队者不知情或付款后未获得对应权益'],
  ['消费者发送匿名弹幕','检查权限与内容，确认显示并提供处置入口','攻击性内容上屏或无法停止显示'],
  ['两间包厢接受远程合唱','建立连接，核对同步，任一方可退出','时延和回声破坏合唱或退出后仍传输'],
  ['一个包厢向陌生包厢发起邀歌','对方确认后建立互动，拒绝或退出即结束','未同意就展示身份或反复打扰'],
  ['同行者触发趣味音效','播放附加音效，演唱者可立即撤销','音效盖住主唱或撤销后状态不恢复'],
  ['消费者用一句话点酒水小食','解析成待确认订单，确认品项数量价格后提交','语音识别错误或重复提交导致多下单'],
  ['消费者询问已付款订单进度','查实际工单状态，解释预计时间并允许人工跟进','没有履约依据却承诺准确送达时间'],
  ['消费者请求更换麦克风','创建服务请求，员工接单、处理并确认完成','无人接单或仅点了完成但问题没有解决'],
  ['消费者申请延长当前包厢时间','核对下一场预约、计费及付款结果后续时','与下一场冲突或扣款成功但时长未更新'],
  ['演唱故障后消费者申请换房','确认可用房间，迁移本场订单和状态并核对','重复计费、错迁订单或原房未正确释放'],
  ['员工结束本场并安排下一场入房','退出账号、清理本场数据，再验证新场隔离','上一场照片、歌单或控制权限残留'],
  ['系统按客流提出包厢新价格','发布前说明新价适用范围，保留已确认订单约定','已确认订单被改价或展示价与结算价不一致'],
  ['消费者查看储值套餐推荐','展示价格、权益和限制，由消费者决定是否购买','只强调收益而隐藏限制或夸大适用性'],
  ['消费者购买一次数字人特效','确认订单、支付、交付及消费状态','重复扣费、权益未到账或播放失败无法核对'],
  ['多人共同支付一笔包厢账单','拆分应付、确认各笔支付，再核对总账','重复回调、部分成功或退款造成账实不符'],
  ['消费者跨门店使用优惠券','核对券范围、叠加规则与结算明细后确认','门店规则不同或系统重复核销'],
  ['消费者提交退款争议','收集订单与事实，给出处理建议并交责任人复核','证据不足或越权自动拒绝合理申诉'],
  ['门店准备把短视频加入曲库','核对内容来源、可用用途及授权后决定收录','公开可看被误当成可商用播放或再分发'],
  ['门店计划开放明星声音合唱','核对声音及相关素材权利范围，再判断能否提供','未确认权益或把生成技术可行当成授权有效'],
  ['门店提出用摄像头分析包厢情绪','核对必要性、受影响对象和可选替代方式','未经确认采集或把推测情绪当成确定事实'],
  ['消费者扫码只想完成点歌','区分本场点歌与可选会员业务，再决定所需信息','不必要的手机号收集阻断基本点歌'],
  ['运营拟按歌曲偏好建立长期画像','核对目的、关联对象、使用及退出方式','本场偏好被当成长久准确画像或退出无效'],
  ['演唱者撤回已分享视频','关闭受控链接，核对缓存及已下载副本的边界','仍能通过受控链接访问或承诺无法保证的全网删除'],
  ['门店询问旧设备能否直接升级','建立兼容范围，验证完整、降级及不支持路径','用旗舰演示代替旧设备验证或隐去升级成本'],
  ['营业中发生网络故障','定位外网、局域网及终端故障边界，再验证可用曲目','把所有断网当成同一种故障或承诺不可达内容'],
  ['消费者用手机控制当前歌曲','按场次与歌曲版本同步，核对指令和显示状态','旧状态覆盖新状态或操作影响错误歌曲'],
  ['消费者提交操作后连接中断','查操作标识和最终状态，再决定是否重试','重复执行扣款、下单或已经完成的操作'],
  ['维护人员准备在演唱中更新特效','检查更新窗口、资源占用和回滚后决定发布时间','热更新阻断演唱或回滚后状态不一致'],
  ['门店准备高峰时开放免费云能力','核对额度、时延、容量和降级后限定使用范围','限流或服务中断导致主流程不可用'],
  ['连锁负责人要求一键部署所有门店','识别差异、验证试点，再分批部署与验收','少数试点通过就跳过门店差异及回滚准备'],
  ['售后要求收集设备诊断包','限定采集字段和接收权限，检查后上传或导出','诊断包包含与故障无关的消费者信息'],
  ['运维拟让AI远程修复营业设备','确认操作权限、影响和恢复方式后执行受限动作','模型误判触发危险修改或营业中无法恢复'],
  ['门店管理员准备发布数字人素材','核对配置权限、内容范围及审核后发布','越过总部规则或误发布到其他门店'],
  ['节假日前准备上线新活动','核对人手、验证、灰度及止损能力后决定窗口','高峰缺值班与回滚能力仍强行发布'],
  ['运营查看AI监控的新玩法报告','核对埋点、故障、负反馈和实际业务记录','模型摘要掩盖实际失败或把热闹当成有效'],
  ['经营者询问数字人能否增加到店','明确增量口径，对照实际到店与投入后判断','没有对照或把原本到店的客人计为新增'],
  ['门店计划售卖包厢主题皮肤','展示实际体验，验证选择、支付和交付意愿','口头喜欢被当作愿意付费或购买后效果不符'],
  ['运营准备向离店消费者发送召回信息','核对允许触达的对象、频率和退出后再执行','打扰未同意接收的人或退出后继续发送'],
  ['运营准备比较两种新玩法','冻结分组、指标和停止规则，再执行并检查差异','分组串扰或看完结果后更换胜负口径'],
  ['门店根据首周数据决定是否续购','分清新鲜感与重复使用，再跟踪约定观察期','把首周试用热度直接当成长久留存'],
  ['产品收到AI汇总的差评需求','回查原文和影响范围，核对重复与反例后排优先级','高频文本被误当高价值或少数严重故障被漏掉'],
  ['团队选择多个角色开始评审','按不同职责读取同一前提，分别提出判断和质询','不同角色重复相同话术或越权替其他岗位担保'],
  ['岗位观点在讨论中被有效反驳','保留原话，记录修正原因和适用条件后复核记忆','把一次模型反驳直接升级为普适事实'],
  ['评审过程中免费模型调用失败','保留已完成记录，说明失败并给出有标记的本地参考','用预置答案冒充模型回复或悄悄切换付费'],
  ['讨论提出超出本次需求的新方向','产品核对范围，另记扩展项并按现有问题收口','为了达成共识不断新增功能和讨论轮次'],
  ['一次评审得分较高但仍存在阻塞','逐项核对依据、风险及条件，再决定是否放行','用总分覆盖缺证据、未解除阻塞或必要岗位缺席'],
  ['需求提出者在讨论中补充新想法','识别新增、保留和撤销项，更新修订并重新评审','只提示收到却不进入讨论，或继续执行被撤销要求']
];
assert.equal(flows.length,60);
const role=key=>ROLE_PERSONAS.find(r=>r.key===key);
const cases=bank.cases.map((item,index)=>{
  const profile=profiles[item.category], [trigger,flow,exception]=flows[index];
  const evidenceId=`${item.id}-E1`,testId=`${item.id}-V1`,taskId=`${item.id}-T1`;
  const participants=[...new Set(['pd',...item.roles,'test'])].map(key=>({key,name:role(key).name,perspective:role(key).professional_view,responsibility:key==='pd'?'确认本次范围、收口并安排补证':key==='test'?'检查反例、验收口径和验证记录':key===item.roles[0]?'提出本专业方案及限制，接收质询':'从本专业视角质询并核对回应',stance:'待讨论，不预填本轮立场'}));
  return {
    case_id:item.id,title:item.title,category:bank.categories[item.category],status:'模拟场景设计，未做门店验证',source_fields:['question','premise','actor','roles','evidence','verify','accept','overturn','mutation','boundary'],
    context:{setting:profile.setting,trigger,affected_actor:item.actor,observer:profile.observer,assets:profile.assets,baseline:profile.baseline,known_facts:[],hypotheses:[item.premise],open_questions:[item.question,`本门店能否提供：${item.evidence}`],out_of_scope:item.boundary},
    participants,
    business_flow:[{step:1,actor:item.actor,action:trigger,expected:'确认实际场次、对象及本次请求',status:'待核实'},{step:2,actor:item.actor,action:flow,expected:item.accept,status:'待验证'},{step:3,actor:role(item.roles[0]).name,action:`遇到“${exception}”时停止扩大承诺，按已有安全边界处理`,expected:item.overturn,status:'待验证'}],
    evidence_requirements:[{id:evidenceId,owner:item.roles[0],required:item.evidence,status:'未提供',provenance:'需要现场原始记录，不接受模型意见代替',record_schema:{source_uri:null,collector:null,collected_at:null,store_id:null,session_id:null,device_or_build:null,applicable_scope:null,observed_result:null,reviewer:null}}],
    validation:{id:testId,owner:'test',baseline:profile.baseline,method:item.verify,success:item.accept,falsifier:item.overturn,exception,required_evidence:[evidenceId],thresholds:{status:'待责任岗位在测试前确认',rule:'原题未给数值时，不编造时延、成功率、样本量或商业门槛；适用阈值须预先冻结',value:null,unit:null,sample_plan:null,approved_by:null},execution:{status:'未执行',actual:null,evidence_ids:[],checked_by:null,checked_at:null}},
    discussion:{max_rounds:1,lead:item.roles[0],challenger:item.roles[1],question:item.challenge,reference_response:item.response,unresolved_action:'保留未决项，安排最小补证动作后收口；不让角色互相赞同替代证据',source:'题库参考，不是本轮模型发言'},
    decision:{rules:['R1：依据及必要岗位齐备','R2：过程分至少75且无未解除阻塞','R3：条件验证及分歧闭环'],pass:{condition:item.accept,prerequisites:['本次范围确认','适用验收标准事先确定','所需证据完成核验','无未解除阻塞风险'],result:'仅允许在已验证范围内推进'},reject:{condition:item.overturn,result:'不通过，并记录触发证据及修复动作'},defer:{condition:'缺原始证据、标准未确定、模型失败或分歧未闭环',result:'本轮不通过（待补证），不等同于功能不可行'},current_result:'未执行，尚无评审结论'},
    artifacts:{order:['score','risk','todo','prd'],score:{weights:SCORE_POLICY.weights,total:null,meaning:'过程证据分，未经执行不预填分数'},risk:{text:exception,level:item.risk.level,impact:item.risk.impact,owner:item.roles[0],status:'参考风险，是否适用待核实',evidence_ids:[evidenceId],merge_rule:'相同问题归并但保留岗位依据；有差异不得直接合并'},tasks:[{id:taskId,owner:item.roles[0],item:`补齐本场景的原始资料：${item.evidence}`,priority:item.risk.impact==='阻塞'?'高':'中',due:'重新评审前，具体日期由责任人确认',done_when:'资料明确来源、适用版本及范围，并经责任岗位核对',evidence_ids:[evidenceId],status:'待确认适用性'},{id:`${item.id}-T2`,owner:'test',item:item.verify,priority:'高',due:'放行前，具体日期由责任人确认',done_when:item.accept,validation_id:testId,status:'未执行'}],prd_sections:{功能概述:item.question,业务流程:flow,前置条件:item.premise,功能规则:item.reply,异常处理:item.response,开发分工:`${role(item.roles[0]).name}提出本专业方案，${role(item.roles[1]).name}交叉核对；正式排期前补证`,运营配置:'本题没有明确的配置项不作预填，由运营按本次范围补齐',交付售后:`记录${exception}的发现、处理与恢复责任；现场流程待确认`,风险清单:exception,验收标准:item.accept}},
    follow_up:{input:item.mutation,expected_revision:item.updated_reply,invalidates:['受影响的范围映射','旧条件验证','相关风险解除状态','受影响执行任务'],reopen_when:`取得${item.evidence}，或需求提出者明确改变范围`,owner:'pd',preserve:['原始输入','原始角色发言','旧结论及其依据']},
    learning:{candidate:item.reasoning,counterexample:item.overturn,status:'未核验参考，不作为已确认经验',confirmation_requires:['实际结果及原始记录','适用场景与版本','独立责任人核对','记录失败或反例'],withdrawal:'证据撤回或反例成立时，停止引用并重新评审相关结论'}
  };
});
const output={version:'1.0',source_sha256:crypto.createHash('sha256').update(source).digest('hex'),status:'60条模拟场景设计；未执行模型或门店验证',cases};
for(const item of cases){assert.equal(item.participants.length,new Set(item.participants.map(r=>r.key)).size);assert.equal(item.artifacts.order.length,4);assert.equal(Object.keys(item.artifacts.prd_sections).length,10);assert.ok(item.artifacts.tasks.every(t=>role(t.owner)));assert.equal(item.context.known_facts.length,0);assert.equal(item.validation.execution.status,'未执行');}
fs.writeFileSync(new URL('ktv-scenario-foundation-60.json',directory),JSON.stringify(output,null,2)+'\n');
const text=['# KTV 60条场景底层资料与闭环','',output.status,'','每条独立包含：现场与对象、范围与未知、岗位职责、业务流程、证据记录、正反验证、有限讨论、判定分支、四项交付、变更重审、执行回填、监督纠正。所有资料是模拟设计，未伪造门店、样本、阈值、实测或通过结果。','',...cases.flatMap(c=>[`## ${c.case_id} ${c.title}`,`场景：${c.context.setting}\n触发：${c.context.trigger}\n具体对象：${c.context.affected_actor}\n待核实前提：${c.context.hypotheses.join('；')}\n范围：${c.context.out_of_scope}`,`### 岗位与流程\n${c.participants.map(r=>`- ${r.name}：${r.responsibility}；关注${r.perspective}`).join('\n')}\n${c.business_flow.map(s=>`${s.step}. ${s.action}`).join('\n')}`,`### 证据与交叉验证\n证据编号：${c.evidence_requirements[0].id}\n需提供：${c.evidence_requirements[0].required}\n质询：${c.discussion.question}\n参考回应：${c.discussion.reference_response}\n方法：${c.validation.method}\n接受条件：${c.validation.success}\n推翻条件：${c.validation.falsifier}\n阈值与样本：尚需事先确认，不填虚构数值。`,`### 判定与交付\n${c.decision.rules.join('；')}\n缺证据时：${c.decision.defer.result}\n四项顺序：${c.artifacts.order.join(' → ')}\n${c.artifacts.tasks.map(t=>`- ${role(t.owner).name}：${t.item}；完成标准：${t.done_when}；期限：${t.due}`).join('\n')}`,`### 变更与回填\n新输入：${c.follow_up.input}\n需要修正：${c.follow_up.expected_revision}\n重审触发：${c.follow_up.reopen_when}\n实际执行状态：${c.validation.execution.status}；回填原始结果与来源后再判断，不把模型共识当事实。`,''])];
const introduction=[
  '# KTV 60条场景底层资料与闭环',
  output.status,
  '每条包含12类底层资料：现场与对象、范围与未知、岗位职责、业务流程、证据记录、正反验证、有限讨论、判定分支、四项交付、变更重审、执行回填、监督纠正。案例帮助发现问题，不能证明门店事实，也不能作为模型实时发言或放行证据。',
  '覆盖10类场景，每类6条：舞台与数字人、找歌与演唱、多人互动、门店服务、交易支付、内容与数据权益、设备与网络、部署运维、增长验证、评审工具。60条是当前覆盖基线，不代表行业所有问题已穷尽。',
  '使用顺序：确认案例适用性 → 明确本轮范围 → 岗位建议与质询 → 有限收口 → 智能评测 → 风险看板 → 待办任务 → 交付文档 → 回填真实记录 → 产品组织重审 → 人工确认或撤回经验。资料不足也要给出不通过原因及补证任务。',
  '真实场景必须补充：门店/场次、设备与软件版本、适用范围、原始来源、采集人与时间、测试前确定的阈值和样本计划、实际观察、核对人。涉及交易、授权或信息处理时，补充相应流水及权利范围。当前这些字段没有真实数据，不编造数值，不预填通过。'
];
const chapters=cases.map(c=>[
  `## ${c.case_id} ${c.title}`,
  `### 现场与边界\n场景：${c.context.setting}\n触发：${c.context.trigger}\n具体对象：${c.context.affected_actor}\n观察对象：${c.context.observer}\n资产与版本：${c.context.assets.join('、')}\n对照流程：${c.context.baseline}\n待核实前提：${c.context.hypotheses.join('；')}\n待确认：${c.context.open_questions.join('；')}\n范围：${c.context.out_of_scope}`,
  `### 岗位与流程\n${c.participants.map(r=>`- ${r.name}：${r.responsibility}；关注${r.perspective}`).join('\n')}\n\n${c.business_flow.map(s=>`${s.step}. ${s.actor}：${s.action}（${s.status}）`).join('\n')}\n\n异常分支：${c.validation.exception}`,
  `### 证据与交叉验证\n证据编号：${c.evidence_requirements[0].id}\n责任岗位：${role(c.evidence_requirements[0].owner).name}\n需提供：${c.evidence_requirements[0].required}\n状态：${c.evidence_requirements[0].status}\n质询：${c.discussion.question}\n参考回应：${c.discussion.reference_response}\n验证编号：${c.validation.id}\n方法：${c.validation.method}\n接受条件：${c.validation.success}\n推翻条件：${c.validation.falsifier}\n阈值与样本：${c.validation.thresholds.rule}`,
  `### 判定与收口\n${c.decision.rules.join('；')}\n通过前提：${c.decision.pass.prerequisites.join('、')}\n通过后：${c.decision.pass.result}\n不通过：${c.decision.reject.condition}；${c.decision.reject.result}\n缺证据时：${c.decision.defer.result}\n最多${c.discussion.max_rounds}轮质询与回应；${c.discussion.unresolved_action}`,
  `### 四项交付\n依次完成智能评测、风险看板、待办任务、交付文档。分数未执行不预填。\n参考风险：${c.artifacts.risk.text}（${c.artifacts.risk.level} / ${c.artifacts.risk.impact}，${c.artifacts.risk.status}）\n\n${c.artifacts.tasks.map(t=>`- ${t.id} / ${role(t.owner).name}：${t.item}\n  完成标准：${t.done_when}\n  期限：${t.due}；关联：${(t.evidence_ids || [t.validation_id]).join('、')}；${t.status}`).join('\n')}`,
  `### PRD参考（待确认适用性）\n${Object.entries(c.artifacts.prd_sections).map(([name,value])=>`- ${name}：${value}`).join('\n')}`,
  `### 变更、执行回填与经验\n新输入：${c.follow_up.input}\n需要修正：${c.follow_up.expected_revision}\n失效项：${c.follow_up.invalidates.join('、')}\n重审触发：${c.follow_up.reopen_when}\n保留：${c.follow_up.preserve.join('、')}\n实际执行状态：${c.validation.execution.status}；回填原始结果与来源后再判断。\n候选经验：${c.learning.candidate}\n反例：${c.learning.counterexample}\n确认要求：${c.learning.confirmation_requires.join('、')}\n当前状态：${c.learning.status}\n撤回条件：${c.learning.withdrawal}`
].join('\n\n'));
fs.writeFileSync(new URL('KTV60条场景底层资料与闭环.md',directory),[...introduction,...chapters].join('\n\n')+'\n');
console.log(JSON.stringify({passed:true,scenario_count:cases.length,task_count:cases.reduce((n,c)=>n+c.artifacts.tasks.length,0),prd_sections:600,external_calls:0,field_validation:'not_run'}));
