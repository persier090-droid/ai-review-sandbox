import test from 'node:test';
import assert from 'node:assert/strict';
import {routeQuestions} from './review-routing.mjs';
import {scenePolicy,assessScene} from './review-scene.mjs';
import {loadRoleSkill} from './expert-skills.mjs';

const roles=['pd','client','server','h5','test','op','service','project','sales'].map(key=>({key,name:key}));
test('role routing separates scene-specific responsibility and never invents participation',()=>{
  const ktv=routeQuestions('KTV点歌机','断网后继续点歌播放，恢复网络不能重复加歌',roles);
  assert.equal(ktv.issues.find(i=>i.id==='offline').lead,'client');
  const saas=routeQuestions('saas','租户隔离并限制跨租户访问',roles);
  assert.equal(saas.issues[0].lead,'server');
  assert.equal(saas.issues[0].challenger,'test');
  const missing=routeQuestions('saas','租户隔离并限制跨租户访问',roles.filter(r=>r.key!=='server'));
  assert.equal(missing.issues[0].lead,null);
  assert.ok(missing.issues[0].missing_roles.includes('server'));
  assert.equal(routeQuestions('app','想做一个新的功能',roles).issues[0].id,'clarify');
});
test('matching quotes are traceable and custom roles do not inherit technical authority',()=>{
  const text='支付回调重试时不能重复扣款';
  const route=routeQuestions('app',text,[{key:'custom',name:'运营顾问',professional_view:'支付体验'},...roles]);
  assert.equal(route.issues[0].lead,'server');
  assert.ok(route.issues.every(i=>text.includes(i.quote)));
});
function fixture(type='requirement') {
  const review={scene:'ktv',review_type:type,revision:1,roles,requirement:'点歌机新增舞蹈但不影响原来的点歌播放',inputs:['点歌机新增舞蹈但不影响原来的点歌播放'],scene_policy:scenePolicy('ktv')};
  review.conclusion={scene_checks:review.scene_policy.checks.map(c=>({id:c.id,owner:c.owners[0],scope_quote:review.requirement,criterion:'开关关闭后恢复原有点歌播放且无残留',method:'逐项执行开关与异常用例并记录对照结果',failure_condition:'失败则关闭新功能并回退既有流程'}))};
  return review;
}
test('five scenes have distinct gates; defined plans do not masquerade as delivery evidence',()=>{
  assert.equal(new Set(['ktv','car','saas','app','web'].map(s=>scenePolicy(s).checks[0].id)).size,5);
  assert.equal(scenePolicy('Web管理平台｜运营后台').scene,'web');
  assert.equal(assessScene(fixture()).passed,true);
  assert.equal(assessScene(fixture('delivery')).passed,false);
  const absent=fixture(); delete absent.conclusion.scene_checks;
  assert.ok(assessScene(absent).checks.every(c=>!c.plan_valid));
  const legacy=fixture(); delete legacy.scene_policy; delete legacy.conclusion.scene_checks;
  assert.equal(assessScene(legacy).passed,false);
});
test('verification is bound to exact scope and criteria; duplicates and fake evidence cannot pass',()=>{
  const r=fixture('quality');
  r.scene_verifications=assessScene(r).checks.map(c=>({contract_key:c.contract_key,status:'通过',evidence:'测试记录 TEST-123，版本1，逐条执行并保留日志',source:'human'}));
  assert.equal(assessScene(r).passed,true);
  r.conclusion.scene_checks[0].criterion='新版本必须满足新的行为和性能限制';
  assert.equal(assessScene(r).passed,false);
  r.conclusion.scene_checks.push({...r.conclusion.scene_checks[1]});
  assert.equal(assessScene(r).checks[1].plan_valid,false);
  const fake=fixture('delivery');fake.conclusion.scene_checks.forEach(c=>Object.assign(c,{status:'通过',evidence:'模型宣称完成验收'}));
  assert.equal(assessScene(fake).passed,false);
});
test('ownership must be selected and professionally responsible; unrelated quotes are rejected',()=>{
  const r=fixture();r.conclusion.scene_checks[0].owner='sales';
  r.conclusion.scene_checks[1].scope_quote='这是完全无关的历史需求';
  assert.equal(assessScene(r).passed,false);
  assert.ok(assessScene(r).checks.slice(0,2).every(c=>!c.plan_valid));
});
test('operations and service have detailed skills and non-KTV skills avoid KTV-only requirements',()=>{
  for(const role of ['op','service'])assert.ok(loadRoleSkill(role,'ktv').includes('验证'));
  assert.ok(loadRoleSkill('server','saas').includes('租户'));
  assert.ok(!loadRoleSkill('server','saas').includes('包厢'));
});
