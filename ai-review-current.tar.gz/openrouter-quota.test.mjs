import test from 'node:test';
import assert from 'node:assert/strict';
import {createQuotaGuard} from './openrouter-quota.mjs';

const response=(remaining,status=200)=>new Response(JSON.stringify({data:{is_free_tier:true,limit_remaining:100,free_model_daily_requests:{used:50-remaining,limit:50,remaining}}}),{status});
test('daily request quota is distinct from money; insufficient budget never starts inference',async()=>{
  let calls=0;
  const guard=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:'test',fetchImpl:async()=>{calls++;return response(2);},now:()=>Date.parse('2026-09-20T14:00:00Z')});
  await assert.rejects(guard.ensure(5),e=>e.code==='FREE_QUOTA_INSUFFICIENT'&&e.remaining===2&&e.required_requests===5);
  await guard.ensure(2);
  assert.equal(calls,1);
  const status=await guard.inspect();assert.equal(status.reset_at,'2026-09-21T00:00:00.000Z');
  guard.recordAttempt();guard.recordAttempt();
  await assert.rejects(guard.ensure(1),/今日免费请求剩余0次/);
});
test('authentication problems are actionable; unavailable status is not misreported as zero quota',async()=>{
  const invalid=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:'test',fetchImpl:async()=>response(0,401)});
  await assert.rejects(invalid.ensure(1),e=>e.code==='OPENROUTER_AUTH');
  const unavailable=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:'test',fetchImpl:async()=>{throw new Error('offline');}});
  assert.equal((await unavailable.inspect()).state,'unknown');
  await unavailable.ensure(1);
  const missing=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:''});
  await assert.rejects(missing.ensure(1),e=>e.code==='OPENROUTER_AUTH');
});
test('malformed counters never pass as real quota and refresh picks up restored quota',async()=>{
  let remaining=0;
  const guard=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:'test',fetchImpl:async()=>response(remaining)});
  await assert.rejects(guard.ensure(5));remaining=50;
  assert.equal((await guard.inspect({force:true})).remaining,50);await guard.ensure(5);
  remaining='invalid';assert.equal((await guard.inspect({force:true})).state,'unknown');
});
