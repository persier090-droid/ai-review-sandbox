import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {ReviewStore} from './review-store.mjs';
import {ROLE_PERSONAS} from './role-personas.mjs';
import {createManualPackage,importManualReply,readManualPackage} from './review-manual.mjs';
import {manualReply} from './tests/manual-fixture.mjs';
import {runReview} from './review-runtime.mjs';

const input={scene:'KTV点歌机',requirement:'KTV点歌机新增数字人跳舞功能，点歌后展示舞蹈，保持点歌操作可用',roles:ROLE_PERSONAS};
function setup(t) {
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'manual-review-'));
  t.after(()=>fs.rmSync(directory,{recursive:true,force:true}));
  return new ReviewStore(directory);
}
test('export includes selected personas, original input and reply contract, survives restart without a review',t=>{
  const store=setup(t),bundle=createManualPackage(store,input);
  assert.equal(store.reviews.size,0);
  assert.ok(bundle.prompt.includes(input.requirement));
  assert.ok(bundle.prompt.includes('counterargument'));
  for(const role of ROLE_PERSONAS) assert.ok(bundle.prompt.includes(role.professional_view));
  assert.equal(readManualPackage(new ReviewStore(store.directory),bundle.id).prompt,bundle.prompt);
});
test('valid imported review runs all stages, preserves text and fills four artifacts without remote calls',async t=>{
  const store=setup(t),bundle=createManualPackage(store,input),reply=manualReply(bundle),raw='```json\n'+JSON.stringify(reply)+'\n```';
  const imported=await importManualReply(store,bundle.id,raw);
  const record=store.get(imported.result.review_id);
  assert.equal(record.role_results.length,9);
  assert.equal(record.import_source.raw,raw);
  assert.equal(record.usage.remote_calls,0);
  assert.equal(record.messages.find(m=>m.phase==='ROUND_SPEAK').text,reply.stages[1].output.text);
  assert.deepEqual(imported.events.filter(e=>e.type==='artifact').map(e=>e.stage),['score','risk','todo','prd']);
  assert.equal(record.artifacts.score.verdict,'不通过');
  assert.match(record.artifacts.prd.markdown,/人工导入/);
  const duplicate=await importManualReply(store,bundle.id,raw);
  assert.equal(duplicate.result.review_id,record.id);
  assert.equal(store.get(record.id).revision,1);
});
test('malformed, mismatched, missing and untraceable replies never create a formal record',async t=>{
  const store=setup(t),bundle=createManualPackage(store,input);
  await assert.rejects(importManualReply(store,bundle.id,'半段回复'),/JSON/);
  for(const mutate of [r=>r.package_id='wrong',r=>r.stages.pop(),r=>r.stages[1].output.analysis.basis[0].quote='伪造的设备全部验收依据',r=>r.stages[1].output.text='已实测全部设备零故障',r=>r.stages.push(r.stages[1]),r=>r.stages.find(s=>s.phase==='ROUND_CHALLENGE').output.acknowledgements=[]]) {
    const reply=manualReply(bundle);mutate(reply);
    await assert.rejects(importManualReply(store,bundle.id,JSON.stringify(reply)));
    assert.equal(store.reviews.size,0);
  }
});
test('continuation exports context, rejects stale package and preserves previous results on failure',async t=>{
  const store=setup(t),bundle=createManualPackage(store,input);
  const first=await importManualReply(store,bundle.id,JSON.stringify(manualReply(bundle)));
  const original=store.get(first.result.review_id);
  const next=createManualPackage(store,{...input,review_id:original.id,change:'取消数字人跳舞功能，仅保留静态背景，不能影响点歌'});
  assert.ok(next.prompt.includes(original.messages.find(m=>m.phase==='ROUND_SPEAK').text));
  await assert.rejects(importManualReply(store,next.id,'{}'));
  assert.deepEqual(store.get(original.id),original);
  store.learn(original.id,{kind:'纠正',text:'当前仅有单店终端',evidence:'需求负责人补充'});
  await assert.rejects(importManualReply(store,next.id,JSON.stringify(manualReply(next))),/变化|过期/);
});
test('additional custom roles use local validation without consuming the API call budget',async t=>{
  const store=setup(t),roles=[...ROLE_PERSONAS,{key:'custom-access',name:'无障碍顾问'},{key:'custom-light',name:'灯光顾问'}];
  const bundle=createManualPackage(store,{...input,roles});
  const {result}=await importManualReply(store,bundle.id,JSON.stringify(manualReply(bundle)));
  assert.equal(result.role_results.length,11);
  assert.equal(result.usage.remote_calls,0);
});
test('case preparation can continue into real imported discussion without inventing a user change',async t=>{
  const store=setup(t);
  const first=await runReview({request:{...input,reference_only:true},basePrompt:'',store,emit:()=>{},call:async()=>{throw Error('should never call');}});
  assert.equal(first.artifacts.score.verdict,'待讨论');
  const bundle=createManualPackage(store,{...input,review_id:first.review_id,resume_discussion:true,change:''});
  assert.equal(bundle.request.change,input.requirement);
  assert.ok(bundle.prompt.includes('KTV-001'));
  const {result}=await importManualReply(store,bundle.id,JSON.stringify(manualReply(bundle)));
  assert.equal(result.review_id,first.review_id);assert.equal(result.revision,2);
  assert.equal(result.artifacts.score.decision_status,'reviewed');
  assert.equal(result.role_results.length,9);
  assert.equal(result.inputs.at(-1),input.requirement);
});
