# Lark Sheet Workbook

## 使用场景

查看飞书表格的工作簿结构与版本号。本 reference 覆盖 2 个只读 shortcut：

| 操作需求 | 使用工具 | 说明 |
|---------|---------|------|
| 查看工作簿结构 | `+workbook-info` | 获取子表列表、名称、行列数、可见性等元数据 |
| 获取当前 revision | `+revision-get` | 获取当前文档 revision（版本号），可作为 `+changeset-get` 复核的版本锚点 |

注意：

- **获取结构是第一步**：任何表格操作前必须先调用 `+workbook-info`，不要跳过直接操作。返回的行列数、子表列表是后续所有操作的基础
- **优先使用 `sheet_id`**：从 `+workbook-info` 返回值中精确获取 `sheet_id`（稳定标识符），不要手动拼写或从 URL 中猜测
- 若 `+workbook-info` 返回包含 `warning_message`，说明部分 `sheet_id` 已失效（被删除/改名或输入错误），应停止复用这些 id，重新不带 `sheet_ids` 全量获取结构后再继续操作
- **导入 / 导出属文件级写操作，当前沙箱不可用**：把本地 `.xlsx` / `.xls` / `.csv` 导入成新的飞书电子表格（或导成多维表格 bitable）、导出下载工作簿，当前沙箱均不可用（lark-drive 域仅开放只读查询，不含导入 / 导出能力）；不要用本 skill 或其它域命令替代。

## Shortcuts

| Shortcut | Risk | 分组 |
| --- | --- | --- |
| `+workbook-info` | read | 工作簿 |
| `+revision-get` | read | 工作簿 |

## Flags

### `+workbook-info`

_公共：URL/token（无 sheet 定位） · 系统：`--dry-run`_

_仅含公共 / 系统 flag。_

### `+revision-get`

_公共：URL/token（无 sheet 定位） · 系统：`--dry-run`_

_仅含公共 / 系统 flag。_

## Examples

公共定位：所有 shortcut 顶部排列 `--url` / `--spreadsheet-token`（XOR，二选一，无 sheet 定位）。

### `+workbook-info`

```bash
lark-cli sheets +workbook-info --url "https://example.feishu.cn/sheets/shtXXX"
```

输出契约：返回 `sheets[]`，每个含 `sheet_id` / `title`（工作表显示名；旧 payload 用 `sheet_name`，读取时优先取 `title`、缺失再回退 `sheet_name`）/ `index` / `resource_type` / `row_count` / `column_count` / `is_hidden`，以及计数字段 `merged_cells_count` / `chart_count` / `pivot_table_count` / `float_image_count`（无 `frozen_*` 字段，冻结信息请用 `+sheet-info` 读取）。是操作飞书表格的第一步——任何后续 sheet 级动作都需要先拿这里的 sheet_id。

> **子表类型 `resource_type`**：`sheet`（普通网格子表）/ `bitable`（内嵌的多维表格子表）/ `#UNSUPPORTED_TYPE`（其它暂不支持的嵌入子表）。
> - 网格类读取（读单元格 / 区域 / 样式 / CSV / 对象配置等）**仅适用于 `sheet`**。对 `bitable` / `#UNSUPPORTED_TYPE` 子表执行网格操作会被直接拒绝并返回明确报错。
> - 要读 `bitable` 子表里的数据：该子表条目会附带 `bitable_app_token` + `bitable_table_id` 两个字段，直接用多维表格命令操作，例如 `lark-cli base +record-list --base-token <bitable_app_token> --table-id <bitable_table_id>`。不要走 sheets 网格命令。
> - `bitable` / `#UNSUPPORTED_TYPE` 子表条目**只含** `sheet_id` / `sheet_name` / `index` / `resource_type`（bitable 另加上述两个 token）以及 `is_hidden` / `tab_color`；**不输出** `row_count` / `column_count` / 各类 `*_count` / `frozen_*` 等网格指标（对非网格子表无意义）。

### `+revision-get`

```bash
lark-cli sheets +revision-get --url "https://example.feishu.cn/sheets/shtXXX"
```

输出契约：返回单个 `revision` 字段，即当前文档版本号。它是 `+changeset-get` 的版本锚点：如果刚执行过一次读操作，也可以直接复用那次响应里的 `revision`；当只想单独取当前版本号、且不需要其它结构信息时，用 `+revision-get` 最直接。

### Validate / DryRun / Execute 约束

- `Validate`：`--url` / `--spreadsheet-token` XOR 必填。
- `DryRun`：输出请求模板，零网络副作用。
- `Execute`：发起工作簿结构 / revision 查询。
