import {spawnSync} from 'node:child_process';
import fs from 'node:fs';
import {fileURLToPath} from 'node:url';
import {sourceFingerprint} from './source-fingerprint.mjs';
import {releaseChecks} from '../review-readiness.mjs';
const cwd=fileURLToPath(new URL('../',import.meta.url));
const stages=[
  {name:'免费额度与预检',args:['--test','openrouter-quota.test.mjs','deepseek.test.mjs']},
  {name:'单元与规则门禁',args:['--test','server.test.mjs','review-runtime.test.mjs','review-context.test.mjs','review-delivery.test.mjs','review-policy.test.mjs','review-local-reference.test.mjs','review-case-library.test.mjs','review-grounding.test.mjs','review-manual.test.mjs','review-automatic.test.mjs','review-store.test.mjs','review-readiness.test.mjs','review-scene.test.mjs','review-module-contract.test.mjs']},
  {name:'本地恢复与异常输入',args:['scripts/check-local-resilience.mjs']},
  {name:'专业资料结构校验',args:['scripts/validate-skills.mjs']},
  {name:'岗位实务与引用隔离',args:['--test','skill-library.test.mjs']},
  {name:'60条场景资料与闭环引用校验',args:['scripts/validate-ktv-scenarios.mjs']},
  {name:'1000条多场景资料可重建校验',args:['scripts/build-review-cases.mjs','--check']},
  {name:'留出题结构与输入隔离校验',args:['scripts/benchmark-ktv-variants.mjs','--self-test']},
  {name:'产品验收与故障恢复',args:['scripts/check-product-browser.mjs']},
  {name:'多场景离线检索与唯一入口',args:['scripts/check-multiscene-browser.mjs']},
  {name:'网页模型协作操作闭环',args:['scripts/check-manual-browser.mjs']},
  {name:'整轮AI调用与重试闭环',args:['scripts/check-automatic-browser.mjs']}
];
const report={at:new Date().toISOString(),stages:[],local_acceptance:'pending',production_readiness:'blocked_pending_live_model_review',note:'隔离上游只验证产品流程；真实免费模型完整评审通过前，不宣称生产可用性已验证。'};
report.source=sourceFingerprint();
fs.mkdirSync(new URL('../test-results/',import.meta.url),{recursive:true});
for(const stage of stages) {
  console.log(stage.name);
  const result=spawnSync(process.execPath,stage.args,{cwd,stdio:'inherit',timeout:180000});
  report.stages.push({name:stage.name,passed:result.status===0});
  if(result.status!==0){report.local_acceptance='failed';report.readiness=releaseChecks({localPassed:false,source:report.source});fs.writeFileSync(new URL('../test-results/release-report.json',import.meta.url),JSON.stringify(report,null,2));process.exit(1);}
}
report.local_acceptance='passed';
let live;
try {live=JSON.parse(fs.readFileSync(new URL('../test-results/live-report.json',import.meta.url),'utf8'));report.live={at:live.at,passed:live.passed,source_matches:live.source===report.source};}catch{}
report.readiness=releaseChecks({localPassed:true,live,source:report.source});
if(report.readiness.local_pilot==='passed')report.production_readiness='local_and_live_checks_passed_not_an_availability_guarantee';
fs.writeFileSync(new URL('../test-results/release-report.json',import.meta.url),JSON.stringify(report,null,2));
console.log('本地验收流水线通过；真实模型可用性为独立上线门槛。');
if(process.argv.includes('--production')&&report.production_readiness==='blocked_pending_live_model_review') {
  console.error('上线门禁未通过：当前代码没有最近24小时的真实九岗位完整评审通过记录。不会以模拟数据替代。');process.exitCode=1;
}
