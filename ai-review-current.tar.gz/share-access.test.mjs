import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {Readable} from 'node:stream';
import {createShareAccess,passwordRecord} from './share-access.mjs';

const origin='https://review-test.frp.ktvsky.com';
function req(url='/',{cookie,body='',site=origin,host=new URL(origin).host,method='GET'}={}) {
  const r=Readable.from([body]);r.url=url;r.method=method;r.headers={host,origin:site,cookie,'content-type':'application/x-www-form-urlencoded'};return r;
}
function res(){return {status:0,headers:{},body:'',writeHead(status,headers){this.status=status;this.headers=headers;},end(body=''){this.body=body;}};}
test('sharing protects API and WS and isolates persistent sessions',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-share-test-'));
  let now=Date.now();
  try {
    const options={origin,directory,...passwordRecord('test-password-long-enough'),now:()=>now};
    const gate=createShareAccess(options);
    const loginPage=res();await gate.authorize(req('/'),loginPage);assert.equal(loginPage.headers['referrer-policy'],'same-origin');
    let response=res();assert.equal(await gate.authorize(req('/api/health'),response),null);assert.equal(response.status,401);
    assert.equal(gate.session(req('/ws')),null);
    response=res();await gate.authorize(req('/login',{method:'POST',body:'password=wrong'}),response);assert.equal(response.status,401);
    response=res();await gate.authorize(req('/login',{method:'POST',body:'password=test-password-long-enough',site:'https://evil.example'}),response);assert.equal(response.status,403);
    const login=async()=>{const r=res();await gate.authorize(req('/login',{method:'POST',body:'password=test-password-long-enough'}),r);assert.equal(r.status,303);assert.match(r.headers['set-cookie'],/HttpOnly; Secure; SameSite=Strict/);return r.headers['set-cookie'].split(';')[0];};
    const first=await login(),second=await login();assert.notEqual(first,second);
    const a=gate.session(req('/ws',{cookie:first})),b=gate.session(req('/ws',{cookie:second}));assert.ok(a);assert.ok(b);assert.notEqual(a.directory,b.directory);
    fs.writeFileSync(path.join(a.directory,'private.json'),'private');assert.equal(fs.existsSync(path.join(b.directory,'private.json')),false);
    const restarted=createShareAccess(options);assert.equal(restarted.session(req('/ws',{cookie:first})).directory,a.directory);
    assert.equal(gate.session(req('/ws',{cookie:first,site:'https://evil.example'})),null);
    assert.equal(gate.session(req('/ws',{cookie:first,host:'evil.example'})),null);
    assert.equal(gate.session(req('/ws',{cookie:'review_share=forged'})),null);
    now+=8*24*60*60*1000;assert.equal(gate.session(req('/ws',{cookie:first})),null);
  } finally {fs.rmSync(directory,{recursive:true,force:true});}
});
test('login attempts are bounded and oversized bodies rejected',async()=>{
  const directory=fs.mkdtempSync(path.join(os.tmpdir(),'review-share-rate-'));
  try {
    const gate=createShareAccess({origin,directory,...passwordRecord('test-password-long-enough')});
    let response=res();await gate.authorize(req('/login',{method:'POST',body:'x'.repeat(5000)}),response);assert.equal(response.status,413);
    for(let i=0;i<30;i++){response=res();await gate.authorize(req('/login',{method:'POST',body:'password=wrong'}),response);}
    assert.equal(response.status,429);
  }finally{fs.rmSync(directory,{recursive:true,force:true});}
});
