> 来源：用户补充包。专业断言和认证权重尚未独立核验；运行时覆盖规则见 README.md。

# 评审状态机 review-state-machine

## 用途
定义评审全过程的状态和转换，确保评审可控、可追踪。

## 状态定义
INIT → INTAKE → PRECHECK → AGENDA_SET → ROUND_SPEAK
→ ROUND_ASK → ROUND_RESPOND → ROUND_CHALLENGE
→ CONVERGE → DECISION → RECORD → TRACKING → DONE


## 状态转换表

| 当前状态 | 触发条件 | 下一状态 |
|---|---|---|
| INIT | 议题提出 | INTAKE |
| INTAKE | 议题分类完成 | PRECHECK |
| PRECHECK | 前置检查通过 | AGENDA_SET |
| PRECHECK | 前置检查不通过 | 延期或取消 |
| AGENDA_SET | 议程设定完成 | ROUND_SPEAK |
| ROUND_SPEAK | 主答发言完成 | ROUND_ASK |
| ROUND_ASK | 所有角色提问完成 | ROUND_RESPOND |
| ROUND_RESPOND | 被质询方回应完成 | ROUND_CHALLENGE |
| ROUND_CHALLENGE | 挑战完成 | CONVERGE 或 ROUND_SPEAK（下一子议题） |
| CONVERGE | 共识/分歧记录完成 | DECISION |
| DECISION | 裁决完成 | RECORD |
| RECORD | 记录写入完成 | TRACKING |
| TRACKING | 执行项跟踪启动 | DONE |

## 异常状态

| 状态 | 触发 | 处理 |
|---|---|---|
| MATERIAL_MISSING | 材料不全 | 退回 PRECHECK |
| ROLE_MISSING | 角色缺席 | 延期或指定代理人 |
| NO_CONVERGENCE | 无法收敛 | 强制进入 DECISION |
| DECISION_DEFERRED | 决策延期 | 约定重新评审 |
| EXTERNAL_ESCALATION | 升级外部 | 结束本次评审 |

## 状态持久化

评审状态存储在 memory 中，格式：

review_state:
  review_id: 编号
  current_state: CONVERGE
  history: [INIT, INTAKE, PRECHECK, ...]
  sub_agenda_index: 2
  sub_agenda_total: 5
  round: 2
  elapsed_minutes: 35
  last_action_at: 时间戳
禁止行为

禁止跳过状态
禁止不回退到异常状态
禁止不持久化状态
