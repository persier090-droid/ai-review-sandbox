# Theme: Notebook Tabs

**Vibe:** Editorial, organized, tactile, paper-like

**Best For:** Reports, reviews, documentation

**Typography:**
- Display: `Bodoni Moda` (400/700) — classic editorial serif
- Body: `DM Sans` (400/500) — friendly readable sans

**字体加载（加到 `client/src/tailwind-theme.css`）：**
```css
@import url('https://miaoda.feishu.cn/fonts/css2?family=Bodoni+Moda:wght@400;700&family=DM+Sans:wght@400;500&display=swap');

:root {
  --font-display: 'Bodoni Moda', Georgia, serif;
  --font-sans: 'DM Sans', system-ui, sans-serif;
}
@theme inline {
  --font-display: var(--font-display);
  --font-sans: var(--font-sans);
}
```
_标题用 `className="font-display"`，正文不加字体类。_

**Theme CSS:**
```css
[data-ppt-theme="notebook-tabs"] {
  --ppt-bg: #f5f5f0;
  --ppt-bg-secondary: #ffffff;
  --ppt-text: #1a1a1a;
  --ppt-text-secondary: #666666;
  --ppt-tab-red: #e63946;
  --ppt-tab-blue: #457b9d;
  --ppt-tab-green: #2a9d8f;
  --ppt-tab-yellow: #e9c46a;
  --ppt-border: #e0e0e0;
}
```

**Key Tailwind Classes:**
```tsx
// Paper card
className="bg-[var(--ppt-bg-secondary)] rounded-lg shadow-sm border border-[var(--ppt-border)] p-6"

// Editorial 标题（Bodoni Moda，编辑感强）
className="font-display text-[clamp(1.75rem,5vw,3.5rem)] font-bold leading-tight text-[var(--ppt-text)]"

// Colored tabs
className="absolute -left-2 top-4 w-4 h-20 rounded-r-sm"
// Use different colors: bg-[var(--ppt-tab-red)], bg-[var(--ppt-tab-blue)], etc.

// Section indicator（小字 UI，正文 DM Sans）
className="text-sm font-medium text-[var(--ppt-text-secondary)] uppercase tracking-wider"
```

**Signature Elements:**
- Paper/card aesthetic with subtle shadows
- Colorful section tabs (red, blue, green, yellow)
- Clean grid layout
- Organized, magazine-like feel
