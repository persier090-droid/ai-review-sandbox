import test from 'node:test';
import assert from 'node:assert/strict';
import {deliverReview} from './review-delivery.mjs';
import {validateDiscussionOutput} from './expert-skills.mjs';
import {localCrossChecks} from './review-local-reference.mjs';
import {collectReviewRisks} from './review-risks.mjs';

const requirement='点歌完成后播放数字人舞蹈，包厢消费者可随时关闭';
export function grounded(role='pd') {
  return {role,stance:'支持',stance_reason:'需求明确允许关闭，支持可逆操作设计',stance_conditions:[],text:'【判断】包厢消费者必须能关闭舞蹈。\n【方向】保留歌曲操作。\n【方案】增加关闭入口或默认不开启。\n【风险】舞蹈遮挡点歌控件。\n【验证】检查关闭后歌曲操作是否可达。',references:[],evidence_gap:'没有门店实测；仅根据需求约束提出设计判断',alternatives:[{plan:'手动关闭',cost:'增加控件'},{plan:'默认不开启',cost:'增加开启步骤'}],predictions:[],prediction_gap:'暂无实测基线，不编造性能数值',analysis:{stakeholder:'包厢消费者',claim:'提供可达的关闭入口，保留点歌操作',principle:'操作可逆性：附加展示不应阻断主要任务',reasoning:'需求允许消费者随时关闭，因此播放状态需要保留可操作的关闭入口',counterargument:'若关闭入口遮挡歌曲操作，新增控件反而损害点歌体验',boundary:'仅数字人播放和关闭，不增加付费流程',verification:'在播放状态尝试关闭，检查歌曲操作仍可完成',basis:[{kind:'input',quote:'包厢消费者可随时关闭'}]},risks:[{text:'舞蹈遮挡点歌控件',level:'mid',impact:'消费者无法继续选择歌曲',mitigation:'保留关闭入口并验证触控区域',evidence_quote:'包厢消费者可随时关闭'}]};
}
test('specific stakeholder, traceable premise and counterargument are required for admission',()=>{
  const base=grounded();
  assert.equal(validateDiscussionOutput(base,'pd',[],{},requirement).eligible,true);
  for(const mutate of [v=>v.analysis.stakeholder='用户',v=>v.analysis.basis[0].quote='模型自己说已验证',v=>v.analysis.counterargument='',v=>v.analysis.reasoning='很好']) {
    const value=structuredClone(base);mutate(value);
    assert.equal(validateDiscussionOutput(value,'pd',[],{},requirement).eligible,false);
  }
});
test('natural role replies need no fixed headings or invented alternative plans',()=>{
  const value=grounded();
  value.text='站在包厢消费者的角度，我支持增加可以随时关闭的舞蹈。先验证关闭后还能继续点歌；如果关闭按钮反而遮挡控件，就要重新调整布局。';
  value.alternatives=[];
  assert.equal(validateDiscussionOutput(value,'pd',[],{},requirement).eligible,true);
  value.analysis.counterargument='';
  assert.equal(validateDiscussionOutput(value,'pd',[],{},requirement).eligible,false);
});
test('unsupported completed-test claims in visible speech are not admitted',()=>{
  const value=grounded();
  value.text='包厢消费者：已实测全部设备零故障，可以直接上线。';
  assert.equal(validateDiscussionOutput(value,'pd',[],{},requirement).eligible,false);
});
test('missing discussion publishes preparation drafts in order without a formal verdict',async()=>{
  const review={id:'example',revision:1,requirement,scene:'KTV',roles:[{key:'pd',name:'产品经理'}],discussion_complete:true,role_results:[],role_status:{pd:{status:'thinking',reason:'依据不足'}},precheck:{passed:false,missing_materials:['成功指标'],missing_roles:[]},quality:{decision_ready:false},closure:{summary:'材料不足',next_action:'补齐成功指标',parking_lot:[]},execution:[],conditions:[],inputs:[requirement]};
  const events=[];
  await deliverReview(review,{save:()=>{},emit:e=>events.push(structuredClone(e))});
  assert.deepEqual(events.filter(e=>e.type==='artifact').map(e=>e.stage),['score','risk','todo','prd']);
  assert.equal(review.artifacts.score.verdict,'待讨论');
  assert.equal(review.artifacts.score.score,null);
  assert.ok(Number.isFinite(review.artifacts.score.preliminary.score));
  assert.equal(review.artifacts.score.preliminary.release_authorized,false);
  assert.match(review.artifacts.prd.markdown,/初步验证评分/);
  assert.ok(review.artifacts.todo.items.some(t=>/成本/.test(t.item)));
  assert.ok(review.artifacts.todo.items.every(i=>i.kind==='verification'));
  assert.match(review.artifacts.prd.markdown,/待讨论/);
  assert.doesNotMatch(review.artifacts.prd.markdown,/结论：不通过|触发不通过/);
  assert.doesNotMatch(review.artifacts.prd.markdown,/功能不可行|评审通过，需求可落地/);
  for(const event of events.filter(e=>e.type==='artifact')) {
    const index=['score','risk','todo','prd'].indexOf(event.stage);
    for(const later of ['score','risk','todo','prd'].slice(index+1)) assert.equal(event.workflow[later],'locked');
  }
});
test('delivery cannot run before discussion ends',async()=>{
  await assert.rejects(deliverReview({discussion_complete:false},{save:()=>{},emit:()=>{}}),/讨论尚未结束/);
});
test('duplicate risk descriptions merge across roles without losing different evidence or severity',()=>{
  const a=grounded('pd'),b=grounded('client');b.risks[0].level='high';b.risks[0].impact_tag='阻塞';b.risks[0].mitigation='增加物理关闭入口';
  const items=collectReviewRisks({id:'dedupe',revision:1,roles:[{key:'pd',name:'产品经理'},{key:'client',name:'客户端研发'}],role_results:[a,b]});
  assert.equal(items.length,1);assert.equal(items[0].level,'high');assert.equal(items[0].impact_tag,'阻塞');assert.equal(items[0].owners.length,2);assert.equal(items[0].observations.length,2);
});
test('local case retrieval stays scoped, traceable, and does not fabricate unmatched answers',()=>{
  const review={scene:'KTV',requirement:'KTV点歌机新增数字人跳舞功能',roles:[{key:'pd'},{key:'client'}]};
  const refs=localCrossChecks(review);assert.ok(refs.length>0&&refs.length<=3);assert.equal(refs[0].case_id,'KTV-001');assert.ok(refs.every(r=>r.challenge&&r.response&&r.overturn));
  assert.equal(localCrossChecks({...review,scene:'车载'}).length,0);
  assert.equal(localCrossChecks({...review,requirement:'完全无关的火星探矿'}).length,0);
});
test('approval is grounded in admitted roles and all outputs share the same verdict',async()=>{
  const review={id:'approved',revision:1,requirement,scene:'KTV',roles:[{key:'pd',name:'产品经理'}],discussion_complete:true,role_results:[grounded()],role_status:{pd:{status:'included'}},precheck:{passed:true,missing_materials:[],missing_roles:[]},quality:{decision_ready:true},conclusion:{basis_roles:['pd'],decision:'通过',execution:[{item:'关闭舞蹈',owner:'客户端研发',deadline:'2027-01-01',deliverable:'关闭入口',scope_quote:'包厢消费者可随时关闭'}],summary:'仅实现可关闭的舞蹈展示',reason:'需求明确可随时关闭'},closure:{parking_lot:[],in_scope:[requirement],reopen_when:'取得关闭功能实测记录',next_action:'客户端完成关闭设计'},execution:[{id:'x',revision:1,item:'实现可关闭的舞蹈',owner:'客户端研发',deadline:'2027-01-01',deliverable:'关闭能力',scope_quote:'包厢消费者可随时关闭'}],inputs:[requirement]};
  await deliverReview(review,{save:()=>{},emit:()=>{}});
  for(const stage of ['score','risk','todo','prd']) assert.equal(review.artifacts[stage].verdict,'不通过','older records without scene acceptance cannot silently pass');
  review.roles.push({key:'client',name:'客户端研发'},{key:'server',name:'服务端研发'});
  review.role_results.push(...['client','server'].map(role=>({...grounded(),role})));
  review.conclusion.scene_checks=ktvScenePlans(requirement);
  await deliverReview(review,{save:()=>{},emit:()=>{}});
  for(const stage of ['score','risk','todo','prd']) assert.equal(review.artifacts[stage].verdict,'通过');
  assert.match(review.artifacts.prd.markdown,/包厢消费者/);
  assert.equal(review.artifacts.risk.items[0].source_role,'pd');
  assert.ok(review.artifacts.prd.markdown.includes('操作可逆性'));
});
import {ktvScenePlans} from './tests/scene-fixture.mjs';
