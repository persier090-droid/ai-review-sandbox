import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {buildProviderRequest,buildReviewPrompt,readModelStream} from '../server.mjs';
import {runReview} from '../review-runtime.mjs';
import {ReviewStore} from '../review-store.mjs';
import {ROLE_PERSONAS} from '../role-personas.mjs';
import {createFreeCaller,providerFailure,freeAttemptBudget} from '../free-recovery.mjs';
import {createQuotaGuard} from '../openrouter-quota.mjs';
import {runAutomaticReview} from '../review-automatic.mjs';
import {sourceFingerprint} from './source-fingerprint.mjs';
import {liveReviewChecks} from '../review-readiness.mjs';

const request={scene:'KTV点歌机',roles:[{key:'pd',name:'产品经理'},{key:'sales',name:'销售/售前'},{key:'project',name:'项目实施'},{key:'test',name:'测试工程师'}],requirement:'这是需求评审联调样例，不代表真实门店实测。需求描述：点歌后展示数字人舞蹈，消费者可随时关闭，不新增收费。目标用户：包厢点歌消费者、门店值班员工。成功指标：建议验收要求是关闭舞蹈后可继续点歌，待实际测试确认。竞品对比：仅与现有静态背景方案比较，静态方案没有舞蹈展示，不提供外部竞品数据。不做的后果：保持现有静态背景，不影响原点歌能力。资源估算：样例假设安排一名客户端研发和一名测试，工期需评估，不能作为已承诺交付。只判断是否具备进入小范围设计验证的条件。'};
const dir=fs.mkdtempSync(path.join(os.tmpdir(),'review-live-'));
const full=process.argv.includes('--full');
const single=process.argv.includes('--batched')||process.argv.includes('--single');
if(full){request.roles=ROLE_PERSONAS;request.exploratory=true;}
const maxAttempts=process.argv.includes('--five-requests')?5:single?freeAttemptBudget(request.roles.length):full?18:12;
const quota=createQuotaGuard({baseUrl:'https://openrouter.ai/api/v1',apiKey:process.env.OPENROUTER_API_KEY});
const store=new ReviewStore(dir),audit=[];
let calls=0;
const started=Date.now();
const source=sourceFingerprint();
try {
  const caller=createFreeCaller({model:process.env.OPENROUTER_MODEL || 'openrouter/free',maxAttempts,notify:event=>console.log(JSON.stringify(event)),request:async(model,prompt,signal,options={})=>{
    await quota.ensure(options.minimumRequests || 1,signal);
    quota.recordAttempt();
    calls++;
    const wire=buildProviderRequest({provider:'openrouter',baseUrl:'https://openrouter.ai/api/v1',apiKey:process.env.OPENROUTER_API_KEY,model,reasoningEffort:single?'none':undefined,responseFormat:options.responseFormat,messages:[{role:'system',content:'遵循评审阶段任务，只返回指定JSON对象，不能输出外层messages包装。'},{role:'user',content:prompt}]});
    const response=await fetch(wire.url,{method:'POST',headers:wire.headers,body:wire.body,signal:AbortSignal.any([signal,AbortSignal.timeout(single?75000:45000)])});
    if(!response.ok) throw providerFailure(response.status,response.headers,await response.json().catch(()=>null));
    const info={};let lastProgress=0;
    const raw=await readModelStream(response.body,true,data=>{if(data.model&&!info.model)console.log(JSON.stringify({response_started_ms:Date.now()-started,model:data.model}));if(data.model)info.model=data.model;if(data.usage)info.cost=data.usage.cost;if(Date.now()-lastProgress>15000){lastProgress=Date.now();console.log(JSON.stringify({elapsed_ms:Date.now()-started,characters:data.characters,finish_reason:data.finish_reason}));}});audit.push(info);return raw;
  }});
  const result=await (single?runAutomaticReview:runReview)({request,basePrompt:buildReviewPrompt(request),store,emit:event=>{if(event.type==='status')console.log(JSON.stringify({stage:event.status}));},limits:{maxCalls:full?16:10,maxMs:180000,maxQuestions:2},call:caller});
  const checks=liveReviewChecks(result,audit,request.roles.map(role=>role.key));
  const report={source,at:new Date().toISOString(),elapsed_ms:Date.now()-started,full,transport:single?'batched':'staged',passed:Object.values(checks).every(status=>status==='passed'),checks,calls,verdict:result.artifacts.score.verdict,coverage:result.artifacts.score.coverage,workflow:result.workflow,models:audit,record_directory:dir,role_status:result.role_status,failure:result.failure};
  fs.mkdirSync(new URL('../test-results/',import.meta.url),{recursive:true});fs.writeFileSync(new URL('../test-results/live-report.json',import.meta.url),JSON.stringify(report,null,2));
  console.log(JSON.stringify(report));
  if(!report.passed)process.exitCode=1;
}catch(error){console.log(JSON.stringify({error_type:error.name,record_directory:dir}));process.exitCode=1;}
