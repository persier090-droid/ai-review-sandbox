import crypto from 'node:crypto';

export function scopeText(review) {
  if(review.effective_scope?.status==='pending') return '';
  return review.effective_requirement ?? (review.inputs || [review.requirement || '']).join('\n');
}

export function resolveScope(review, proposed, previous) {
  const latest=review.inputs.at(-1), changed=previous && latest!==previous.inputs.at(-1);
  let active, retired;
  if(!previous) {active=[review.requirement];retired=[];}
  else if(!changed && (previous.effective_scope?.status==='resolved' || review.inputs.length===1)) {
    active=previous.effective_scope?.active?.map(item=>item.quote) || [review.requirement];
    retired=previous.effective_scope?.retired?.map(item=>item.quote) || [];
  } else {
    if(!proposed || proposed.change_quote!==latest || !Array.isArray(proposed.active_quotes) || !proposed.active_quotes.length || !Array.isArray(proposed.retired_quotes)) throw new Error('变更缺少可追溯的当前有效范围，请重新解析后继续');
    active=proposed.active_quotes;retired=proposed.retired_quotes;
  }
  const inputs=review.inputs;
  const restored=quote=>changed&&latest.split(/[，。；\n]/).some(clause=>['恢复','重新启用'].some(verb=>clause.trim()===verb+quote));
  retired=[...new Set([...retired,...(previous?.effective_scope?.retired || []).map(item=>item.quote)])].filter(quote=>!restored(quote));
  const valid=quote=>typeof quote==='string'&&quote.trim().length>=2&&inputs.some(input=>input.includes(quote));
  if(!active.every(valid)||!retired.every(valid))throw new Error('有效范围包含不在原始输入中的内容');
  if(active.some(quote=>retired.some(old=>quote.includes(old))))throw new Error('有效范围与已撤销要求重叠，需澄清后继续');
  if(changed) {
    const prior=previous.effective_scope?.active?.map(item=>item.quote) || [previous.requirement];
    for(const match of latest.matchAll(/(?:取消|撤销|删除|移除|停止|不再|不要)([^，。；\n]+)/g)) {
      const cancelled=match[1].trim();
      if(cancelled.length>=2&&prior.some(q=>q.includes(cancelled))&&active.some(q=>q.includes(cancelled))) throw new Error('已取消的要求仍在有效范围内');
    }
    for(const quote of prior) {
      let remainder=quote;
      for(const part of [...active,...retired].sort((a,b)=>b.length-a.length)) remainder=remainder.split(part).join('');
      remainder=remainder.replace(/(?:需求描述|目标用户|业务场景|前置条件|验收标准)\s*[:：]/g,'').replace(/[\s，。；、：:,.!?！？;]+/g,'');
      if(remainder.length>=2) throw new Error('有效范围遗漏原有要求，必须明确保留或撤销');
    }
  }
  if(changed && !active.some(quote=>latest.includes(quote)) && !retired.length) throw new Error('有效范围没有处理本次变更');
  const locate=quote=>({quote,input_index:inputs.findIndex(input=>input.includes(quote))});
  const current=[...new Set(active)], removed=[...new Set(retired)];
  const key=crypto.createHash('sha256').update(JSON.stringify(current)).digest('hex');
  review.effective_scope={status:'resolved',revision:review.revision,key,active:current.map(locate),retired:removed.map(locate),change_quote:latest,source:'模型提出的原文范围映射，非现场事实核验'};
  review.effective_requirement=current.join('\n');
  return review.effective_scope;
}
