import test from "node:test";
import assert from "node:assert/strict";
import { buildAssertionContext,validateDiscussionOutput } from "./expert-skills.mjs";
import { buildProviderRequest, buildReviewPrompt, buildRoleSkillContext, normalizeModelResponse } from "./server.mjs";

test('a short literal PRD quote reports its exact field and length for targeted repair',()=>{
  const check=validateDiscussionOutput({deliverables:{acceptance:[{text:'验收时确认不会新增收费项目',scope_quote:'不新增收费'}]}},'sales',[],{},'只做本场邀请，不新增收费，不跨包厢。');
  assert.ok(check.exclusion_reasons.some(reason=>/deliverables.acceptance\[0\].scope_quote.*5.*6/.test(reason)));
});

test("buildAssertionContext selects role assertions with source and verification", () => {
  const context = buildAssertionContext(
    [{ key: "test", name: "测试工程师" }, { key: "server", name: "服务端研发" }],
    "评估点歌系统高峰并发和搜索响应时间"
  );

  assert.match(context, /SRE-SLI-test/);
  assert.match(context, /SRE-SLI-server/);
  assert.doesNotMatch(context, /qa-perf-001|qa-perf-002|server-capacity-002/);
  assert.match(context, /来源依据/);
  assert.match(context, /验证方式/);
});

test("buildRoleSkillContext distributes shared protocols and role-specific capabilities", () => {
  const context = buildRoleSkillContext([
    { key: "pd", name: "产品经理" },
    { key: "server", name: "服务端研发" },
    { key: "test", name: "测试工程师" }
  ]);

  assert.match(context, /八步思考/);
  assert.match(context, /不强制固定标题或两个方案/);
  assert.match(context, /学习闭环/);
  assert.match(context, /产品经理.*用户价值/);
  assert.match(context, /服务端研发.*容量估算/);
  assert.match(context, /测试工程师.*弱网/);
  assert.match(context, /交接/);
});

test("buildReviewPrompt includes requirement, scene, roles, and raw discussion history", () => {
  const prompt = buildReviewPrompt({
    scene: "KTV点歌机",
    requirement: "新增数字人舞蹈功能",
    roles: [{ key: "test", name: "测试工程师" }],
    history: [{ role: "test", name: "测试工程师", text: "要覆盖低配机型" }],
    change: "增加断网兜底",
    reasoning: "高"
  });

  assert.match(prompt, /新增数字人舞蹈功能/);
  assert.match(prompt, /KTV点歌机/);
  assert.match(prompt, /测试工程师/);
  assert.match(prompt, /要覆盖低配机型/);
  assert.match(prompt, /增加断网兜底/);
  assert.match(prompt, /解析/);
  assert.match(prompt, /依赖/);
  assert.match(prompt, /继续讨论/);
});

test("normalizeModelResponse preserves model message text and extracts review data", () => {
  const result = normalizeModelResponse(JSON.stringify({
    messages: [{ role: "test", name: "测试工程师", text: "原样保留：低配机型需要专项压测。" }],
    questions: [{ text: "最低支持机型是什么？", level: "high", category: "test", owner: "测试工程师" }],
    risks: [{ text: "低配机型可能卡顿。", level: "high", category: "test", owner: "测试工程师" }]
  }));

  assert.equal(result.messages[0].text, "原样保留：低配机型需要专项压测。");
  assert.equal(result.questions[0].owner, "测试工程师");
  assert.equal(result.risks[0].level, "high");
});

test("buildProviderRequest creates an OpenRouter streaming request without local model storage", () => {
  const request = buildProviderRequest({
    provider: "openrouter",
    baseUrl: "https://openrouter.ai/api/v1",
    apiKey: "test-key",
    model: "openrouter/free",
    messages: [{ role: "user", content: "继续解析这条变更" }]
  });

  assert.equal(request.url, "https://openrouter.ai/api/v1/chat/completions");
  assert.equal(request.headers.authorization, "Bearer test-key");
  assert.deepEqual(JSON.parse(request.body), {
    model: "openrouter/free",
    messages: [{ role: "user", content: "继续解析这条变更" }],
    stream: true,
    max_tokens: 8192,
    stream_options: {include_usage:true},
    temperature: 0.2,
    provider: {max_price:{prompt:0,completion:0,request:0,image:0}},
    plugins: [],
    response_format: {type:'json_object'}
  });
});

test('free-only policy rejects paid models and paid automatic routing before any request', () => {
  for (const model of ['openrouter/auto','openrouter/auto:free','openai/gpt-4o','test/paid']) {
    assert.throws(()=>buildProviderRequest({provider:'openrouter',baseUrl:'https://openrouter.ai/api/v1',apiKey:'fixture',model,messages:[]}),/仅允许/);
  }
});
test('pinned free model keeps the zero price ceiling and has no paid fallback',()=>{
  const wire=buildProviderRequest({provider:'openrouter',baseUrl:'https://openrouter.ai/api/v1',apiKey:'fixture',model:'google/gemma-4-31b-it:free',messages:[]});
  const body=JSON.parse(wire.body);
  assert.deepEqual(body.provider.max_price,{prompt:0,completion:0,request:0,image:0});
  assert.equal(body.models,undefined);
  assert.deepEqual(body.plugins,[]);
});

test('terminal SSE marker completes the reply even when the provider keeps the connection open',{timeout:200},async()=>{
  let cancelled=false;
  const body=new ReadableStream({start(controller){controller.enqueue(new TextEncoder().encode('data: {"choices":[{"delta":{"content":"完整回复"}}]}\n\ndata: [DONE]\n\n'));},cancel(){cancelled=true;}});
  const {readModelStream}=await import('./server.mjs');
  assert.equal(await readModelStream(body,true),'完整回复');
  assert.equal(cancelled,true);
});
