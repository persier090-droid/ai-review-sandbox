# 本地初评实施计划

目标：每轮产生可解释的初步验证评分和行动建议，缩短默认页面内容。

- [x] 在 review-local-reference.test.mjs 与 review-delivery.test.mjs 覆盖60条初评、无匹配、变更、正式放行隔离。
- [x] 新增 review-preliminary.mjs，复用题库和场景资料提供成本拆解及评分检查项。
- [x] 接入 review-delivery.mjs 四项交付与 review-runtime.mjs 简短收口；server.mjs 读取历史结果时调用现有 ReviewStore.refresh 补充初评，保留原文。
- [x] 调整 index.html 默认摘要与折叠详情，保持原始消息及正式门槛。
- [x] 单元测试、9阶段本地验收流水线和桌面/移动检查通过；已重启本地服务。真实模型请求0，正式模型完整评审仍属独立验证项。
