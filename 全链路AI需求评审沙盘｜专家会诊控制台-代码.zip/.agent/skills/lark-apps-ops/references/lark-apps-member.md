# 应用协作者与协作权限设置（`+member-*`）

管理**谁能开发这个妙搭应用**，以及应用的协作策略（外部分享、链接分享、评论、谁能管协作者）。

三个容易混的概念，别互相代用：

| 管什么 | 命令族 | 归属 |
|---|---|---|
| 谁能**开发**这个应用（协作者 + 协作策略） | `+member-*` | 本文件 |
| 谁能**打开/访问**运行中的应用（运行时可见范围） | `+access-scope-*` | [access-scope-get](lark-apps-access-scope-get.md) / [access-scope-set](lark-apps-access-scope-set.md) |
| 应用**内部**的业务角色与角色成员（应用自己的 RBAC） | `+role-*` | → [lark-apps-authz](../../lark-apps-authz/SKILL.md) |

不要读取或判断 `app_type` 来预判支持范围，直接调用对应命令；不支持的情况由服务端返回（见下方「不支持时立即停手」）。

## 命令一览

| 命令 | 用途 | risk | 关键 flag |
|---|---|---|---|
| `+member-list` | 列出应用的全部直接协作者 | read | `--member-type`、`--role` |
| `+member-settings-get` | 读当前协作策略 | read | — |
| `+member-add` | 添加协作者 | high-risk-write | `--member-type`、`--member-id`、`--perm`、`--need-notification`、`--yes` |
| `+member-update` | 改协作者权限 | high-risk-write | `--member-type`、`--member-id`、`--perm`、`--yes` |
| `+member-remove` | 移除协作者 | high-risk-write | `--member-type`、`--member-id`、`--yes` |
| `+member-settings-set` | 改协作策略 | high-risk-write | `--external-access`、`--link-share`、`--comment-by`、`--manage-collaborators-by`、`--yes` |

四条写命令走 SKILL.md 的 exit-10 审批协议：先 `--dry-run` 核对目标与请求体（dry-run 不需要 `--yes`），把应用、成员、权限变化和影响面讲清楚，用户显式同意后再补 `--yes`。**批量移除协作者不接受泛化授权**——「你直接做」不构成对逐个成员移除的预授权。

## ID 类型：必须显式且匹配，禁止隐式转换

写命令的 `--member-type` 是**外部 ID 类型**，必须与 `--member-id` 的前缀一一对应：

| 对象 | `--member-type` | `--member-id` |
|---|---|---|
| 用户 | `openid` | `ou_...` |
| 群组 | `openchat` | `oc_...` |
| 部门 | `opendepartmentid` | `od-...` |

- **禁止传内部数字 ID**（妙搭数字 `user_id` 只用于应用内 `user_profile` 场景，不能喂给 `+member-*`），禁止猜类型，禁止自行做 ID 转换。
- 只拿到姓名 / 群名时，先在 `lark-cli` skill 里用 `contact +search-user` / `im +chat-search` 换出 `ou_` / `oc_`；换不出来就停下来问用户，不要用近似值试探。
- `+member-list --member-type` 是**另一套枚举**——筛的是响应里的对象类型 `user` / `department` / `chat`，不是写命令那三个 ID 类型。别把两套混用。

## 权限档位

`--perm`（写）与 `--role`（`+member-list` 筛选）取 `view` / `edit` / `full_access`。

## 读取

```bash
# 全部直接协作者；一次返回全量，没有分页参数，用 --member-type / --role 缩小范围
lark-cli apps +member-list --app-id "$app_id"
lark-cli apps +member-list --app-id "$app_id" --member-type user --role full_access

# 当前协作策略
lark-cli apps +member-settings-get --app-id "$app_id"
```

协作者响应**不含应用详情**。要名称、类型或发布状态时单独调 `+get --app-id "$app_id"`，不要期待成员接口顺带返回 `app`。

## 写入

```bash
# 先预览（--dry-run 不需要 --yes）
lark-cli apps +member-add    --app-id "$app_id" --member-type openid           --member-id ou_xxx --perm view --dry-run
lark-cli apps +member-update --app-id "$app_id" --member-type openchat         --member-id oc_xxx --perm edit --dry-run
lark-cli apps +member-remove --app-id "$app_id" --member-type opendepartmentid --member-id od-xxx --dry-run

# 用户确认后把 --dry-run 换成 --yes
lark-cli apps +member-add --app-id "$app_id" --member-type openid --member-id ou_xxx --perm view --yes
```

`+member-add` 可加 `--need-notification` 通知被添加的协作者。

## 协作策略

```bash
lark-cli apps +member-settings-set --app-id "$app_id" --external-access disabled --comment-by viewer --dry-run
```

| Flag | 取值 |
|---|---|
| `--external-access` | `enabled` / `disabled`（是否允许外部协作） |
| `--link-share` | `closed` / `tenant-readable` / `tenant-editable` / `anyone-readable` |
| `--comment-by` | `viewer` / `editor`（谁能评论） |
| `--manage-collaborators-by` | `anyone` / `same-tenant` / `full-access`（谁能管协作者） |

**两个只读字段，读得到但改不了**，不要尝试用别的字段模拟：

- `external_invite` 只在 `+member-settings-get` 响应里出现，跟随 `external_access` 变化，CLI 不注册 `--external-invite`。要改外部协作能力只设 `--external-access`。
- `copy_download_by` 同样只读。CCM 明确不支持给妙搭对象写入复制 / 打印 / 下载权限，CLI 不注册 `--copy-download-by`；保留读取结果即可。

## 不支持时立即停手

返回 subtype `feature_not_available`（OpenAPI code `3340005`，直连服务可能是 `40005`）时：**停止 CLI 自动化**，不切换 `app_type`，不用 `+access-scope-*` / `+role-*` / 其它成员命令绕。向用户说明该应用暂不支持通过 `lark-cli` 设置协作者，引导其在妙搭后台的权限设置里操作。
