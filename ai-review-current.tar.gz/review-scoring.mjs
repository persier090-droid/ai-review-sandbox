import {collectReviewRisks} from './review-risks.mjs';
import {scopeText} from './review-scope.mjs';
import {assessScene} from './review-scene.mjs';
import {assessFeasibility} from './review-feasibility.mjs';
const list=v=>Array.isArray(v)?v:[];
const has=v=>typeof v==='string' && v.trim().length>0;
const ratio=(n,d)=>d ? n/d : 0;
export const SCORE_POLICY={version:'review-gate-v1',status:'项目规则v1：用户授权制定；权重为治理规则，尚无实测校准，不代表行业认证',threshold:75,weights:{materials:15,coverage:15,evidence:20,challenge:20,execution:20,boundary:10}};

export function scoreReview(review) {
  const sceneAssessment=assessScene(review);
  const opinions=list(review.role_results), required=list(review.required_roles).length ? review.required_roles : list(review.roles).map(r=>r.key);
  const phases=new Set(list(review.state_history).filter(h=>h.revision===review.revision).map(h=>h.state));
  const dimensions=[];
  const dimension=(key,name,checks)=>{
    const weight=SCORE_POLICY.weights[key], earned=checks.reduce((n,c)=>n+(c.passed?c.points:0),0);
    dimensions.push({key,name,weight,earned,deducted:weight-earned,status:`${earned.toFixed(1)} / ${weight}`,basis:checks.filter(c=>!c.passed).map(c=>c.reason).join('；') || '所列检查项均有对应记录',checks});
  };
  const materials=list(review.material_requirements);
  dimension('materials','材料可定位性',materials.length ? materials.map(name=>({label:name,points:15/materials.length,passed:Boolean(review.precheck)&&!list(review.precheck.missing_materials).includes(name),reason:`缺少${name}的原文定位`,evidence:list(review.material_evidence || review.intake?.materials).find(m=>m.name===name)?.quote || ''})) : [{label:'前置材料检查',points:15,passed:review.precheck?.passed===true,reason:'尚未通过材料检查',evidence:'前置检查记录'}]);
  dimension('coverage','必要专业覆盖',required.map(key=>({label:review.roles.find(r=>r.key===key)?.name || key,points:15/required.length,passed:opinions.some(o=>o.role===key),reason:`必要岗位${key}尚无可纳入意见（覆盖缺口，不是反对票）`,evidence:opinions.find(o=>o.role===key)?.analysis?.claim || ''})));
  const evidenceFields=[['basis','可追溯前提'],['principle','理论与原则'],['reasoning','依据到判断的解释'],['counterargument','反例'],['verification','验证方式']];
  dimension('evidence','论证可检查性',evidenceFields.map(([key,label])=>({label,points:4,passed:opinions.length>0 && opinions.every(o=>key==='basis' ? list(o.analysis?.basis).length>0 : has(o.analysis?.[key])),reason:`有效意见缺少${label}`,evidence:opinions.map(o=>key==='basis'?list(o.analysis?.basis).map(b=>b.quote).join('；'):o.analysis?.[key]).join('\n')})));
  const questions=list(review.challenges), responses=list(review.responses);
  const noQuestions=phases.has('ROUND_ASK') && has(review.no_questions_reason);
  const challengeChecks=questions.length ? questions.flatMap(q=>[
    {label:`${q.id} 有依据的回应`,points:10/questions.length,passed:responses.some(r=>r.question_id===q.id && opinions.some(o=>o.role===r.responder)),reason:`${q.id} 尚无有效回应`,evidence:responses.find(r=>r.question_id===q.id)?.response || ''},
    {label:`${q.id} 质询闭环`,points:10/questions.length,passed:q.acknowledgement?.satisfied===true && opinions.some(o=>o.role===q.asker),reason:`${q.id} 尚未闭环`,evidence:q.acknowledgement?.reason || ''}
  ]) : [{label:'检查关键质询并说明无需质询的原因',points:20,passed:noQuestions,reason:'未记录关键质询检查或无需质询的原因',evidence:review.no_questions_reason || ''}];
  dimension('challenge','质询与闭环',challengeChecks);
  const execution=list(review.conclusion?.execution);
  const today=String(review.closure?.at || new Date().toISOString()).slice(0,10);
  dimension('execution','结论可执行性',[
    {label:'责任决策与依据记录',points:5,passed:has(review.conclusion?.reason) && list(review.conclusion?.basis_roles).length>0,reason:'缺少责任决策与引用岗位',evidence:review.conclusion?.reason || ''},
    {label:'任务含责任、有效日期、交付物和范围原文',points:10,passed:execution.length>0 && execution.every(e=>has(e.owner)&&Number.isFinite(Date.parse(e.deadline))&&new Date(e.deadline).toISOString().slice(0,10)>=today&&has(e.deliverable)&&has(e.scope_quote)&&scopeText(review).includes(e.scope_quote)),reason:'执行项不完整、期限过期或缺本轮范围依据',evidence:execution.map(e=>`${e.owner} ${e.deadline} ${e.deliverable} ${e.scope_quote}`).join('\n')},
    {label:'再次评审触发条件',points:5,passed:has(review.closure?.reopen_when)&&has(review.closure?.next_action),reason:'缺少具体下一步或重启条件',evidence:review.closure?.reopen_when || ''}
  ]);
  dimension('boundary','范围与分歧处理',[
    {label:'范围收口记录',points:5,passed:Array.isArray(review.closure?.in_scope)&&Array.isArray(review.closure?.parking_lot),reason:'未记录本次范围与另议事项',evidence:list(review.closure?.in_scope).join('；')},
    {label:'未决项与分歧均已处理',points:5,passed:Boolean(review.closure)&&!list(review.closure.undecided).length&&!list(review.conflicts).some(c=>!has(c.resolution))&&!list(review.deferred_questions).length,reason:'仍有未决分歧或延期质询',evidence:list(review.conflicts).map(c=>c.resolution).join('；') || '未决事项记录'}
  ]);
  const raw=dimensions.reduce((sum,d)=>sum+d.earned,0);
  const awaitingDiscussion=!opinions.length||!review.conclusion||Boolean(review.failure);
  const scoringStatus=awaitingDiscussion?'unavailable':'available';
  const scoringReason=!awaitingDiscussion?'基于本轮已纳入意见检查过程记录':review.reference_only?'本轮仅整理了案例参考，尚未完成针对本次需求的专业讨论，不评分、不判通过或不通过':review.failure?.http_status===429?'模型返回429，讨论尚未完成，尚未评分；服务受限不是需求被否决':'尚未完成有效岗位交流与决策，暂不评分；已有意见保留，继续讨论后再评判';
  const blockers=collectReviewRisks(review).filter(r=>r.impact_tag==='阻塞'&&r.status!=='已解除');
  const incomplete=list(review.conditions).filter(c=>c.revision===review.revision && c.status!=='通过');
  const roleConditions=opinions.flatMap(o=>o.stance==='有条件'?list(o.stance_conditions):[]);
  const unverifiedRoleConditions=roleConditions.filter(text=>!list(review.conditions).some(c=>c.revision===review.revision&&c.condition===text&&c.status==='通过'));
  const unresolvedDissent=opinions.filter(o=>o.stance==='反对'&&!list(review.conflicts).some(c=>list(c.parties).includes(o.role)&&has(c.resolution)&&has(c.decider)&&list(review.predictions).some(p=>p.feedback?.evidence===c.evidence)));
  const unresolvedConflicts=list(review.conflicts).filter(c=>!has(c.resolution)||!has(c.decider)||!has(c.evidence)||!list(review.predictions).some(p=>p.feedback?.evidence===c.evidence));
  const openChallenges=list(review.challenges).filter(q=>q.acknowledgement?.satisfied!==true);
  const rules=[
    {id:'R1',name:'依据与流程门槛',passed:review.precheck?.passed===true&&review.quality?.decision_ready===true&&opinions.length>0&&required.every(k=>opinions.some(o=>o.role===k))&&!review.failure&&!review.reassessment_required,reason:review.reassessment_required?'证据或验证状态已变化，原决策失效，需重新复核':'材料、必要专业覆盖、依据和决策流程必须齐备'},
    {id:'R2',name:'分数与阻塞门槛',passed:opinions.length>0&&raw>=SCORE_POLICY.threshold&&!blockers.length,reason:opinions.length?`总分需达到${SCORE_POLICY.threshold}分，且没有未解除的阻塞风险；当前${raw.toFixed(1)}分、${blockers.length}项阻塞`:`尚未评分，暂不能核验${SCORE_POLICY.threshold}分门槛；未取得有效专业意见不记为低分`},
    {id:'R3',name:'放行与验证门槛',passed:review.conclusion?.decision==='通过'&&!incomplete.length&&!unverifiedRoleConditions.length&&!unresolvedDissent.length&&!unresolvedConflicts.length&&!openChallenges.length&&!list(review.deferred_questions).length&&!list(review.closure?.undecided).length,reason:`责任决策必须明确通过，附加条件均已验证；当前${incomplete.length}项决策条件、${unverifiedRoleConditions.length}项岗位条件待验证，${unresolvedDissent.length}项反对意见、${unresolvedConflicts.length}项分歧、${openChallenges.length}项质询尚未闭环`}
  ];
  if(!sceneAssessment.passed) {
    rules[0].passed=false;
    rules[0].reason+='；场景专项验收：'+(sceneAssessment.error || sceneAssessment.checks.filter(c=>!c.passed).map(c=>`${c.label}：${c.reason}`).join('；'));
  }
  if(sceneAssessment.evidence_required&&!sceneAssessment.passed){rules[2].passed=false;rules[2].reason+='；当前评审类型必须完成场景验收与人工证据回填';}
  const feasibility=assessFeasibility(review);
  if(feasibility.blockers.length||feasibility.cost.budget_status==='超出已列预算') {
    rules[2].passed=false;
    rules[2].reason+='；投入与场景边界未满足：'+[...feasibility.blockers.map(b=>b.reason),...(feasibility.cost.budget_status==='超出已列预算'?['已列费用超过验证预算，须缩小范围或重新确认预算']:[])].join('；');
  }
  if(awaitingDiscussion) for(const rule of rules){rule.passed=false;rule.status='pending';rule.reason='讨论与责任决策尚未完成，尚未评分；本条规则待评估，不作通过或不通过判定';}
  return {policy:SCORE_POLICY,decision_status:awaitingDiscussion?'awaiting_discussion':'reviewed',score:awaitingDiscussion?null:Math.round(raw*10)/10,raw_score:raw,scoring_status:scoringStatus,scoring_reason:scoringReason,formula:'S = Σ(检查项权重 × 已满足标记)，标记为0或1；满分100，按未四舍五入值判定',dimensions,rules,verdict:awaitingDiscussion?'待讨论':rules.every(r=>r.passed)?'通过':'不通过',coverage_ratio:ratio(opinions.length,list(review.roles).length),scope:'过程证据完整性评分，不是成功概率、事实真实性或上线质量认证'};
}
